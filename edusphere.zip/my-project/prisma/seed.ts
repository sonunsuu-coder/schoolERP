import { PrismaClient } from '@prisma/client'

// Use a fresh client without query logging for speed
const db = new PrismaClient()

async function main() {
  console.log('🌱 Seeding EduSphere database...')

  // Clean existing data (order matters due to foreign keys)
  console.log('  Cleaning existing data...')
  const deleteOrder = [
    'mark', 'payment', 'feeRecord', 'attendance', 'teacherAttendance',
    'timetable', 'homework', 'lessonPlan', 'exam',
    'notification', 'event', 'enquiry',
    'income', 'expense',
    'libraryBook', 'vehicle',
    'staff', 'teacher', 'student',
    'section', 'subject', 'class',
    'school',
  ] as const
  for (const model of deleteOrder) {
    try {
      // @ts-ignore
      await db[model].deleteMany({})
    } catch {}
  }
  console.log('    ✓ Database cleaned')

  // ─── 1. SCHOOL ────────────────────────────────────────────────
  console.log('  Creating school...')
  const school = await db.school.create({
    data: {
      name: 'Delhi Public School, Sector 24',
      address: 'Sector 24, Roorkee, Uttarakhand, 247667',
      phone: '+91-1332-272580',
      email: 'admin@dpsroorkee.com',
      established: 1995,
    },
  })
  const schoolId = school.id
  console.log(`    ✓ School: ${school.name}`)

  // ─── 2. CLASSES ───────────────────────────────────────────────
  console.log('  Creating classes...')
  const classes: Record<number, string> = {}
  for (let i = 1; i <= 12; i++) {
    const cls = await db.class.create({
      data: { name: `Class ${i}`, numericLevel: i, schoolId },
    })
    classes[i] = cls.id
  }
  console.log(`    ✓ 12 classes created`)

  // ─── 3. SECTIONS ──────────────────────────────────────────────
  console.log('  Creating sections...')
  const sections: Record<string, string> = {}
  for (let i = 1; i <= 12; i++) {
    for (const sec of ['A', 'B'] as const) {
      const section = await db.section.create({
        data: { name: sec, classId: classes[i], schoolId },
      })
      sections[`${i}-${sec}`] = section.id
    }
  }
  console.log(`    ✓ 24 sections created`)

  // ─── 4. SUBJECTS ──────────────────────────────────────────────
  console.log('  Creating subjects...')
  const subjectData = [
    { name: 'English', code: 'ENG', type: 'theory' },
    { name: 'Hindi', code: 'HIN', type: 'theory' },
    { name: 'Mathematics', code: 'MAT', type: 'theory' },
    { name: 'Science', code: 'SCI', type: 'theory' },
    { name: 'Social Studies', code: 'SST', type: 'theory' },
    { name: 'Computer Science', code: 'CS', type: 'theory' },
    { name: 'Physics', code: 'PHY', type: 'theory' },
    { name: 'Chemistry', code: 'CHEM', type: 'theory' },
    { name: 'Biology', code: 'BIO', type: 'theory' },
    { name: 'Economics', code: 'ECS', type: 'theory' },
    { name: 'Physical Education', code: 'PE', type: 'practical' },
    { name: 'Art', code: 'ART', type: 'practical' },
    { name: 'Music', code: 'MUS', type: 'practical' },
  ]
  const subjects: Record<string, string> = {}
  for (const s of subjectData) {
    const subj = await db.subject.create({
      data: { name: s.name, code: s.code, type: s.type, schoolId },
    })
    subjects[s.code] = subj.id
  }
  console.log(`    ✓ 13 subjects created`)

  // ─── 5. TEACHERS ──────────────────────────────────────────────
  console.log('  Creating teachers...')
  const teacherData = [
    { employeeId: 'T001', firstName: 'Rajesh', lastName: 'Sharma', gender: 'male', qualification: 'M.Ed', specialization: 'English', experience: 18, salary: 65000, phone: '+91-98765-43210' },
    { employeeId: 'T002', firstName: 'Priya', lastName: 'Gupta', gender: 'female', qualification: 'M.Sc', specialization: 'Mathematics', experience: 12, salary: 58000, phone: '+91-98765-43211' },
    { employeeId: 'T003', firstName: 'Amit', lastName: 'Verma', gender: 'male', qualification: 'M.Sc', specialization: 'Physics', experience: 15, salary: 62000, phone: '+91-98765-43212' },
    { employeeId: 'T004', firstName: 'Sunita', lastName: 'Devi', gender: 'female', qualification: 'M.A', specialization: 'Hindi', experience: 20, salary: 68000, phone: '+91-98765-43213' },
    { employeeId: 'T005', firstName: 'Vikram', lastName: 'Singh', gender: 'male', qualification: 'M.Sc', specialization: 'Chemistry', experience: 10, salary: 55000, phone: '+91-98765-43214' },
    { employeeId: 'T006', firstName: 'Anita', lastName: 'Kumari', gender: 'female', qualification: 'M.Ed', specialization: 'Biology', experience: 8, salary: 50000, phone: '+91-98765-43215' },
    { employeeId: 'T007', firstName: 'Suresh', lastName: 'Kumar', gender: 'male', qualification: 'B.Tech', specialization: 'Computer Science', experience: 6, salary: 52000, phone: '+91-98765-43216' },
    { employeeId: 'T008', firstName: 'Meera', lastName: 'Patel', gender: 'female', qualification: 'M.A', specialization: 'Social Studies', experience: 14, salary: 60000, phone: '+91-98765-43217' },
    { employeeId: 'T009', firstName: 'Rakesh', lastName: 'Joshi', gender: 'male', qualification: 'M.P.Ed', specialization: 'Physical Education', experience: 9, salary: 48000, phone: '+91-98765-43218' },
    { employeeId: 'T010', firstName: 'Kavita', lastName: 'Malhotra', gender: 'female', qualification: 'M.A', specialization: 'Art', experience: 7, salary: 45000, phone: '+91-98765-43219' },
    { employeeId: 'T011', firstName: 'Deepak', lastName: 'Agarwal', gender: 'male', qualification: 'M.Sc', specialization: 'Mathematics', experience: 11, salary: 57000, phone: '+91-98765-43220' },
    { employeeId: 'T012', firstName: 'Pooja', lastName: 'Rani', gender: 'female', qualification: 'M.A', specialization: 'English', experience: 5, salary: 42000, phone: '+91-98765-43221' },
    { employeeId: 'T013', firstName: 'Manish', lastName: 'Tiwari', gender: 'male', qualification: 'B.Tech', specialization: 'Computer Science', experience: 4, salary: 40000, phone: '+91-98765-43222' },
    { employeeId: 'T014', firstName: 'Neha', lastName: 'Sharma', gender: 'female', qualification: 'M.A', specialization: 'Music', experience: 3, salary: 38000, phone: '+91-98765-43223' },
    { employeeId: 'T015', firstName: 'Sanjay', lastName: 'Mishra', gender: 'male', qualification: 'M.Com', specialization: 'Economics', experience: 16, salary: 63000, phone: '+91-98765-43224' },
  ]
  const teachers: Record<string, { id: string; name: string }> = {}
  for (const t of teacherData) {
    const teacher = await db.teacher.create({
      data: {
        employeeId: t.employeeId,
        firstName: t.firstName,
        lastName: t.lastName,
        email: `${t.firstName.toLowerCase()}.${t.lastName.toLowerCase()}@dpsroorkee.com`,
        phone: t.phone,
        gender: t.gender,
        qualification: t.qualification,
        specialization: t.specialization,
        experience: t.experience,
        salary: t.salary,
        address: `${Math.floor(Math.random() * 30) + 1}, Civil Lines, Roorkee`,
        schoolId,
      },
    })
    teachers[t.employeeId] = { id: teacher.id, name: `${t.firstName} ${t.lastName}` }
  }
  console.log(`    ✓ 15 teachers created`)

  // ─── 6. STUDENTS ──────────────────────────────────────────────
  console.log('  Creating students...')
  // Distribution: more students in lower classes, fewer in higher
  // Class 1-3: 9 each (27), Class 4-6: 8 each (24), Class 7-9: 6 each (18), Class 10-12: 4 each (11) → ~80
  // Actually: let me do: 1-3: 8, 4-6: 7, 7-8: 6, 9-10: 5, 11-12: 4 = 24+21+12+10+8 = 75... let me adjust
  // 1-3: 8ea=24, 4-6: 7ea=21, 7-8: 6ea=12, 9-10: 5ea=10, 11-12: 7ea=14 = 81... close enough, adjust
  // Simpler: 1-3: 8, 4-6: 7, 7-9: 6, 10-12: 5 = 24+21+18+15 = 78... close enough
  // Let me just distribute 80: class 1:8, 2:8, 3:8, 4:7, 5:7, 6:7, 7:6, 8:6, 9:6, 10:5, 11:6, 12:6 = 80
  const studentDistribution: Record<number, number> = {
    1: 8, 2: 8, 3: 8, 4: 7, 5: 7, 6: 7, 7: 6, 8: 6, 9: 6, 10: 5, 11: 6, 12: 6,
  }

  const indianFirstNamesMale = [
    'Arjun', 'Rahul', 'Aryan', 'Vivaan', 'Aditya', 'Karthik', 'Vihaan', 'Sai',
    'Rohit', 'Nikhil', 'Harsh', 'Yash', 'Atharv', 'Dhruv', 'Pranav', 'Manan',
    'Ishaan', 'Kunal', 'Varun', 'Akash', 'Shivam', 'Parth', 'Lakshay', 'Ayush',
    'Dev', 'Aaditya', 'Gaurav', 'Tanmay', 'Rudra', 'Ayaan', 'Reyansh', 'Krishna',
    'Aryan', 'Ansh', 'Vansh', 'Kabir', 'Shreyas', 'Siddharth', 'Harshit', 'Mayank',
    'Vishal', 'Himanshu', 'Naman', 'Samarth', 'Tushar', 'Divyanshu', 'Shashwat',
  ]
  const indianFirstNamesFemale = [
    'Ananya', 'Diya', 'Ishita', 'Saanvi', 'Aadhya', 'Kavya', 'Riya', 'Pooja',
    'Shruti', 'Nisha', 'Priya', 'Aanya', 'Sneha', 'Tanya', 'Muskaan', 'Khushi',
    'Avani', 'Navya', 'Siddhi', 'Ishani', 'Meera', 'Kashvi', 'Prisha', 'Vidhi',
    'Aarohi', 'Aditi', 'Bhavya', 'Charvi', 'Disha', 'Esha', 'Gargi', 'Hridaya',
    'Jiya', 'Kamya', 'Lavanya', 'Mahi', 'Nitya', 'Ojasvi', 'Prachi', 'Rashi',
    'Simran', 'Trisha', 'Urvi', 'Vedika', 'Wafika',
  ]
  const indianLastNames = [
    'Sharma', 'Gupta', 'Verma', 'Singh', 'Kumar', 'Patel', 'Joshi', 'Malhotra',
    'Agarwal', 'Rani', 'Tiwari', 'Mishra', 'Rao', 'Reddy', 'Nair', 'Iyer',
    'Chopra', 'Kapoor', 'Bhatia', 'Chauhan', 'Rathore', 'Saxena', 'Pandey', 'Dubey',
    'Yadav', 'Mehta', 'Desai', 'Bansal', 'Goel', 'Khandelwal',
  ]

  const fatherFirstNames = [
    'Rajendra', 'Suresh', 'Mahesh', 'Dinesh', 'Ramesh', 'Mukesh', 'Anil', 'Ashok',
    'Kamal', 'Prakash', 'Rajiv', 'Vijay', 'Brijesh', 'Naresh', 'Harish', 'Pankaj',
    'Girish', 'Subhash', 'Pradeep', 'Santosh', 'Ranjeet', 'Amrit', 'Pramod', 'Dilip',
    'Gopal', 'Kishan', 'Nand', 'Mohan', 'Deepak', 'Bharat',
  ]
  const motherFirstNames = [
    'Sunita', 'Geeta', 'Kamla', 'Pushpa', 'Saroj', 'Shanti', 'Rekha', 'Usha',
    'Suman', 'Asha', 'Lata', 'Kiran', 'Mamta', 'Sushma', 'Priti', 'Neelam',
    'Anju', 'Sangita', 'Manju', 'Rajni', 'Kavita', 'Sarita', 'Veena', 'Archana',
    'Bindu', 'Chitra', 'Deepa', 'Hema', 'Jyoti', 'Lalita',
  ]

  const roorkeeAreas = [
    'Civil Lines, Roorkee', 'Sadar Bazaar, Roorkee', 'Station Road, Roorkee',
    'Piran Kaliyar Road, Roorkee', 'Laksar Road, Roorkee', 'Haridwar Road, Roorkee',
    'MG Road, Roorkee', 'IIT Campus Area, Roorkee', 'Gangnahar, Roorkee',
    'Shivpuri, Roorkee', 'Solanipuram, Roorkee', 'Bhood Road, Roorkee',
    'Subhash Nagar, Roorkee', 'Gandhi Nagar, Roorkee', 'Rampur, Roorkee',
  ]

  // Class-appropriate birth years: Class 1 ~2018, Class 12 ~2008
  function getBirthYear(classLevel: number): number {
    return 2018 - (classLevel - 1)
  }

  function randomFrom<T>(arr: T[]): T {
    return arr[Math.floor(Math.random() * arr.length)]
  }

  function randomDateInYear(year: number): Date {
    const month = Math.floor(Math.random() * 12) + 1
    const day = Math.floor(Math.random() * 28) + 1
    return new Date(year, month - 1, day)
  }

  const studentIds: Record<number, string[]> = {} // classLevel -> student ids
  const studentNameMap: Record<string, string> = {} // studentId -> "FirstName LastName"
  let admCounter = 1

  for (let classLevel = 1; classLevel <= 12; classLevel++) {
    const count = studentDistribution[classLevel]
    const classSectionIds: Record<string, string[]> = { A: [], B: [] }
    const allClassStudentIds: string[] = []

    for (let i = 0; i < count; i++) {
      const section = i < Math.ceil(count / 2) ? 'A' : 'B'
      const rollNumber = classSectionIds[section].length + 1
      const gender = Math.random() > 0.5 ? 'male' : 'female'
      const firstName = gender === 'male'
        ? randomFrom(indianFirstNamesMale)
        : randomFrom(indianFirstNamesFemale)
      const lastName = randomFrom(indianLastNames)
      const fatherName = `${randomFrom(fatherFirstNames)} ${lastName}`
      const motherName = `${randomFrom(motherFirstNames)} ${lastName}`
      const birthYear = getBirthYear(classLevel)
      const dob = randomDateInYear(birthYear)
      const admissionNo = `ADM-2024-${String(admCounter).padStart(3, '0')}`
      admCounter++

      const student = await db.student.create({
        data: {
          admissionNo,
          rollNumber: String(rollNumber),
          firstName,
          lastName,
          dob,
          gender,
          bloodGroup: randomFrom(['A+', 'B+', 'O+', 'AB+', 'A-', 'B-', 'O-']),
          religion: randomFrom(['Hindu', 'Muslim', 'Sikh', 'Christian']),
          category: randomFrom(['General', 'OBC', 'SC', 'ST']),
          address: `${Math.floor(Math.random() * 200) + 1}, ${randomFrom(roorkeeAreas)}`,
          phone: `+91-${Math.floor(Math.random() * 90000) + 10000}-${Math.floor(Math.random() * 90000) + 10000}`,
          fatherName,
          fatherPhone: `+91-${Math.floor(Math.random() * 90000) + 10000}-${Math.floor(Math.random() * 90000) + 10000}`,
          fatherOccupation: randomFrom(['Farmer', 'Businessman', 'Government Employee', 'Private Job', 'Doctor', 'Engineer', 'Teacher', 'Shopkeeper']),
          motherName,
          motherPhone: `+91-${Math.floor(Math.random() * 90000) + 10000}-${Math.floor(Math.random() * 90000) + 10000}`,
          motherOccupation: randomFrom(['Homemaker', 'Teacher', 'Nurse', 'Private Job', 'Business']),
          admissionDate: new Date(2024, 3, 1),
          schoolId,
          classId: classes[classLevel],
          sectionId: sections[`${classLevel}-${section}`],
          className: `Class ${classLevel}`,
          sectionName: `Section ${section}`,
          status: 'active',
        },
      })
      classSectionIds[section].push(student.id)
      allClassStudentIds.push(student.id)
      studentNameMap[student.id] = `${firstName} ${lastName}`
    }
    studentIds[classLevel] = allClassStudentIds
  }
  console.log(`    ✓ 80 students created`)

  // ─── 7. STUDENT ATTENDANCE (last 30 days) ─────────────────────
  console.log('  Creating student attendance...')
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const allStudentIds = Object.values(studentIds).flat()
  const attendanceBatch: { studentId: string; date: Date; status: string; remarks?: string }[] = []

  for (const studentId of allStudentIds) {
    for (let d = 29; d >= 0; d--) {
      const date = new Date(today)
      date.setDate(date.getDate() - d)
      // Skip Sundays
      if (date.getDay() === 0) continue
      const rand = Math.random()
      const status = rand < 0.85 ? 'present' : rand < 0.95 ? 'absent' : 'late'
      attendanceBatch.push({ studentId, date, status })
    }
  }

  // Insert in batches of 500 to avoid issues
  for (let i = 0; i < attendanceBatch.length; i += 500) {
    const batch = attendanceBatch.slice(i, i + 500)
    await db.attendance.createMany({ data: batch })
  }
  console.log(`    ✓ ${attendanceBatch.length} student attendance records created`)

  // ─── 8. TEACHER ATTENDANCE (last 30 days) ─────────────────────
  console.log('  Creating teacher attendance...')
  const teacherAttendanceBatch: { teacherId: string; date: Date; status: string; checkIn?: Date; checkOut?: Date }[] = []

  for (const empId of Object.keys(teachers)) {
    const teacherId = teachers[empId].id
    for (let d = 29; d >= 0; d--) {
      const date = new Date(today)
      date.setDate(date.getDate() - d)
      if (date.getDay() === 0) continue
      const rand = Math.random()
      const status = rand < 0.95 ? 'present' : rand < 0.98 ? 'absent' : 'late'
      const entry: { teacherId: string; date: Date; status: string; checkIn?: Date; checkOut?: Date } = { teacherId, date, status }
      if (status !== 'absent') {
        const checkIn = new Date(date)
        checkIn.setHours(7, 30 + Math.floor(Math.random() * 30), 0)
        const checkOut = new Date(date)
        checkOut.setHours(14 + Math.floor(Math.random() * 2), Math.floor(Math.random() * 60), 0)
        entry.checkIn = checkIn
        entry.checkOut = checkOut
      }
      teacherAttendanceBatch.push(entry)
    }
  }

  for (let i = 0; i < teacherAttendanceBatch.length; i += 100) {
    const batch = teacherAttendanceBatch.slice(i, i + 100)
    await Promise.all(batch.map(record => {
      const data: { teacherId: string; date: Date; status: string; checkIn?: Date; checkOut?: Date } = {
        teacherId: record.teacherId,
        date: record.date,
        status: record.status,
      }
      if (record.checkIn && record.checkOut) {
        data.checkIn = record.checkIn
        data.checkOut = record.checkOut
      }
      return db.teacherAttendance.create({ data })
    }))
  }
  console.log(`    ✓ ${teacherAttendanceBatch.length} teacher attendance records created`)

  // ─── 9. FEE STRUCTURES ────────────────────────────────────────
  console.log('  Creating fee structures...')
  const feeStructures: Record<string, string> = {}

  // Tuition fee varies by class
  for (let cl = 1; cl <= 12; cl++) {
    const amount = 1500 + (cl - 1) * Math.round(3500 / 11)
    const fs = await db.feeStructure.create({
      data: {
        name: 'Tuition Fee',
        amount,
        frequency: 'monthly',
        type: 'tuition',
        className: `Class ${cl}`,
        schoolId,
        status: 'active',
      },
    })
    feeStructures[`tuition-${cl}`] = fs.id
  }

  // Transport Fee
  const transportFs = await db.feeStructure.create({
    data: { name: 'Transport Fee', amount: 2000, frequency: 'monthly', type: 'transport', schoolId, status: 'active' },
  })
  feeStructures['transport'] = transportFs.id

  // Lab Fee
  const labFs = await db.feeStructure.create({
    data: { name: 'Lab Fee', amount: 1000, frequency: 'quarterly', type: 'lab', schoolId, status: 'active' },
  })
  feeStructures['lab'] = labFs.id

  // Sports Fee
  const sportsFs = await db.feeStructure.create({
    data: { name: 'Sports Fee', amount: 500, frequency: 'quarterly', type: 'sports', schoolId, status: 'active' },
  })
  feeStructures['sports'] = sportsFs.id

  // Library Fee
  const libraryFs = await db.feeStructure.create({
    data: { name: 'Library Fee', amount: 500, frequency: 'annual', type: 'library', schoolId, status: 'active' },
  })
  feeStructures['library'] = libraryFs.id

  // Exam Fee
  const examFs = await db.feeStructure.create({
    data: { name: 'Exam Fee', amount: 300, frequency: 'quarterly', type: 'exam', schoolId, status: 'active' },
  })
  feeStructures['exam'] = examFs.id

  console.log(`    ✓ ${Object.keys(feeStructures).length} fee structures created`)

  // ─── 10. FEE RECORDS ──────────────────────────────────────────
  console.log('  Creating fee records...')
  const paidFeeRecordIds: string[] = []

  const currentQuarterStart = new Date(today)
  currentQuarterStart.setMonth(currentQuarterStart.getMonth() - 2, 1)
  const paidDaysAgoOptions = [5, 10, 15, 20, 25, 35, 45]

  function makeFeeStatus(paidProb: number): { status: string; paidAmount: number; paidDate: Date | undefined } {
    const rand = Math.random()
    if (rand < paidProb) {
      const daysAgo = paidDaysAgoOptions[Math.floor(Math.random() * paidDaysAgoOptions.length)]
      const pd = new Date(today); pd.setDate(pd.getDate() - daysAgo)
      return { status: 'paid', paidAmount: 0, paidDate: pd } // paidAmount set by caller
    } else if (rand < paidProb + 0.2) {
      return { status: 'pending', paidAmount: 0, paidDate: undefined }
    }
    return { status: 'overdue', paidAmount: 0, paidDate: undefined }
  }

  for (let cl = 1; cl <= 12; cl++) {
    const classStudentIds = studentIds[cl]
    if (!classStudentIds) continue
    const tuitionAmount = 1500 + (cl - 1) * Math.round(3500 / 11)

    const feePromises: Promise<any>[] = []

    for (const studentId of classStudentIds) {
      const studentName = studentNameMap[studentId]

      // Tuition fee for this quarter (3 months)
      for (let m = 0; m < 3; m++) {
        const dueDate = new Date(currentQuarterStart)
        dueDate.setMonth(dueDate.getMonth() + m, 15)
        const fs = makeFeeStatus(0.6)
        if (fs.status === 'paid') fs.paidAmount = tuitionAmount

        feePromises.push(
          db.feeRecord.create({
            data: {
              studentId, feeStructureId: feeStructures[`tuition-${cl}`],
              feeName: 'Tuition Fee', studentName, amount: tuitionAmount,
              paidAmount: fs.paidAmount, dueDate, paidDate: fs.paidDate, status: fs.status, schoolId,
            },
          }).then(fr => { if (fr.status === 'paid') paidFeeRecordIds.push(fr.id) })
        )
      }

      // Transport fee (1 record for current month)
      {
        const dueDate = new Date(currentQuarterStart); dueDate.setDate(15)
        const fs = makeFeeStatus(0.5)
        if (fs.status === 'paid') fs.paidAmount = 2000
        feePromises.push(
          db.feeRecord.create({
            data: {
              studentId, feeStructureId: feeStructures['transport'],
              feeName: 'Transport Fee', studentName, amount: 2000,
              paidAmount: fs.paidAmount, dueDate, paidDate: fs.paidDate, status: fs.status, schoolId,
            },
          }).then(fr => { if (fr.status === 'paid') paidFeeRecordIds.push(fr.id) })
        )
      }

      // Lab fee (quarterly)
      {
        const dueDate = new Date(currentQuarterStart); dueDate.setDate(15)
        const fs = makeFeeStatus(0.55)
        if (fs.status === 'paid') fs.paidAmount = 1000
        feePromises.push(
          db.feeRecord.create({
            data: {
              studentId, feeStructureId: feeStructures['lab'],
              feeName: 'Lab Fee', studentName, amount: 1000,
              paidAmount: fs.paidAmount, dueDate, paidDate: fs.paidDate, status: fs.status, schoolId,
            },
          }).then(fr => { if (fr.status === 'paid') paidFeeRecordIds.push(fr.id) })
        )
      }

      // Sports fee (quarterly)
      {
        const dueDate = new Date(currentQuarterStart); dueDate.setDate(20)
        const fs = makeFeeStatus(0.5)
        if (fs.status === 'paid') fs.paidAmount = 500
        feePromises.push(
          db.feeRecord.create({
            data: {
              studentId, feeStructureId: feeStructures['sports'],
              feeName: 'Sports Fee', studentName, amount: 500,
              paidAmount: fs.paidAmount, dueDate, paidDate: fs.paidDate, status: fs.status, schoolId,
            },
          }).then(fr => { if (fr.status === 'paid') paidFeeRecordIds.push(fr.id) })
        )
      }

      // Exam fee (quarterly)
      {
        const dueDate = new Date(currentQuarterStart); dueDate.setDate(25)
        const fs = makeFeeStatus(0.6)
        if (fs.status === 'paid') fs.paidAmount = 300
        feePromises.push(
          db.feeRecord.create({
            data: {
              studentId, feeStructureId: feeStructures['exam'],
              feeName: 'Exam Fee', studentName, amount: 300,
              paidAmount: fs.paidAmount, dueDate, paidDate: fs.paidDate, status: fs.status, schoolId,
            },
          }).then(fr => { if (fr.status === 'paid') paidFeeRecordIds.push(fr.id) })
        )
      }
    }

    // Execute all fee record creates for this class in parallel
    await Promise.all(feePromises)
  }
  console.log(`    ✓ Fee records created (includes tuition, transport, lab, sports, exam)`)

  // ─── 11. PAYMENTS ─────────────────────────────────────────────
  console.log('  Creating payments...')
  const paymentMethods = ['UPI', 'Cash', 'Bank Transfer', 'Online']

  // Fetch paid fee records with amounts
  if (paidFeeRecordIds.length > 0) {
    const paidFeeRecords = await db.feeRecord.findMany({
      where: { id: { in: paidFeeRecordIds } },
      select: { id: true, paidAmount: true, paidDate: true },
    })
    const paymentPromises = paidFeeRecords.map(fr =>
      db.payment.create({
        data: {
          feeRecordId: fr.id,
          amount: fr.paidAmount,
          method: randomFrom(paymentMethods),
          transactionId: `TXN-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
          status: 'completed',
          paidAt: fr.paidDate || new Date(),
          schoolId,
        },
      })
    )
    await Promise.all(paymentPromises)
  }
  console.log(`    ✓ ${paidFeeRecordIds.length} payment records created`)

  // ─── 12. EXAMS ────────────────────────────────────────────────
  console.log('  Creating exams...')
  const class10ASectionId = sections['10-A']

  const completedExamDate = new Date(today)
  completedExamDate.setDate(completedExamDate.getDate() - 30)

  const midTermDate = new Date(today)
  midTermDate.setDate(midTermDate.getDate() - 10)

  const upcomingDate1 = new Date(today)
  upcomingDate1.setDate(upcomingDate1.getDate() + 15)

  const upcomingDate2 = new Date(today)
  upcomingDate2.setDate(upcomingDate2.getDate() + 45)

  const examSubjectsCompleted1 = ['English', 'Hindi', 'Mathematics', 'Science']
  const examSubjectsCompleted2 = ['English', 'Hindi', 'Mathematics', 'Science', 'Social Studies']
  const examSubjectsUpcoming = ['English', 'Hindi', 'Mathematics', 'Science', 'Social Studies', 'Computer Science']

  const exams: Record<string, string> = {}

  // Unit Test 1 (completed)
  for (const subj of examSubjectsCompleted1) {
    const startD = new Date(completedExamDate)
    const endD = new Date(completedExamDate)
    endD.setHours(endD.getHours() + 2)
    const exam = await db.exam.create({
      data: {
        name: 'Unit Test 1',
        type: 'unit-test',
        startDate: startD,
        endDate: endD,
        status: 'completed',
        schoolId,
        subjectName: subj,
        sectionId: class10ASectionId,
        sectionName: 'Section A',
        maxMarks: 100,
        className: 'Class 10',
      },
    })
    exams[`ut1-${subj}`] = exam.id
  }

  // Mid Term (completed)
  for (const subj of examSubjectsCompleted2) {
    const startD = new Date(midTermDate)
    const endD = new Date(midTermDate)
    endD.setHours(endD.getHours() + 3)
    const exam = await db.exam.create({
      data: {
        name: 'Mid Term',
        type: 'mid-term',
        startDate: startD,
        endDate: endD,
        status: 'completed',
        schoolId,
        subjectName: subj,
        sectionId: class10ASectionId,
        sectionName: 'Section A',
        maxMarks: 100,
        className: 'Class 10',
      },
    })
    exams[`mt-${subj}`] = exam.id
  }

  // Unit Test 2 (upcoming)
  for (const subj of examSubjectsUpcoming) {
    const startD = new Date(upcomingDate1)
    const endD = new Date(upcomingDate1)
    endD.setHours(endD.getHours() + 2)
    await db.exam.create({
      data: {
        name: 'Unit Test 2',
        type: 'unit-test',
        startDate: startD,
        endDate: endD,
        status: 'upcoming',
        schoolId,
        subjectName: subj,
        sectionId: class10ASectionId,
        sectionName: 'Section A',
        maxMarks: 100,
        className: 'Class 10',
      },
    })
  }

  // Annual Exam (upcoming)
  for (const subj of examSubjectsUpcoming) {
    const startD = new Date(upcomingDate2)
    const endD = new Date(upcomingDate2)
    endD.setHours(endD.getHours() + 3)
    await db.exam.create({
      data: {
        name: 'Annual Exam',
        type: 'annual',
        startDate: startD,
        endDate: endD,
        status: 'upcoming',
        schoolId,
        subjectName: subj,
        sectionId: class10ASectionId,
        sectionName: 'Section A',
        maxMarks: 100,
        className: 'Class 10',
      },
    })
  }
  console.log(`    ✓ ${examSubjectsCompleted1.length + examSubjectsCompleted2.length + examSubjectsUpcoming.length * 2} exams created`)

  // ─── 13. MARKS ────────────────────────────────────────────────
  console.log('  Creating marks...')
  function getGrade(percentage: number): string {
    if (percentage >= 90) return 'A+'
    if (percentage >= 80) return 'A'
    if (percentage >= 70) return 'B+'
    if (percentage >= 60) return 'B'
    if (percentage >= 50) return 'C'
    return 'D'
  }

  // Get students in Class 10A
  const class10AStudents = await db.student.findMany({
    where: { classId: classes[10], sectionId: sections['10-A'] },
    select: { id: true, firstName: true, lastName: true },
  })

  const completedExamIds = [
    ...Object.values(exams),
  ]

  for (const student of class10AStudents) {
    const studentName = `${student.firstName} ${student.lastName}`
    // Base performance level for this student (some students perform better consistently)
    const basePerformance = 50 + Math.random() * 40 // 50-90

    for (const examId of completedExamIds) {
      // Vary around base performance
      const marksObtained = Math.min(100, Math.max(15, Math.round(
        basePerformance + (Math.random() - 0.5) * 30
      )))
      const grade = getGrade(marksObtained)

      await db.mark.create({
        data: {
          studentId: student.id,
          examId,
          marksObtained,
          grade,
          remarks: marksObtained >= 90 ? 'Excellent' : marksObtained >= 75 ? 'Good' : marksObtained >= 50 ? 'Average' : 'Needs Improvement',
          studentName,
        },
      })
    }
  }
  console.log(`    ✓ Marks for ${class10AStudents.length} students across completed exams`)

  // ─── 14. TIMETABLE ────────────────────────────────────────────
  console.log('  Creating timetable...')
  const periods = [
    { period: 1, startTime: '8:00', endTime: '8:45' },
    { period: 2, startTime: '8:45', endTime: '9:30' },
    { period: 3, startTime: '9:30', endTime: '10:15' },
    { period: 4, startTime: '10:30', endTime: '11:15' },
    { period: 5, startTime: '11:15', endTime: '12:00' },
    { period: 6, startTime: '12:45', endTime: '1:30' },
    { period: 7, startTime: '1:30', endTime: '2:15' },
    { period: 8, startTime: '2:15', endTime: '3:00' },
  ]

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']

  // Teacher-to-subject mapping for class 10A timetable
  const ttSlots: { day: string; period: number; subjectCode: string; teacherEmpId: string }[] = [
    // Monday
    { day: 'Monday', period: 1, subjectCode: 'ENG', teacherEmpId: 'T001' },
    { day: 'Monday', period: 2, subjectCode: 'MAT', teacherEmpId: 'T002' },
    { day: 'Monday', period: 3, subjectCode: 'HIN', teacherEmpId: 'T004' },
    { day: 'Monday', period: 4, subjectCode: 'PHY', teacherEmpId: 'T003' },
    { day: 'Monday', period: 5, subjectCode: 'CHEM', teacherEmpId: 'T005' },
    { day: 'Monday', period: 6, subjectCode: 'BIO', teacherEmpId: 'T006' },
    { day: 'Monday', period: 7, subjectCode: 'CS', teacherEmpId: 'T007' },
    { day: 'Monday', period: 8, subjectCode: 'PE', teacherEmpId: 'T009' },
    // Tuesday
    { day: 'Tuesday', period: 1, subjectCode: 'MAT', teacherEmpId: 'T002' },
    { day: 'Tuesday', period: 2, subjectCode: 'ENG', teacherEmpId: 'T012' },
    { day: 'Tuesday', period: 3, subjectCode: 'SST', teacherEmpId: 'T008' },
    { day: 'Tuesday', period: 4, subjectCode: 'HIN', teacherEmpId: 'T004' },
    { day: 'Tuesday', period: 5, subjectCode: 'PHY', teacherEmpId: 'T003' },
    { day: 'Tuesday', period: 6, subjectCode: 'MAT', teacherEmpId: 'T011' },
    { day: 'Tuesday', period: 7, subjectCode: 'ECS', teacherEmpId: 'T015' },
    { day: 'Tuesday', period: 8, subjectCode: 'ART', teacherEmpId: 'T010' },
    // Wednesday
    { day: 'Wednesday', period: 1, subjectCode: 'ENG', teacherEmpId: 'T001' },
    { day: 'Wednesday', period: 2, subjectCode: 'CHEM', teacherEmpId: 'T005' },
    { day: 'Wednesday', period: 3, subjectCode: 'MAT', teacherEmpId: 'T002' },
    { day: 'Wednesday', period: 4, subjectCode: 'BIO', teacherEmpId: 'T006' },
    { day: 'Wednesday', period: 5, subjectCode: 'CS', teacherEmpId: 'T013' },
    { day: 'Wednesday', period: 6, subjectCode: 'SST', teacherEmpId: 'T008' },
    { day: 'Wednesday', period: 7, subjectCode: 'HIN', teacherEmpId: 'T004' },
    { day: 'Wednesday', period: 8, subjectCode: 'MUS', teacherEmpId: 'T014' },
    // Thursday
    { day: 'Thursday', period: 1, subjectCode: 'PHY', teacherEmpId: 'T003' },
    { day: 'Thursday', period: 2, subjectCode: 'MAT', teacherEmpId: 'T011' },
    { day: 'Thursday', period: 3, subjectCode: 'ENG', teacherEmpId: 'T012' },
    { day: 'Thursday', period: 4, subjectCode: 'CHEM', teacherEmpId: 'T005' },
    { day: 'Thursday', period: 5, subjectCode: 'SST', teacherEmpId: 'T008' },
    { day: 'Thursday', period: 6, subjectCode: 'HIN', teacherEmpId: 'T004' },
    { day: 'Thursday', period: 7, subjectCode: 'PE', teacherEmpId: 'T009' },
    { day: 'Thursday', period: 8, subjectCode: 'CS', teacherEmpId: 'T007' },
    // Friday
    { day: 'Friday', period: 1, subjectCode: 'MAT', teacherEmpId: 'T002' },
    { day: 'Friday', period: 2, subjectCode: 'BIO', teacherEmpId: 'T006' },
    { day: 'Friday', period: 3, subjectCode: 'ENG', teacherEmpId: 'T001' },
    { day: 'Friday', period: 4, subjectCode: 'PHY', teacherEmpId: 'T003' },
    { day: 'Friday', period: 5, subjectCode: 'ECS', teacherEmpId: 'T015' },
    { day: 'Friday', period: 6, subjectCode: 'HIN', teacherEmpId: 'T004' },
    { day: 'Friday', period: 7, subjectCode: 'ART', teacherEmpId: 'T010' },
    { day: 'Friday', period: 8, subjectCode: 'MUS', teacherEmpId: 'T014' },
  ]

  const subjectNames: Record<string, string> = {
    ENG: 'English', HIN: 'Hindi', MAT: 'Mathematics', SCI: 'Science', SST: 'Social Studies',
    CS: 'Computer Science', PHY: 'Physics', CHEM: 'Chemistry', BIO: 'Biology',
    ECS: 'Economics', PE: 'Physical Education', ART: 'Art', MUS: 'Music',
  }

  for (const slot of ttSlots) {
    const p = periods.find(pp => pp.period === slot.period)!
    await db.timetable.create({
      data: {
        sectionId: class10ASectionId,
        day: slot.day,
        period: slot.period,
        subjectId: subjects[slot.subjectCode],
        teacherId: teachers[slot.teacherEmpId].id,
        subjectName: subjectNames[slot.subjectCode],
        teacherName: teachers[slot.teacherEmpId].name,
        startTime: p.startTime,
        endTime: p.endTime,
        schoolId,
      },
    })
  }
  console.log(`    ✓ ${ttSlots.length} timetable entries created`)

  // ─── 15. HOMEWORK ─────────────────────────────────────────────
  console.log('  Creating homework...')
  const homeworkData = [
    { title: 'Complete Exercise 5.3', subjectName: 'Mathematics', sectionName: 'Section A', teacherName: teachers['T002'].name, dueDaysAhead: 3 },
    { title: 'Write an essay on "My Country"', subjectName: 'English', sectionName: 'Section A', teacherName: teachers['T001'].name, dueDaysAhead: 5 },
    { title: 'Read Chapter 8 and answer questions', subjectName: 'Science', sectionName: 'Section A', teacherName: teachers['T006'].name, dueDaysAhead: 4 },
    { title: 'Solve numerical problems from Chapter 4', subjectName: 'Physics', sectionName: 'Section A', teacherName: teachers['T003'].name, dueDaysAhead: 7 },
    { title: 'Write a letter to the editor', subjectName: 'Hindi', sectionName: 'Section A', teacherName: teachers['T004'].name, dueDaysAhead: 2 },
    { title: 'Complete the worksheet on Chemical Reactions', subjectName: 'Chemistry', sectionName: 'Section A', teacherName: teachers['T005'].name, dueDaysAhead: 6 },
    { title: 'Research project on Indian Freedom Struggle', subjectName: 'Social Studies', sectionName: 'Section A', teacherName: teachers['T008'].name, dueDaysAhead: 10 },
    { title: 'Write a Python program for factorial', subjectName: 'Computer Science', sectionName: 'Section A', teacherName: teachers['T007'].name, dueDaysAhead: 5 },
    { title: 'Diagram practice - Human Heart', subjectName: 'Biology', sectionName: 'Section A', teacherName: teachers['T006'].name, dueDaysAhead: 8 },
    { title: 'Prepare for class debate on Economics', subjectName: 'Economics', sectionName: 'Section A', teacherName: teachers['T015'].name, dueDaysAhead: 12 },
  ]

  for (const hw of homeworkData) {
    const dueDate = new Date(today)
    dueDate.setDate(dueDate.getDate() + hw.dueDaysAhead)
    await db.homework.create({
      data: {
        title: hw.title,
        description: `Complete the assigned task and submit before the due date.`,
        subjectName: hw.subjectName,
        sectionName: hw.sectionName,
        teacherName: hw.teacherName,
        dueDate,
        status: 'active',
        schoolId,
      },
    })
  }
  console.log(`    ✓ ${homeworkData.length} homework entries created`)

  // ─── 16. EVENTS ───────────────────────────────────────────────
  console.log('  Creating events...')
  const eventData = [
    {
      title: 'Annual Sports Day',
      description: 'Annual inter-house sports competition featuring athletics, team sports, and special performances.',
      date: new Date(today.getFullYear(), today.getMonth() + 1, 15),
      venue: 'School Ground',
      type: 'sports',
      status: 'upcoming',
    },
    {
      title: 'Republic Day Celebration',
      description: 'Flag hoisting ceremony, cultural programs, and patriotic song performances by students.',
      date: new Date(today.getFullYear() + (today.getMonth() >= 0 && today.getDate() > 26 ? 1 : 0), 0, 26),
      venue: 'School Auditorium',
      type: 'cultural',
      status: 'upcoming',
    },
    {
      title: 'Science Exhibition',
      description: 'Students showcase their science projects and working models. Judged by external experts.',
      date: (function () { const d = new Date(today); d.setDate(d.getDate() - 20); return d })(),
      venue: 'Science Block',
      type: 'academic',
      status: 'completed',
    },
    {
      title: 'Parent-Teacher Meeting',
      description: 'Mid-term parent-teacher meeting to discuss student progress and performance.',
      date: new Date(today.getFullYear(), today.getMonth() + 1, 5),
      venue: 'Respective Classrooms',
      type: 'meeting',
      status: 'upcoming',
    },
    {
      title: 'Diwali Celebration',
      description: 'Cultural program including rangoli competition, diya decoration, and sweets distribution.',
      date: new Date(2024, 10, 1),
      venue: 'School Auditorium',
      type: 'cultural',
      status: 'completed',
    },
  ]

  for (const ev of eventData) {
    await db.event.create({
      data: {
        title: ev.title,
        description: ev.description,
        date: ev.date,
        endDate: new Date(ev.date.getTime() + 8 * 60 * 60 * 1000), // +8 hours
        venue: ev.venue,
        type: ev.type,
        status: ev.status,
        schoolId,
      },
    })
  }
  console.log(`    ✓ ${eventData.length} events created`)

  // ─── 17. NOTIFICATIONS ────────────────────────────────────────
  console.log('  Creating notifications...')
  const notifications = [
    { title: 'Welcome Back!', message: 'New academic session 2024-25 has begun. Wishing all students a successful year ahead.', type: 'info', targetRole: 'all' },
    { title: 'Fee Payment Reminder', message: 'Parents are requested to pay the pending fees before the due date to avoid late fine charges.', type: 'warning', targetRole: 'parent' },
    { title: 'Unit Test Results Published', message: 'Results for Unit Test 1 have been published. Check the marks section for details.', type: 'success', targetRole: 'student' },
    { title: 'Staff Meeting', message: 'A mandatory staff meeting is scheduled for Saturday at 10:00 AM in the conference room.', type: 'alert', targetRole: 'teacher' },
    { title: 'Bus Route Changed', message: 'Route 3 has been diverted due to road construction. New route details available at the transport desk.', type: 'warning', targetRole: 'parent' },
    { title: 'Holiday Notice', message: 'School will remain closed on 26th January for Republic Day celebration.', type: 'info', targetRole: 'all' },
    { title: 'Sports Day Registration', message: 'Students interested in participating in Annual Sports Day must register with their PE teacher by Friday.', type: 'info', targetRole: 'student' },
    { title: 'Library Books Overdue', message: 'Several students have overdue library books. Please return them immediately to avoid penalties.', type: 'alert', targetRole: 'student' },
    { title: 'Maintenance Schedule', message: 'Water tank maintenance is scheduled for this weekend. Water supply may be disrupted.', type: 'warning', targetRole: 'staff' },
    { title: 'New Admission Enquiries', message: '15 new admission enquiries received this week. Follow-up action required.', type: 'info', targetRole: 'admin' },
  ]

  for (const n of notifications) {
    await db.notification.create({
      data: {
        title: n.title,
        message: n.message,
        type: n.type,
        targetRole: n.targetRole,
        isRead: Math.random() > 0.6,
        schoolId,
      },
    })
  }
  console.log(`    ✓ ${notifications.length} notifications created`)

  // ─── 18. LIBRARY BOOKS ────────────────────────────────────────
  console.log('  Creating library books...')
  const booksData = [
    { title: 'To Kill a Mockingbird', author: 'Harper Lee', category: 'Fiction', total: 5, available: 3 },
    { title: 'A Brief History of Time', author: 'Stephen Hawking', category: 'Science', total: 3, available: 2 },
    { title: 'NCERT Mathematics Class 10', author: 'NCERT', category: 'Mathematics', total: 20, available: 15 },
    { title: 'India After Gandhi', author: 'Ramachandra Guha', category: 'History', total: 4, available: 3 },
    { title: 'Wings of Fire', author: 'A.P.J. Abdul Kalam', category: 'Literature', total: 6, available: 4 },
    { title: 'The Story of My Experiments with Truth', author: 'M.K. Gandhi', category: 'Literature', total: 5, available: 5 },
    { title: 'Concepts of Physics Vol. 1', author: 'H.C. Verma', category: 'Science', total: 10, available: 7 },
    { title: 'Concepts of Physics Vol. 2', author: 'H.C. Verma', category: 'Science', total: 10, available: 8 },
    { title: 'Organic Chemistry', author: 'Morrison & Boyd', category: 'Science', total: 4, available: 2 },
    { title: 'NCERT Science Class 9', author: 'NCERT', category: 'Science', total: 25, available: 20 },
    { title: 'Pride and Prejudice', author: 'Jane Austen', category: 'Fiction', total: 3, available: 3 },
    { title: 'The Discovery of India', author: 'Jawaharlal Nehru', category: 'History', total: 4, available: 4 },
    { title: 'Higher Algebra', author: 'Hall & Knight', category: 'Mathematics', total: 6, available: 5 },
    { title: 'R.D. Sharma Mathematics Class 12', author: 'R.D. Sharma', category: 'Mathematics', total: 15, available: 10 },
    { title: 'Biology NCERT Class 11', author: 'NCERT', category: 'Science', total: 20, available: 18 },
    { title: 'Chhava', author: 'Shivaji Sawant', category: 'Literature', total: 3, available: 2 },
    { title: 'Merriam-Webster Dictionary', author: 'Merriam-Webster', category: 'Reference', total: 2, available: 2 },
    { title: 'Encyclopedia Britannica', author: 'Encyclopedia Britannica', category: 'Reference', total: 2, available: 1 },
    { title: 'The Alchemist', author: 'Paulo Coelho', category: 'Fiction', total: 4, available: 3 },
    { title: 'Three Men in a Boat', author: 'Jerome K. Jerome', category: 'Fiction', total: 5, available: 4 },
    { title: 'Modern Indian History', author: 'Spectrum Publications', category: 'History', total: 8, available: 6 },
    { title: 'Computer Science with Python', author: 'Sumita Arora', category: 'Science', total: 12, available: 9 },
  ]

  for (const book of booksData) {
    await db.libraryBook.create({
      data: {
        title: book.title,
        author: book.author,
        isbn: `ISBN-${Math.random().toString(36).substring(2, 15).toUpperCase()}`,
        category: book.category,
        totalCopies: book.total,
        availableCopies: book.available,
        schoolId,
      },
    })
  }
  console.log(`    ✓ ${booksData.length} library books created`)

  // ─── 19. VEHICLES ─────────────────────────────────────────────
  console.log('  Creating vehicles...')
  const vehiclesData = [
    { number: 'UK-07-AB-1234', type: 'Bus', capacity: 50, driverName: 'Ramu Singh', driverPhone: '+91-98760-10001', route: 'Civil Lines → IIT Campus → School' },
    { number: 'UK-07-CD-5678', type: 'Bus', capacity: 45, driverName: 'Mahesh Pal', driverPhone: '+91-98760-10002', route: 'Sadar Bazaar → Station Road → School' },
    { number: 'UK-07-EF-9012', type: 'Bus', capacity: 50, driverName: 'Kallu Driver', driverPhone: '+91-98760-10003', route: 'Laksar Road → Bhood Road → School' },
    { number: 'UK-07-GH-3456', type: 'Van', capacity: 15, driverName: 'Sunil Kumar', driverPhone: '+91-98760-10004', route: 'Shivpuri → Solanipuram → School' },
    { number: 'UK-07-IJ-7890', type: 'Bus', capacity: 50, driverName: 'Rajendra Prasad', driverPhone: '+91-98760-10005', route: 'Haridwar Road → Gangnahar → School' },
  ]

  for (const v of vehiclesData) {
    await db.vehicle.create({
      data: {
        number: v.number,
        type: v.type,
        capacity: v.capacity,
        driverName: v.driverName,
        driverPhone: v.driverPhone,
        route: v.route,
        schoolId,
        status: 'active',
      },
    })
  }
  console.log(`    ✓ ${vehiclesData.length} vehicles created`)

  // ─── 20. INCOME AND EXPENSE RECORDS ───────────────────────────
  console.log('  Creating income and expense records...')
  const incomeCategories = ['Fee Collection', 'Transport Fee', 'Donation', 'Other']
  const expenseCategories = ['Salary', 'Maintenance', 'Utilities', 'Supplies', 'Transport', 'Events']

  for (let m = 5; m >= 0; m--) {
    const monthDate = new Date(today)
    monthDate.setMonth(monthDate.getMonth() - m)
    monthDate.setDate(1)

    // 2-3 income records per month
    const incomeCount = 2 + Math.floor(Math.random() * 2)
    for (let i = 0; i < incomeCount; i++) {
      const day = Math.floor(Math.random() * 28) + 1
      const date = new Date(monthDate)
      date.setDate(day)
      const category = randomFrom(incomeCategories)
      let amount: number
      let description: string
      switch (category) {
        case 'Fee Collection':
          amount = 150000 + Math.random() * 200000
          description = `Fee collection for ${date.toLocaleString('en-IN', { month: 'long' })}`
          break
        case 'Transport Fee':
          amount = 40000 + Math.random() * 30000
          description = `Transport fee collection for ${date.toLocaleString('en-IN', { month: 'long' })}`
          break
        case 'Donation':
          amount = 5000 + Math.random() * 25000
          description = 'Donation received from alumni association'
          break
        default:
          amount = 2000 + Math.random() * 10000
          description = 'Miscellaneous income'
      }
      await db.income.create({
        data: { category, description, amount: Math.round(amount), date, schoolId },
      })
    }

    // 3-4 expense records per month
    const expenseCount = 3 + Math.floor(Math.random() * 2)
    for (let i = 0; i < expenseCount; i++) {
      const day = Math.floor(Math.random() * 28) + 1
      const date = new Date(monthDate)
      date.setDate(day)
      const category = randomFrom(expenseCategories)
      let amount: number
      let description: string
      switch (category) {
        case 'Salary':
          amount = 800000 + Math.random() * 200000
          description = `Staff salary disbursement for ${date.toLocaleString('en-IN', { month: 'long' })}`
          break
        case 'Maintenance':
          amount = 10000 + Math.random() * 40000
          description = 'Building and infrastructure maintenance'
          break
        case 'Utilities':
          amount = 20000 + Math.random() * 30000
          description = 'Electricity and water bills'
          break
        case 'Supplies':
          amount = 5000 + Math.random() * 20000
          description = 'Office and classroom supplies'
          break
        case 'Transport':
          amount = 30000 + Math.random() * 20000
          description = 'Vehicle fuel and maintenance'
          break
        default:
          amount = 10000 + Math.random() * 30000
          description = 'Event organization expenses'
      }
      await db.expense.create({
        data: { category, description, amount: Math.round(amount), date, schoolId },
      })
    }
  }
  console.log(`    ✓ Income and expense records created`)

  // ─── 21. STAFF MEMBERS ────────────────────────────────────────
  console.log('  Creating staff members...')
  const staffData = [
    { employeeId: 'S001', firstName: 'Ramesh', lastName: 'Chauhan', department: 'Administration', designation: 'Office Manager', salary: 35000, phone: '+91-98760-20001' },
    { employeeId: 'S002', firstName: 'Anjali', lastName: 'Sharma', department: 'Accounts', designation: 'Accountant', salary: 30000, phone: '+91-98760-20002' },
    { employeeId: 'S003', firstName: 'Babu', lastName: 'Lal', department: 'Library', designation: 'Librarian', salary: 25000, phone: '+91-98760-20003' },
    { employeeId: 'S004', firstName: 'Om', lastName: 'Prakash', department: 'Transport', designation: 'Transport Manager', salary: 28000, phone: '+91-98760-20004' },
    { employeeId: 'S005', firstName: 'Raju', lastName: 'Kumar', department: 'Maintenance', designation: 'Maintenance Supervisor', salary: 22000, phone: '+91-98760-20005' },
    { employeeId: 'S006', firstName: 'Bhairon', lastName: 'Singh', department: 'Security', designation: 'Security Guard', salary: 18000, phone: '+91-98760-20006' },
    { employeeId: 'S007', firstName: 'Sunita', lastName: 'Devi', department: 'Administration', designation: 'Receptionist', salary: 20000, phone: '+91-98760-20007' },
    { employeeId: 'S008', firstName: 'Deepak', lastName: 'Rawat', department: 'Maintenance', designation: 'Electrician', salary: 22000, phone: '+91-98760-20008' },
  ]

  for (const s of staffData) {
    await db.staff.create({
      data: {
        employeeId: s.employeeId,
        firstName: s.firstName,
        lastName: s.lastName,
        email: `${s.firstName.toLowerCase()}.${s.lastName.toLowerCase()}@dpsroorkee.com`,
        phone: s.phone,
        department: s.department,
        designation: s.designation,
        salary: s.salary,
        schoolId,
        status: 'active',
      },
    })
  }
  console.log(`    ✓ ${staffData.length} staff members created`)

  // ─── 22. LESSON PLANS ─────────────────────────────────────────
  console.log('  Creating lesson plans...')
  const lessonPlansData = [
    {
      teacherId: teachers['T003'].id, subjectName: 'Physics', sectionName: 'Section A',
      title: 'Laws of Motion - Newton\'s Three Laws',
      content: 'Introduction to Newton\'s Laws of Motion. Topics: First Law (Inertia), Second Law (F=ma), Third Law (Action-Reaction). Include demonstrations and numerical problems.',
      date: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1), status: 'published',
    },
    {
      teacherId: teachers['T002'].id, subjectName: 'Mathematics', sectionName: 'Section A',
      title: 'Quadratic Equations - Factorization Method',
      content: 'Solving quadratic equations by factorization. Practice problems with varying difficulty levels. Introduction to discriminant.',
      date: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 2), status: 'published',
    },
    {
      teacherId: teachers['T001'].id, subjectName: 'English', sectionName: 'Section A',
      title: 'Shakespeare - Julius Caesar (Act 1)',
      content: 'Reading and analysis of Act 1 of Julius Caesar. Character study, themes of ambition and loyalty. Group discussion activity.',
      date: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 3), status: 'draft',
    },
    {
      teacherId: teachers['T005'].id, subjectName: 'Chemistry', sectionName: 'Section A',
      title: 'Periodic Table - Trends and Properties',
      content: 'Understanding periodic trends: atomic radius, ionization energy, electron affinity, electronegativity. Practice with worksheet.',
      date: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 4), status: 'published',
    },
    {
      teacherId: teachers['T008'].id, subjectName: 'Social Studies', sectionName: 'Section A',
      title: 'Indian Democracy - Fundamental Rights',
      content: 'Overview of Fundamental Rights guaranteed by the Indian Constitution. Case studies and discussion on right to equality, freedom, and constitutional remedies.',
      date: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 5), status: 'draft',
    },
  ]

  for (const lp of lessonPlansData) {
    await db.lessonPlan.create({
      data: {
        teacherId: lp.teacherId,
        subjectName: lp.subjectName,
        sectionName: lp.sectionName,
        title: lp.title,
        content: lp.content,
        date: lp.date,
        status: lp.status,
        schoolId,
      },
    })
  }
  console.log(`    ✓ ${lessonPlansData.length} lesson plans created`)

  // ─── 23. ENQUIRIES ────────────────────────────────────────────
  console.log('  Creating enquiries...')
  const enquiriesData = [
    { parentName: 'Amit Bansal', studentName: 'Aarav Bansal', phone: '+91-99880-10001', email: 'amit.bansal@email.com', classApplied: 'Class 3', message: 'Would like to know about the admission process for Class 3 for the next academic session.', status: 'new' },
    { parentName: 'Swati Goel', studentName: 'Anika Goel', phone: '+91-99880-10002', email: 'swati.goel@email.com', classApplied: 'Class 6', message: 'Already submitted the form. Following up on the admission status.', status: 'contacted' },
    { parentName: 'Deepak Khandelwal', studentName: 'Vihaan Khandelwal', phone: '+91-99880-10003', email: 'deepak.k@email.com', classApplied: 'Class 1', message: 'My son is currently in KG at ABC School. Want to transfer him to DPS.', status: 'admitted' },
    { parentName: 'Nisha Saxena', studentName: 'Aadya Saxena', phone: '+91-99880-10004', email: 'nisha.saxena@email.com', classApplied: 'Class 8', message: 'Seeking admission in Class 8. Currently studying in Delhi.', status: 'contacted' },
    { parentName: 'Rohit Mehta', studentName: 'Arjun Mehta', phone: '+91-99880-10005', email: 'rohit.mehta@email.com', classApplied: 'Class 11', message: 'Enquiring about Science stream availability and admission criteria.', status: 'new' },
  ]

  for (const eq of enquiriesData) {
    await db.enquiry.create({
      data: {
        parentName: eq.parentName,
        studentName: eq.studentName,
        phone: eq.phone,
        email: eq.email,
        classApplied: eq.classApplied,
        message: eq.message,
        status: eq.status,
        schoolId,
      },
    })
  }
  console.log(`    ✓ ${enquiriesData.length} enquiries created`)

  console.log('')
  console.log('✅ Seeding completed successfully!')
  console.log(`   School: ${school.name}`)
  console.log(`   Classes: 12 | Sections: 24 | Subjects: 13`)
  console.log(`   Teachers: 15 | Staff: 8 | Students: 80`)
  console.log(`   Timetable entries: ${ttSlots.length} | Homework: ${homeworkData.length}`)
  console.log(`   Events: ${eventData.length} | Notifications: ${notifications.length}`)
  console.log(`   Library Books: ${booksData.length} | Vehicles: ${vehiclesData.length}`)
  console.log(`   Lesson Plans: ${lessonPlansData.length} | Enquiries: ${enquiriesData.length}`)
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:')
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })