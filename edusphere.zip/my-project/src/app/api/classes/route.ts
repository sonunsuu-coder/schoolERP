import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const classes = await db.class.findMany({
      orderBy: { numericLevel: 'asc' },
      include: {
        sections: {
          orderBy: { name: 'asc' },
        },
      },
    })

    return NextResponse.json({ data: classes })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch classes' }, { status: 500 })
  }
}