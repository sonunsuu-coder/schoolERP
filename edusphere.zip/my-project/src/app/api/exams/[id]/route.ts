import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const exam = await db.exam.findUnique({
      where: { id },
      include: {
        section: { select: { id: true, name: true, class: { select: { name: true } } } },
        marks: {
          include: {
            student: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                admissionNo: true,
                rollNumber: true,
              },
            },
          },
          orderBy: { marksObtained: 'desc' },
        },
      },
    })

    if (!exam) {
      return NextResponse.json({ error: 'Exam not found' }, { status: 404 })
    }

    return NextResponse.json({ data: exam })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch exam' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()

    const exam = await db.exam.update({
      where: { id },
      data: {
        name: body.name,
        type: body.type,
        startDate: body.startDate ? new Date(body.startDate) : undefined,
        endDate: body.endDate ? new Date(body.endDate) : undefined,
        subjectName: body.subjectName,
        sectionName: body.sectionName,
        maxMarks: body.maxMarks,
        className: body.className,
        status: body.status,
      },
    })

    return NextResponse.json({ data: exam })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to update exam' }, { status: 500 })
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { marks: marksArray } = body

    if (!Array.isArray(marksArray)) {
      return NextResponse.json(
        { error: 'marks array is required' },
        { status: 400 }
      )
    }

    const exam = await db.exam.findUnique({ where: { id } })
    if (!exam) {
      return NextResponse.json({ error: 'Exam not found' }, { status: 404 })
    }

    const results: Awaited<ReturnType<typeof db.mark.upsert>>[] = []
    for (const mark of marksArray) {
      const { studentId, marksObtained, grade, remarks } = mark

      // Calculate grade if not provided
      const calculatedGrade =
        grade ??
        (marksObtained >= 90
          ? 'A+'
          : marksObtained >= 80
            ? 'A'
            : marksObtained >= 70
              ? 'B+'
              : marksObtained >= 60
                ? 'B'
                : marksObtained >= 50
                  ? 'C'
                  : marksObtained >= 40
                    ? 'D'
                    : 'F')

      const result = await db.mark.upsert({
        where: {
          studentId_examId: { studentId, examId: id },
        },
        create: {
          studentId,
          examId: id,
          marksObtained,
          grade: calculatedGrade,
          remarks,
          studentName: mark.studentName,
        },
        update: {
          marksObtained,
          grade: calculatedGrade,
          remarks,
          studentName: mark.studentName,
        },
      })
      results.push(result)
    }

    return NextResponse.json({ data: results }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to submit marks' }, { status: 500 })
  }
}