import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const type = searchParams.get('type')
    const status = searchParams.get('status')
    const classId = searchParams.get('classId')
    const sectionId = searchParams.get('sectionId')

    const where: Record<string, unknown> = {}

    if (type) where.type = type
    if (status) where.status = status
    if (sectionId) where.sectionId = sectionId
    if (classId) {
      const sections = await db.section.findMany({
        where: { classId },
        select: { id: true },
      })
      where.sectionId = { in: sections.map((s) => s.id) }
    }

    const exams = await db.exam.findMany({
      where,
      include: {
        section: { select: { id: true, name: true, class: { select: { name: true } } } },
        _count: { select: { marks: true } },
      },
      orderBy: { startDate: 'desc' },
    })

    return NextResponse.json({ data: exams })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch exams' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const exam = await db.exam.create({
      data: {
        name: body.name,
        type: body.type,
        startDate: new Date(body.startDate),
        endDate: new Date(body.endDate),
        schoolId: body.schoolId,
        subjectName: body.subjectName,
        sectionId: body.sectionId,
        sectionName: body.sectionName,
        maxMarks: body.maxMarks ?? 100,
        className: body.className,
        status: body.status ?? 'upcoming',
      },
    })

    return NextResponse.json({ data: exam }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to create exam' }, { status: 500 })
  }
}