import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const department = searchParams.get('department')
    const status = searchParams.get('status')

    const where: Record<string, unknown> = {}
    if (department) where.department = department
    if (status) where.status = status

    const staff = await db.staff.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ data: staff })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch staff' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const staff = await db.staff.create({
      data: {
        employeeId: body.employeeId,
        firstName: body.firstName,
        lastName: body.lastName,
        email: body.email,
        phone: body.phone,
        department: body.department,
        designation: body.designation,
        salary: body.salary,
        schoolId: body.schoolId,
        status: body.status ?? 'active',
      },
    })

    return NextResponse.json({ data: staff }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to add staff' }, { status: 500 })
  }
}