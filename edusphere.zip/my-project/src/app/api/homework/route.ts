import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const sectionId = searchParams.get('sectionId')
    const status = searchParams.get('status')

    const where: Record<string, unknown> = {}
    if (sectionId) where.sectionName = sectionId
    if (status) where.status = status

    const homework = await db.homework.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ data: homework })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch homework' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const homework = await db.homework.create({
      data: {
        title: body.title,
        description: body.description,
        subjectName: body.subjectName,
        sectionName: body.sectionName,
        teacherName: body.teacherName,
        dueDate: new Date(body.dueDate),
        schoolId: body.schoolId,
        status: body.status ?? 'active',
      },
    })

    return NextResponse.json({ data: homework }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to create homework' }, { status: 500 })
  }
}