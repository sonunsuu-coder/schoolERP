import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { feeRecordId, amount, method, transactionId, schoolId } = body

    if (!feeRecordId || !amount || !method) {
      return NextResponse.json(
        { error: 'feeRecordId, amount, and method are required' },
        { status: 400 }
      )
    }

    // Get the fee record
    const feeRecord = await db.feeRecord.findUnique({
      where: { id: feeRecordId },
    })

    if (!feeRecord) {
      return NextResponse.json({ error: 'Fee record not found' }, { status: 404 })
    }

    const newPaidAmount = feeRecord.paidAmount + amount
    const newStatus = newPaidAmount >= feeRecord.amount ? 'paid' : 'partial'

    // Update fee record
    const updatedFeeRecord = await db.feeRecord.update({
      where: { id: feeRecordId },
      data: {
        paidAmount: newPaidAmount,
        paidDate: newStatus === 'paid' ? new Date() : feeRecord.paidDate,
        status: newStatus,
      },
    })

    // Create payment record
    const payment = await db.payment.create({
      data: {
        feeRecordId,
        amount,
        method,
        transactionId,
        schoolId: schoolId || feeRecord.schoolId,
      },
    })

    return NextResponse.json({
      data: { feeRecord: updatedFeeRecord, payment },
    }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to collect fee' }, { status: 500 })
  }
}