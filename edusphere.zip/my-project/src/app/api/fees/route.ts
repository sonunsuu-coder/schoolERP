import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const status = searchParams.get('status')
    const studentId = searchParams.get('studentId')
    const classId = searchParams.get('classId')

    const where: Record<string, unknown> = {}

    if (status) where.status = status
    if (studentId) where.studentId = studentId
    if (classId) {
      // Find students in this class and filter fee records
      const studentsInClass = await db.student.findMany({
        where: { classId, status: 'active' },
        select: { id: true },
      })
      where.studentId = { in: studentsInClass.map((s) => s.id) }
    }

    const feeRecords = await db.feeRecord.findMany({
      where,
      include: {
        student: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            admissionNo: true,
            className: true,
            sectionName: true,
          },
        },
        feeStructure: {
          select: { name: true, type: true, frequency: true },
        },
        payment: true,
      },
      orderBy: { dueDate: 'desc' },
    })

    return NextResponse.json({ data: feeRecords })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch fee records' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const feeRecord = await db.feeRecord.create({
      data: {
        studentId: body.studentId,
        feeStructureId: body.feeStructureId,
        feeName: body.feeName,
        studentName: body.studentName,
        amount: body.amount,
        dueDate: new Date(body.dueDate),
        schoolId: body.schoolId,
        lateFine: body.lateFine ?? 0,
        discount: body.discount ?? 0,
      },
    })

    return NextResponse.json({ data: feeRecord }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to create fee record' }, { status: 500 })
  }
}