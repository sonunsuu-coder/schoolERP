import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const feeStructures = await db.feeStructure.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        _count: { select: { feeRecords: true } },
      },
    })

    return NextResponse.json({ data: feeStructures })
  } catch (error) {
    console.error(error)
    return NextResponse.json(
      { error: 'Failed to fetch fee structures' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, amount, frequency, type, className, schoolId, status } = body

    if (!name || !amount || !schoolId) {
      return NextResponse.json(
        { error: 'name, amount, and schoolId are required' },
        { status: 400 }
      )
    }

    const feeStructure = await db.feeStructure.create({
      data: {
        name,
        amount: Number(amount),
        frequency: frequency || 'monthly',
        type: type || 'tuition',
        className: className || null,
        schoolId,
        status: status || 'active',
      },
    })

    return NextResponse.json({ data: feeStructure }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json(
      { error: 'Failed to create fee structure' },
      { status: 500 }
    )
  }
}