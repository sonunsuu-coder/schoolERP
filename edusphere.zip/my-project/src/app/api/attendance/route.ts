import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const date = searchParams.get('date')
    const classId = searchParams.get('classId')
    const sectionId = searchParams.get('sectionId')
    const studentId = searchParams.get('studentId')
    const from = searchParams.get('from')
    const to = searchParams.get('to')

    // Individual student attendance history
    if (studentId && from && to) {
      const attendance = await db.attendance.findMany({
        where: {
          studentId,
          date: {
            gte: new Date(from),
            lte: new Date(to + 'T23:59:59.999Z'),
          },
        },
        orderBy: { date: 'desc' },
      })

      const totalDays = attendance.length
      const presentDays = attendance.filter((a) => a.status === 'present').length

      return NextResponse.json({
        data: attendance,
        summary: {
          totalDays,
          presentDays,
          absentDays: totalDays - presentDays,
          percentage: totalDays > 0
            ? Math.round((presentDays / totalDays) * 100)
            : 0,
        },
      })
    }

    // Attendance by date/class/section
    if (date) {
      const studentWhere: Record<string, unknown> = { status: 'active' }
      if (classId) studentWhere.classId = classId
      if (sectionId) studentWhere.sectionId = sectionId

      const students = await db.student.findMany({
        where: studentWhere,
        select: {
          id: true,
          firstName: true,
          lastName: true,
          admissionNo: true,
          rollNumber: true,
          class: { select: { name: true } },
          section: { select: { name: true } },
        },
        orderBy: { rollNumber: 'asc' },
      })

      const dateStart = new Date(date)
      const dateEnd = new Date(date + 'T23:59:59.999Z')

      const attendanceRecords = await db.attendance.findMany({
        where: {
          date: { gte: dateStart, lte: dateEnd },
          studentId: { in: students.map((s) => s.id) },
        },
      })

      const attendanceMap = new Map(
        attendanceRecords.map((r) => [r.studentId, r])
      )

      const result = students.map((s) => ({
        ...s,
        className: s.class?.name,
        sectionName: s.section?.name,
        attendance: attendanceMap.get(s.id) ?? null,
        status: attendanceMap.get(s.id)?.status ?? 'not_marked',
        remarks: attendanceMap.get(s.id)?.remarks ?? null,
      }))

      return NextResponse.json({ data: result, date })
    }

    // Default: return today's attendance if no params
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const todayStr = today.toISOString().split('T')[0]

    const todayAttendance = await db.attendance.findMany({
      where: {
        date: { gte: new Date(todayStr), lt: new Date(todayStr + 'T23:59:59.999Z') },
      },
      include: {
        student: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            admissionNo: true,
            rollNumber: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ data: todayAttendance })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch attendance' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { date, records } = body

    if (!date || !Array.isArray(records)) {
      return NextResponse.json(
        { error: 'date and records array are required' },
        { status: 400 }
      )
    }

    const results: Awaited<ReturnType<typeof db.attendance.upsert>>[] = []
    for (const record of records) {
      const { studentId, status, remarks } = record
      const result = await db.attendance.upsert({
        where: {
          studentId_date: {
            studentId,
            date: new Date(date),
          },
        },
        create: {
          studentId,
          date: new Date(date),
          status: status || 'present',
          remarks,
        },
        update: {
          status: status || 'present',
          remarks,
        },
      })
      results.push(result)
    }

    return NextResponse.json({ data: results }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to mark attendance' }, { status: 500 })
  }
}