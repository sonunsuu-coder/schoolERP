import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const type = searchParams.get('type') ?? 'attendance'

    if (type === 'attendance') {
      return await getAttendanceReport()
    } else if (type === 'fees') {
      return await getFeesReport()
    } else if (type === 'academic') {
      return await getAcademicReport()
    } else if (type === 'financial') {
      return await getFinancialReport()
    }

    return NextResponse.json({ error: 'Invalid report type' }, { status: 400 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to generate report' }, { status: 500 })
  }
}

async function getAttendanceReport() {
  // Monthly attendance by class
  const today = new Date()
  const sixMonthsAgo = new Date()
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)
  const sixMonthsAgoStr = sixMonthsAgo.toISOString().split('T')[0]

  const attendance = await db.attendance.findMany({
    where: { date: { gte: new Date(sixMonthsAgoStr) } },
    include: {
      student: {
        select: {
          classId: true,
          className: true,
        },
      },
    },
  })

  // Group by month and class
  const map: Record<string, Record<string, { total: number; present: number }>> = {}

  for (const a of attendance) {
    const month = a.date.toISOString().slice(0, 7)
    const className = a.student.className ?? 'Unassigned'

    if (!map[month]) map[month] = {}
    if (!map[month][className]) map[month][className] = { total: 0, present: 0 }

    map[month][className].total++
    if (a.status === 'present') {
      map[month][className].present++
    }
  }

  const monthlyByClass = Object.entries(map)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, classes]) => ({
      month,
      classes: Object.entries(classes).map(([className, data]) => ({
        className,
        total: data.total,
        present: data.present,
        percentage: data.total > 0
          ? Math.round((data.present / data.total) * 100)
          : 0,
      })),
    }))

  return NextResponse.json({ data: { type: 'attendance', monthlyByClass } })
}

async function getFeesReport() {
  // Fee collection by month
  const today = new Date()
  const sixMonthsAgo = new Date()
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)
  const sixMonthsAgoStr = sixMonthsAgo.toISOString().split('T')[0]

  const payments = await db.payment.findMany({
    where: { paidAt: { gte: new Date(sixMonthsAgoStr) } },
    select: { paidAt: true, amount: true },
  })

  const monthlyCollection: Record<string, number> = {}
  for (const p of payments) {
    const month = p.paidAt.toISOString().slice(0, 7)
    monthlyCollection[month] = (monthlyCollection[month] ?? 0) + p.amount
  }

  const collectionByMonth = Object.entries(monthlyCollection)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, amount]) => ({ month, amount }))

  // Outstanding by class
  const outstandingRecords = await db.feeRecord.findMany({
    where: { status: 'pending' },
    include: {
      student: { select: { className: true } },
    },
  })

  const outstandingByClass: Record<string, number> = {}
  for (const fr of outstandingRecords) {
    const className = fr.student.className ?? 'Unassigned'
    outstandingByClass[className] =
      (outstandingByClass[className] ?? 0) + (fr.amount - fr.paidAmount)
  }

  const outstandingList = Object.entries(outstandingByClass)
    .sort(([, a], [, b]) => b - a)
    .map(([className, amount]) => ({ className, amount }))

  return NextResponse.json({
    data: {
      type: 'fees',
      collectionByMonth,
      outstandingByClass: outstandingList,
      totalOutstanding: outstandingList.reduce((s, i) => s + i.amount, 0),
    },
  })
}

async function getAcademicReport() {
  // Average marks by subject
  const marks = await db.mark.findMany({
    include: {
      exam: {
        select: { subjectName: true, maxMarks: true },
      },
    },
  })

  const subjectMap: Record<string, { totalMarks: number; count: number; totalMax: number }> = {}

  for (const m of marks) {
    const subject = m.exam.subjectName
    if (!subjectMap[subject]) {
      subjectMap[subject] = { totalMarks: 0, count: 0, totalMax: 0 }
    }
    subjectMap[subject].totalMarks += m.marksObtained
    subjectMap[subject].count++
    subjectMap[subject].totalMax += m.exam.maxMarks
  }

  const averageBySubject = Object.entries(subjectMap).map(
    ([subject, data]) => ({
      subject,
      averageMarks: Math.round((data.totalMarks / data.count) * 100) / 100,
      maxMarks: data.totalMax / data.count,
      averagePercentage:
        data.totalMax > 0
          ? Math.round((data.totalMarks / data.totalMax) * 100)
          : 0,
      studentsCount: data.count,
    })
  )

  // Class performance
  const exams = await db.exam.findMany({
    include: {
      marks: true,
      section: {
        select: { name: true, class: { select: { name: true } } },
      },
    },
  })

  const classMap: Record<string, { totalMarks: number; count: number; totalMax: number }> = {}

  for (const exam of exams) {
    const className = exam.className ?? exam.section?.class?.name ?? 'Unassigned'
    if (!classMap[className]) {
      classMap[className] = { totalMarks: 0, count: 0, totalMax: 0 }
    }
    for (const mark of exam.marks) {
      classMap[className].totalMarks += mark.marksObtained
      classMap[className].count++
      classMap[className].totalMax += exam.maxMarks
    }
  }

  const classPerformance = Object.entries(classMap)
    .map(([className, data]) => ({
      className,
      averageMarks: data.count > 0
        ? Math.round((data.totalMarks / data.count) * 100) / 100
        : 0,
      averagePercentage:
        data.totalMax > 0
          ? Math.round((data.totalMarks / data.totalMax) * 100)
          : 0,
      totalEntries: data.count,
    }))
    .sort((a, b) => b.averagePercentage - a.averagePercentage)

  return NextResponse.json({
    data: { type: 'academic', averageBySubject, classPerformance },
  })
}

async function getFinancialReport() {
  const today = new Date()
  const sixMonthsAgo = new Date()
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)
  const sixMonthsAgoStr = sixMonthsAgo.toISOString().split('T')[0]

  const currentMonthStart = new Date(today.getFullYear(), today.getMonth(), 1)
  const currentMonthStartStr = currentMonthStart.toISOString().split('T')[0]

  const allIncome = await db.income.findMany({
    where: { date: { gte: new Date(sixMonthsAgoStr) } },
    select: { date: true, amount: true, category: true },
  })

  const allExpenses = await db.expense.findMany({
    where: { date: { gte: new Date(sixMonthsAgoStr) } },
    select: { date: true, amount: true, category: true },
  })

  // Income vs Expense monthly
  const monthlyIncomeMap: Record<string, number> = {}
  const monthlyExpenseMap: Record<string, number> = {}

  for (const i of allIncome) {
    const month = i.date.toISOString().slice(0, 7)
    monthlyIncomeMap[month] = (monthlyIncomeMap[month] ?? 0) + i.amount
  }

  for (const e of allExpenses) {
    const month = e.date.toISOString().slice(0, 7)
    monthlyExpenseMap[month] = (monthlyExpenseMap[month] ?? 0) + e.amount
  }

  const allMonths = new Set([...Object.keys(monthlyIncomeMap), ...Object.keys(monthlyExpenseMap)])
  const incomeVsExpense = Array.from(allMonths)
    .sort()
    .map((month) => ({
      month,
      income: monthlyIncomeMap[month] ?? 0,
      expense: monthlyExpenseMap[month] ?? 0,
      net: (monthlyIncomeMap[month] ?? 0) - (monthlyExpenseMap[month] ?? 0),
    }))

  // This month totals
  const thisMonthIncome = allIncome
    .filter((i) => i.date >= new Date(currentMonthStartStr))
    .reduce((sum, i) => sum + i.amount, 0)

  const thisMonthExpense = allExpenses
    .filter((e) => e.date >= new Date(currentMonthStartStr))
    .reduce((sum, e) => sum + e.amount, 0)

  // Total income and expense
  const totalIncome = allIncome.reduce((sum, i) => sum + i.amount, 0)
  const totalExpense = allExpenses.reduce((sum, e) => sum + e.amount, 0)

  // Expense breakdown by category
  const expenseByCategory: Record<string, number> = {}
  for (const e of allExpenses) {
    expenseByCategory[e.category] = (expenseByCategory[e.category] ?? 0) + e.amount
  }

  const expenseBreakdown = Object.entries(expenseByCategory)
    .sort(([, a], [, b]) => b - a)
    .map(([category, amount]) => ({ category, amount }))

  // Income breakdown by category
  const incomeByCategory: Record<string, number> = {}
  for (const i of allIncome) {
    incomeByCategory[i.category] = (incomeByCategory[i.category] ?? 0) + i.amount
  }

  const incomeBreakdown = Object.entries(incomeByCategory)
    .sort(([, a], [, b]) => b - a)
    .map(([category, amount]) => ({ category, amount }))

  // P&L summary
  const plSummary = {
    totalIncome,
    totalExpense,
    netProfit: totalIncome - totalExpense,
    profitMargin: totalIncome > 0
      ? Math.round(((totalIncome - totalExpense) / totalIncome) * 100)
      : 0,
    thisMonthIncome,
    thisMonthExpense,
    thisMonthNet: thisMonthIncome - thisMonthExpense,
  }

  return NextResponse.json({
    data: {
      type: 'financial',
      incomeVsExpense,
      plSummary,
      expenseBreakdown,
      incomeBreakdown,
    },
  })
}