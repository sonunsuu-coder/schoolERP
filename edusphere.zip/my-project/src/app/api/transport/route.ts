import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const vehicles = await db.vehicle.findMany({
      orderBy: { number: 'asc' },
    })

    return NextResponse.json({ data: vehicles })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch vehicles' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const vehicle = await db.vehicle.create({
      data: {
        number: body.number,
        type: body.type,
        capacity: body.capacity,
        driverName: body.driverName,
        driverPhone: body.driverPhone,
        route: body.route,
        schoolId: body.schoolId,
        status: body.status ?? 'active',
      },
    })

    return NextResponse.json({ data: vehicle }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to add vehicle' }, { status: 500 })
  }
}