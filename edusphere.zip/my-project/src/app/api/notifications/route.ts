import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const type = searchParams.get('type')
    const isRead = searchParams.get('isRead')

    const where: Record<string, unknown> = {}
    if (type) where.type = type
    if (isRead !== null && isRead !== undefined) {
      where.isRead = isRead === 'true'
    }

    const notifications = await db.notification.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ data: notifications })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch notifications' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { ids } = body

    if (!Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json(
        { error: 'ids array is required' },
        { status: 400 }
      )
    }

    await db.notification.updateMany({
      where: { id: { in: ids } },
      data: { isRead: true },
    })

    return NextResponse.json({ data: { updated: ids.length } })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to update notifications' }, { status: 500 })
  }
}