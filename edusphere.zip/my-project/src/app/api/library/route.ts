import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const category = searchParams.get('category')
    const search = searchParams.get('search')

    const where: Record<string, unknown> = {}

    if (category) where.category = category
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { author: { contains: search } },
        { isbn: { contains: search } },
      ]
    }

    const books = await db.libraryBook.findMany({
      where,
      orderBy: { title: 'asc' },
    })

    return NextResponse.json({ data: books })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch library books' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const book = await db.libraryBook.create({
      data: {
        title: body.title,
        author: body.author,
        isbn: body.isbn,
        category: body.category,
        totalCopies: body.totalCopies,
        availableCopies: body.availableCopies ?? body.totalCopies,
        schoolId: body.schoolId,
      },
    })

    return NextResponse.json({ data: book }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to add book' }, { status: 500 })
  }
}