import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const todayStr = today.toISOString().split('T')[0]

    // 6 months ago
    const sixMonthsAgo = new Date()
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)
    const sixMonthsAgoStr = sixMonthsAgo.toISOString().split('T')[0]

    // Current month start
    const currentMonthStart = new Date(today.getFullYear(), today.getMonth(), 1)
    const currentMonthStartStr = currentMonthStart.toISOString().split('T')[0]

    // Total students (active)
    const totalStudents = await db.student.count({ where: { status: 'active' } })

    // Total teachers (active)
    const totalTeachers = await db.teacher.count({ where: { status: 'active' } })

    // Total staff (active)
    const totalStaff = await db.staff.count({ where: { status: 'active' } })

    // Today's attendance percentage
    const todayAttendance = await db.attendance.findMany({
      where: {
        date: { gte: new Date(todayStr), lt: new Date(todayStr + 'T23:59:59.999Z') },
      },
    })
    const presentToday = todayAttendance.filter((a) => a.status === 'present').length
    const todayAttendancePercentage = totalStudents > 0
      ? Math.round((presentToday / totalStudents) * 100)
      : 0

    // Fee collection summary
    const feeRecords = await db.feeRecord.findMany({
      include: { payment: true },
      where: {
        payment: { paidAt: { gte: new Date(currentMonthStartStr) } },
      },
    })
    const collectedThisMonth = feeRecords.reduce((sum, fr) => sum + (fr.payment?.amount ?? 0), 0)

    const outstandingRecords = await db.feeRecord.findMany({
      where: { status: 'pending' },
    })
    const outstandingAmount = outstandingRecords.reduce((sum, fr) => sum + (fr.amount - fr.paidAmount), 0)

    // Upcoming events (next 5)
    const upcomingEvents = await db.event.findMany({
      where: { date: { gte: new Date(todayStr) } },
      orderBy: { date: 'asc' },
      take: 5,
    })

    // Recent notifications (last 10)
    const recentNotifications = await db.notification.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10,
    })

    // Monthly attendance trend (last 6 months)
    const allAttendance = await db.attendance.findMany({
      where: {
        date: { gte: new Date(sixMonthsAgoStr) },
      },
      select: { date: true, status: true },
    })

    const monthlyAttendanceMap: Record<string, { total: number; present: number }> = {}
    for (const a of allAttendance) {
      const monthKey = a.date.toISOString().slice(0, 7) // YYYY-MM
      if (!monthlyAttendanceMap[monthKey]) {
        monthlyAttendanceMap[monthKey] = { total: 0, present: 0 }
      }
      monthlyAttendanceMap[monthKey].total++
      if (a.status === 'present') {
        monthlyAttendanceMap[monthKey].present++
      }
    }
    const monthlyAttendanceTrend = Object.entries(monthlyAttendanceMap)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, data]) => ({
        month,
        percentage: data.total > 0 ? Math.round((data.present / data.total) * 100) : 0,
        total: data.total,
        present: data.present,
      }))

    // Fee collection trend (last 6 months)
    const allPayments = await db.payment.findMany({
      where: { paidAt: { gte: new Date(sixMonthsAgoStr) } },
      select: { paidAt: true, amount: true },
    })

    const monthlyFeeMap: Record<string, number> = {}
    for (const p of allPayments) {
      const monthKey = p.paidAt.toISOString().slice(0, 7)
      monthlyFeeMap[monthKey] = (monthlyFeeMap[monthKey] ?? 0) + p.amount
    }
    const feeCollectionTrend = Object.entries(monthlyFeeMap)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, amount]) => ({ month, amount }))

    // Gender distribution
    const maleCount = await db.student.count({ where: { gender: 'male', status: 'active' } })
    const femaleCount = await db.student.count({ where: { gender: 'female', status: 'active' } })
    const otherCount = totalStudents - maleCount - femaleCount
    const genderDistribution = [
      { gender: 'Male', count: maleCount },
      { gender: 'Female', count: femaleCount },
      { gender: 'Other', count: Math.max(otherCount, 0) },
    ]

    // Class-wise enrollment
    const classEnrollment = await db.class.findMany({
      include: {
        _count: { select: { students: { where: { status: 'active' } } } },
      },
      orderBy: { numericLevel: 'asc' },
    })
    const classWiseEnrollment = classEnrollment.map((c) => ({
      className: c.name,
      count: c._count.students,
    }))

    // Revenue vs expense (last 6 months)
    const allIncome = await db.income.findMany({
      where: { date: { gte: new Date(sixMonthsAgoStr) } },
      select: { date: true, amount: true },
    })
    const allExpenses = await db.expense.findMany({
      where: { date: { gte: new Date(sixMonthsAgoStr) } },
      select: { date: true, amount: true },
    })

    const monthlyRevenueMap: Record<string, number> = {}
    const monthlyExpenseMap: Record<string, number> = {}
    for (const i of allIncome) {
      const monthKey = i.date.toISOString().slice(0, 7)
      monthlyRevenueMap[monthKey] = (monthlyRevenueMap[monthKey] ?? 0) + i.amount
    }
    for (const e of allExpenses) {
      const monthKey = e.date.toISOString().slice(0, 7)
      monthlyExpenseMap[monthKey] = (monthlyExpenseMap[monthKey] ?? 0) + e.amount
    }

    const allMonths = new Set([...Object.keys(monthlyRevenueMap), ...Object.keys(monthlyExpenseMap)])
    const revenueVsExpense = Array.from(allMonths)
      .sort()
      .map((month) => ({
        month,
        revenue: monthlyRevenueMap[month] ?? 0,
        expense: monthlyExpenseMap[month] ?? 0,
      }))

    return NextResponse.json({
      data: {
        totalStudents,
        totalTeachers,
        totalStaff,
        todayAttendancePercentage,
        feeCollection: {
          collectedThisMonth,
          outstandingAmount,
        },
        upcomingEvents,
        recentNotifications,
        monthlyAttendanceTrend,
        feeCollectionTrend,
        genderDistribution,
        classWiseEnrollment,
        revenueVsExpense,
      },
    })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch dashboard data' }, { status: 500 })
  }
}