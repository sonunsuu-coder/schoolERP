import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const sectionId = searchParams.get('sectionId')

    if (!sectionId) {
      return NextResponse.json(
        { error: 'sectionId is required' },
        { status: 400 }
      )
    }

    const timetable = await db.timetable.findMany({
      where: { sectionId },
      include: {
        subject: { select: { id: true, name: true, code: true } },
        teacher: { select: { id: true, firstName: true, lastName: true } },
      },
      orderBy: [{ day: 'asc' }, { period: 'asc' }],
    })

    // Group by day
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    const groupedByDay: Record<string, typeof timetable> = {}

    for (const day of days) {
      groupedByDay[day] = timetable.filter((t) => t.day === day)
    }

    // Add any days not in the standard list
    for (const entry of timetable) {
      if (!groupedByDay[entry.day]) {
        groupedByDay[entry.day] = timetable.filter((t) => t.day === entry.day)
      }
    }

    return NextResponse.json({ data: groupedByDay })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch timetable' }, { status: 500 })
  }
}