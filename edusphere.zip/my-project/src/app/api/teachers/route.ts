import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const teachers = await db.teacher.findMany({
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ data: teachers })
  } catch (error) {
    console.error(error)
    return NextResponse.json(
      { error: 'Failed to fetch teachers' },
      { status: 500 }
    )
  }
}
