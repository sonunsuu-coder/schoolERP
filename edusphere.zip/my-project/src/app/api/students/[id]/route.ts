import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const student = await db.student.findUnique({
      where: { id },
      include: {
        class: { select: { id: true, name: true } },
        section: { select: { id: true, name: true } },
      },
    })

    if (!student) {
      return NextResponse.json({ error: 'Student not found' }, { status: 404 })
    }

    // Attendance summary
    const totalAttendance = await db.attendance.count({ where: { studentId: id } })
    const presentAttendance = await db.attendance.count({
      where: { studentId: id, status: 'present' },
    })
    const attendanceSummary = {
      totalDays: totalAttendance,
      presentDays: presentAttendance,
      absentDays: totalAttendance - presentAttendance,
      percentage: totalAttendance > 0
        ? Math.round((presentAttendance / totalAttendance) * 100)
        : 0,
    }

    // Fee summary
    const feeRecords = await db.feeRecord.findMany({
      where: { studentId: id },
      include: { payment: true },
    })
    const totalFees = feeRecords.reduce((sum, fr) => sum + fr.amount, 0)
    const totalPaid = feeRecords.reduce((sum, fr) => sum + fr.paidAmount, 0)
    const feeSummary = {
      totalFees,
      totalPaid,
      outstanding: totalFees - totalPaid,
      paidRecords: feeRecords.filter((fr) => fr.status === 'paid').length,
      pendingRecords: feeRecords.filter((fr) => fr.status === 'pending').length,
    }

    return NextResponse.json({
      data: { ...student, attendanceSummary, feeSummary },
    })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch student' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()

    const student = await db.student.update({
      where: { id },
      data: {
        rollNumber: body.rollNumber,
        firstName: body.firstName,
        lastName: body.lastName,
        dob: body.dob ? new Date(body.dob) : undefined,
        gender: body.gender,
        bloodGroup: body.bloodGroup,
        religion: body.religion,
        category: body.category,
        address: body.address,
        phone: body.phone,
        email: body.email,
        avatar: body.avatar,
        fatherName: body.fatherName,
        fatherPhone: body.fatherPhone,
        fatherOccupation: body.fatherOccupation,
        motherName: body.motherName,
        motherPhone: body.motherPhone,
        motherOccupation: body.motherOccupation,
        guardianName: body.guardianName,
        guardianPhone: body.guardianPhone,
        guardianRelation: body.guardianRelation,
        medicalHistory: body.medicalHistory,
        allergies: body.allergies,
        classId: body.classId,
        sectionId: body.sectionId,
        className: body.className,
        sectionName: body.sectionName,
        status: body.status,
      },
    })

    return NextResponse.json({ data: student })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to update student' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    await db.student.update({
      where: { id },
      data: { status: 'inactive' },
    })

    return NextResponse.json({ data: { id, status: 'inactive' } })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to delete student' }, { status: 500 })
  }
}