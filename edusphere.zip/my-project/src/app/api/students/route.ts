import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const page = parseInt(searchParams.get('page') ?? '1', 10)
    const limit = parseInt(searchParams.get('limit') ?? '10', 10)
    const search = searchParams.get('search') ?? ''
    const classId = searchParams.get('classId')
    const sectionId = searchParams.get('sectionId')
    const status = searchParams.get('status')

    const where: Record<string, unknown> = {}

    if (search) {
      where.OR = [
        { firstName: { contains: search } },
        { lastName: { contains: search } },
        { admissionNo: { contains: search } },
      ]
    }

    if (classId) where.classId = classId
    if (sectionId) where.sectionId = sectionId
    if (status) where.status = status

    const [students, total] = await Promise.all([
      db.student.findMany({
        where,
        include: {
          class: { select: { id: true, name: true } },
          section: { select: { id: true, name: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.student.count({ where }),
    ])

    return NextResponse.json({
      data: students,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to fetch students' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const student = await db.student.create({
      data: {
        admissionNo: body.admissionNo,
        rollNumber: body.rollNumber,
        firstName: body.firstName,
        lastName: body.lastName,
        dob: new Date(body.dob),
        gender: body.gender,
        bloodGroup: body.bloodGroup,
        religion: body.religion,
        category: body.category,
        address: body.address,
        phone: body.phone,
        email: body.email,
        avatar: body.avatar,
        admissionDate: body.admissionDate ? new Date(body.admissionDate) : undefined,
        fatherName: body.fatherName,
        fatherPhone: body.fatherPhone,
        fatherOccupation: body.fatherOccupation,
        motherName: body.motherName,
        motherPhone: body.motherPhone,
        motherOccupation: body.motherOccupation,
        guardianName: body.guardianName,
        guardianPhone: body.guardianPhone,
        guardianRelation: body.guardianRelation,
        medicalHistory: body.medicalHistory,
        allergies: body.allergies,
        schoolId: body.schoolId,
        classId: body.classId,
        sectionId: body.sectionId,
        className: body.className,
        sectionName: body.sectionName,
        status: body.status ?? 'active',
      },
    })

    return NextResponse.json({ data: student }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to create student' }, { status: 500 })
  }
}