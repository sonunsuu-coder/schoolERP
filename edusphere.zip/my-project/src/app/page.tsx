'use client'

import dynamic from 'next/dynamic'
import { useAppStore } from '@/store/app'
import { AppShell } from '@/components/layout/AppShell'
import { Loader2 } from 'lucide-react'

function ModuleLoader() {
  return (
    <div className="flex h-96 items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
    </div>
  )
}

const modules: Record<string, React.ComponentType> = {
  dashboard: dynamic(() => import('@/components/modules/DashboardModule'), { loading: ModuleLoader, ssr: false }),
  students: dynamic(() => import('@/components/modules/StudentsModule'), { loading: ModuleLoader, ssr: false }),
  attendance: dynamic(() => import('@/components/modules/AttendanceModule'), { loading: ModuleLoader, ssr: false }),
  fees: dynamic(() => import('@/components/modules/FeeModule'), { loading: ModuleLoader, ssr: false }),
  exams: dynamic(() => import('@/components/modules/ExamModule'), { loading: ModuleLoader, ssr: false }),
  timetable: dynamic(() => import('@/components/modules/TimetableModule'), { loading: ModuleLoader, ssr: false }),
  homework: dynamic(() => import('@/components/modules/HomeworkModule'), { loading: ModuleLoader, ssr: false }),
  communication: dynamic(() => import('@/components/modules/CommunicationModule'), { loading: ModuleLoader, ssr: false }),
  library: dynamic(() => import('@/components/modules/LibraryModule'), { loading: ModuleLoader, ssr: false }),
  staff: dynamic(() => import('@/components/modules/StaffModule'), { loading: ModuleLoader, ssr: false }),
  transport: dynamic(() => import('@/components/modules/TransportModule'), { loading: ModuleLoader, ssr: false }),
  events: dynamic(() => import('@/components/modules/EventsModule'), { loading: ModuleLoader, ssr: false }),
  reports: dynamic(() => import('@/components/modules/ReportsModule'), { loading: ModuleLoader, ssr: false }),
  settings: dynamic(() => import('@/components/modules/SettingsModule'), { loading: ModuleLoader, ssr: false }),
}

export default function HomePage() {
  const { activeModule } = useAppStore()
  const ActiveComponent = modules[activeModule]

  return (
    <AppShell>
      <ActiveComponent />
    </AppShell>
  )
}