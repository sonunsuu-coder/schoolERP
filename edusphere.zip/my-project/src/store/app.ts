import { create } from 'zustand'

export type ModuleId =
  | 'dashboard'
  | 'students'
  | 'attendance'
  | 'fees'
  | 'exams'
  | 'timetable'
  | 'homework'
  | 'communication'
  | 'library'
  | 'staff'
  | 'transport'
  | 'events'
  | 'reports'
  | 'settings'

interface AppState {
  activeModule: ModuleId
  sidebarOpen: boolean
  setActiveModule: (module: ModuleId) => void
  toggleSidebar: () => void
  setSidebarOpen: (open: boolean) => void
}

export const useAppStore = create<AppState>((set) => ({
  activeModule: 'dashboard',
  sidebarOpen: true,
  setActiveModule: (module) => set({ activeModule: module }),
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
}))