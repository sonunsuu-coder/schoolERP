'use client'

import { useEffect } from 'react'
import { useAppStore } from '@/store/app'
import { Header } from '@/components/layout/Header'
import { Sidebar, SidebarContent } from '@/components/layout/Sidebar'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'

function AppShell({ children }: { children: React.ReactNode }) {
  const { sidebarOpen, setSidebarOpen, activeModule } = useAppStore()

  // Close mobile sidebar on module change
  useEffect(() => {
    setSidebarOpen(false)
  }, [activeModule, setSidebarOpen])

  return (
    <div className="flex min-h-screen flex-col bg-gray-50 dark:bg-gray-950">
      <Header />

      <div className="flex flex-1 overflow-hidden">
        {/* Desktop sidebar */}
        <Sidebar />

        {/* Mobile sidebar sheet */}
        <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <SheetContent side="left" className="w-64 p-0 dark:bg-gray-900">
            <SheetHeader className="sr-only">
              <SheetTitle>Navigation Menu</SheetTitle>
              <SheetDescription>EduSphere main navigation</SheetDescription>
            </SheetHeader>
            <SidebarContent isMobile />
          </SheetContent>
        </Sheet>

        {/* Main content */}
        <main className="flex-1 overflow-auto p-4 sm:p-6">
          {children}
        </main>
      </div>

      {/* Sticky footer */}
      <footer className="mt-auto border-t border-gray-200 bg-white py-3 dark:border-gray-800 dark:bg-gray-900">
        <p className="text-center text-xs text-gray-500 dark:text-gray-400">
          © 2024 EduSphere School Management System. All rights reserved.
        </p>
      </footer>
    </div>
  )
}

export { AppShell }