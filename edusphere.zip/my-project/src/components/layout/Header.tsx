'use client'

import { Menu, Search, Bell, LogOut, Settings, User } from 'lucide-react'
import { useAppStore, type ModuleId } from '@/store/app'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

const moduleNames: Record<ModuleId, string> = {
  dashboard: 'Dashboard',
  students: 'Students',
  attendance: 'Attendance',
  fees: 'Fees',
  exams: 'Examinations',
  timetable: 'Timetable',
  homework: 'Homework',
  communication: 'Communication',
  library: 'Library',
  staff: 'Staff & HR',
  transport: 'Transport',
  events: 'Events',
  reports: 'Reports',
  settings: 'Settings',
}

function Header() {
  const { activeModule, toggleSidebar, setActiveModule } = useAppStore()
  const currentModuleName = moduleNames[activeModule]

  return (
    <header className="sticky top-0 z-30 flex h-16 shrink-0 items-center gap-4 border-b border-gray-200 bg-white px-4 dark:border-gray-800 dark:bg-gray-900 sm:px-6">
      {/* Left side */}
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={toggleSidebar}
          aria-label="Toggle sidebar"
        >
          <Menu className="size-5" />
        </Button>

        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb">
          <ol className="flex items-center gap-1.5 text-sm">
            <li className="text-gray-400 dark:text-gray-500">Home</li>
            <li className="text-gray-300 dark:text-gray-600">/</li>
            <li className="font-medium text-gray-900 dark:text-gray-100">
              {currentModuleName}
            </li>
          </ol>
        </nav>
      </div>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Right side */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Search */}
        <div className="relative hidden sm:block">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-gray-400" />
          <Input
            type="search"
            placeholder="Search students, fees, exams..."
            className="h-9 w-56 rounded-lg pl-9 text-sm lg:w-72"
            readOnly
          />
        </div>

        <Separator orientation="vertical" className="hidden h-6 sm:block" />

        {/* Notifications */}
        <Button
          variant="ghost"
          size="icon"
          className="relative"
          aria-label="Notifications"
        >
          <Bell className="size-5 text-gray-600 dark:text-gray-400" />
          <Badge className="absolute -right-0.5 -top-0.5 flex size-5 items-center justify-center rounded-full bg-red-500 p-0 text-[10px] font-bold text-white border-0">
            3
          </Badge>
        </Button>

        {/* User dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative flex items-center gap-2 px-2">
              <Avatar className="size-8">
                <AvatarFallback className="bg-emerald-100 text-sm font-semibold text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-400">
                  AU
                </AvatarFallback>
              </Avatar>
              <span className="hidden text-sm font-medium text-gray-700 dark:text-gray-300 lg:block">
                Admin User
              </span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col gap-1">
                <p className="text-sm font-medium">Admin User</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Super Admin</p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem onSelect={() => setActiveModule('settings')}>
                <User className="mr-2 size-4" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setActiveModule('settings')}>
                <Settings className="mr-2 size-4" />
                Settings
              </DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
            <DropdownMenuItem variant="destructive">
              <LogOut className="mr-2 size-4" />
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}

export { Header }