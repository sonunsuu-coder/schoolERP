'use client'

import { type LucideIcon, LayoutDashboard, GraduationCap, UserCheck, IndianRupee, FileText, CalendarDays, BookOpen, MessageSquare, Library, Users, Bus, Calendar, BarChart3 } from 'lucide-react'
import { useAppStore, type ModuleId } from '@/store/app'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip'

interface NavItem {
  label: string
  moduleId: ModuleId
  icon: LucideIcon
}

interface NavCategory {
  title: string
  items: NavItem[]
}

const navCategories: NavCategory[] = [
  {
    title: 'Main',
    items: [
      { label: 'Dashboard', moduleId: 'dashboard', icon: LayoutDashboard },
      { label: 'Students', moduleId: 'students', icon: GraduationCap },
      { label: 'Attendance', moduleId: 'attendance', icon: UserCheck },
      { label: 'Fees', moduleId: 'fees', icon: IndianRupee },
      { label: 'Examinations', moduleId: 'exams', icon: FileText },
      { label: 'Timetable', moduleId: 'timetable', icon: CalendarDays },
    ],
  },
  {
    title: 'Academics',
    items: [
      { label: 'Homework', moduleId: 'homework', icon: BookOpen },
      { label: 'Communication', moduleId: 'communication', icon: MessageSquare },
      { label: 'Library', moduleId: 'library', icon: Library },
    ],
  },
  {
    title: 'Administration',
    items: [
      { label: 'Staff & HR', moduleId: 'staff', icon: Users },
      { label: 'Transport', moduleId: 'transport', icon: Bus },
      { label: 'Events', moduleId: 'events', icon: Calendar },
      { label: 'Reports', moduleId: 'reports', icon: BarChart3 },
    ],
  },
]

function NavItemButton({ item, isMobile = false }: { item: NavItem; isMobile?: boolean }) {
  const { activeModule, setActiveModule, setSidebarOpen } = useAppStore()
  const isActive = activeModule === item.moduleId
  const Icon = item.icon

  const handleClick = () => {
    setActiveModule(item.moduleId)
    if (isMobile) {
      setSidebarOpen(false)
    }
  }

  if (isMobile) {
    return (
      <button
        onClick={handleClick}
        className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
          isActive
            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-400'
            : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-gray-200'
        }`}
      >
        <Icon className={`size-5 shrink-0 ${isActive ? 'text-emerald-600 dark:text-emerald-400' : ''}`} />
        <span>{item.label}</span>
        {isActive && (
          <span className="ml-auto h-1.5 w-1.5 rounded-full bg-emerald-500 dark:bg-emerald-400" />
        )}
      </button>
    )
  }

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          onClick={handleClick}
          className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
            isActive
              ? 'border-l-[3px] border-emerald-500 bg-emerald-50 text-emerald-700 pl-[9px] dark:border-emerald-400 dark:bg-emerald-950/50 dark:text-emerald-400'
              : 'border-l-[3px] border-transparent text-gray-600 hover:bg-gray-100 hover:text-gray-900 pl-[9px] dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-gray-200'
          }`}
        >
          <Icon className={`size-5 shrink-0 ${isActive ? 'text-emerald-600 dark:text-emerald-400' : ''}`} />
          <span>{item.label}</span>
        </button>
      </TooltipTrigger>
      <TooltipContent side="right" sideOffset={8}>
        {item.label}
      </TooltipContent>
    </Tooltip>
  )
}

function SidebarContent({ isMobile = false }: { isMobile?: boolean }) {
  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-5">
        <div className="flex size-9 items-center justify-center rounded-lg bg-emerald-600 dark:bg-emerald-700">
          <GraduationCap className="size-5 text-white" />
        </div>
        <div className="flex flex-col">
          <span className="text-base font-bold tracking-tight text-gray-900 dark:text-white">
            EduSphere
          </span>
          <span className="text-xs text-gray-500 dark:text-gray-400">DPS Roorkee</span>
        </div>
      </div>

      <Separator />

      {/* Navigation */}
      <ScrollArea className="flex-1 px-3 py-3">
        <nav className="flex flex-col gap-5">
          {navCategories.map((category) => (
            <div key={category.title} className="flex flex-col gap-1">
              <span className="px-3 pb-1 pt-1 text-[11px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500">
                {category.title}
              </span>
              {category.items.map((item) => (
                <NavItemButton key={item.moduleId} item={item} isMobile={isMobile} />
              ))}
            </div>
          ))}
        </nav>
      </ScrollArea>

      {/* Footer */}
      <Separator />
      <div className="px-4 py-3">
        <p className="text-xs text-gray-400 dark:text-gray-500">Version 2.0</p>
        <p className="text-xs text-gray-400 dark:text-gray-500">© 2024 EduSphere</p>
      </div>
    </div>
  )
}

function Sidebar() {
  return (
    <aside className="hidden w-64 shrink-0 flex-col border-r border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900 md:flex">
      <SidebarContent />
    </aside>
  )
}

export { Sidebar, SidebarContent }