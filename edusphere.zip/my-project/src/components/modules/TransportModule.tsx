'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Bus,
  Plus,
  Phone,
  User,
  Route,
  Users,
  Loader2,
  MapPin,
  Gauge,
} from 'lucide-react'
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Progress } from '@/components/ui/progress'

// ─── Types ───────────────────────────────────────────────────────────────────

interface Vehicle {
  id: string
  number: string
  type: string
  capacity: number
  driverName: string
  driverPhone: string
  route: string
  status: string
  createdAt: string
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getStatusBadge(status: string) {
  return status === 'active' ? (
    <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 text-[10px] px-1.5 py-0 hover:bg-emerald-100">
      Active
    </Badge>
  ) : (
    <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
      Inactive
    </Badge>
  )
}

function getTypeIcon(type: string) {
  return type.toLowerCase().includes('bus') ? (
    <Bus className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
  ) : (
    <Bus className="h-5 w-5 text-teal-600 dark:text-teal-400" />
  )
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function TableSkeleton({ rows = 4 }: { rows?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 px-4">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-4 w-28" />
          <Skeleton className="h-4 w-28 hidden md:block" />
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-5 w-14" />
        </div>
      ))}
    </div>
  )
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function TransportModule() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  // Form state
  const [formNumber, setFormNumber] = useState('')
  const [formType, setFormType] = useState('')
  const [formCapacity, setFormCapacity] = useState('')
  const [formDriverName, setFormDriverName] = useState('')
  const [formDriverPhone, setFormDriverPhone] = useState('')
  const [formRoute, setFormRoute] = useState('')

  const fetchVehicles = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      const res = await fetch('/api/transport')
      if (!res.ok) throw new Error('Failed to fetch vehicles')
      const json = await res.json()
      setVehicles(json.data ?? [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchVehicles()
  }, [fetchVehicles])

  const handleSubmit = async () => {
    if (!formNumber || !formType || !formCapacity || !formDriverName || !formDriverPhone || !formRoute) return
    try {
      setSubmitting(true)
      const res = await fetch('/api/transport', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          number: formNumber,
          type: formType,
          capacity: parseInt(formCapacity),
          driverName: formDriverName,
          driverPhone: formDriverPhone,
          route: formRoute,
        }),
      })
      if (!res.ok) throw new Error('Failed to add vehicle')
      setDialogOpen(false)
      setFormNumber('')
      setFormType('')
      setFormCapacity('')
      setFormDriverName('')
      setFormDriverPhone('')
      setFormRoute('')
      fetchVehicles()
    } catch (err) {
      console.error(err)
    } finally {
      setSubmitting(false)
    }
  }

  // Summary stats
  const totalVehicles = vehicles.length
  const activeVehicles = vehicles.filter((v) => v.status === 'active').length
  const totalCapacity = vehicles.reduce((sum, v) => sum + v.capacity, 0)
  const activeRoutes = new Set(vehicles.filter((v) => v.status === 'active').map((v) => v.route)).size

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Transport Management
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage school vehicles, routes, and drivers
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Add Vehicle
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Vehicle</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="veh-number">Vehicle Number *</Label>
                  <Input
                    id="veh-number"
                    value={formNumber}
                    onChange={(e) => setFormNumber(e.target.value)}
                    placeholder="e.g., UK-07-AB-1234"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="veh-type">Type *</Label>
                  <Select value={formType} onValueChange={setFormType}>
                    <SelectTrigger id="veh-type">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Bus">Bus</SelectItem>
                      <SelectItem value="Mini Bus">Mini Bus</SelectItem>
                      <SelectItem value="Van">Van</SelectItem>
                      <SelectItem value="Tempo">Tempo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="veh-capacity">Capacity *</Label>
                <Input
                  id="veh-capacity"
                  type="number"
                  min={1}
                  value={formCapacity}
                  onChange={(e) => setFormCapacity(e.target.value)}
                  placeholder="Seating capacity"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="veh-driver">Driver Name *</Label>
                  <Input
                    id="veh-driver"
                    value={formDriverName}
                    onChange={(e) => setFormDriverName(e.target.value)}
                    placeholder="Driver name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="veh-driver-phone">Driver Phone *</Label>
                  <Input
                    id="veh-driver-phone"
                    value={formDriverPhone}
                    onChange={(e) => setFormDriverPhone(e.target.value)}
                    placeholder="Phone number"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="veh-route">Route *</Label>
                <Input
                  id="veh-route"
                  value={formRoute}
                  onChange={(e) => setFormRoute(e.target.value)}
                  placeholder="e.g., Sector 24 → Railway Station"
                />
              </div>
              <Button
                onClick={handleSubmit}
                disabled={
                  submitting ||
                  !formNumber ||
                  !formType ||
                  !formCapacity ||
                  !formDriverName ||
                  !formDriverPhone ||
                  !formRoute
                }
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Add Vehicle
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Error State */}
      {error && !loading && (
        <Card className="border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950/30">
          <CardContent className="flex items-center gap-3 p-4">
            <span className="text-rose-500 text-lg">⚠</span>
            <p className="text-sm text-rose-700 dark:text-rose-400">{error}</p>
            <Button variant="outline" size="sm" className="ml-auto" onClick={fetchVehicles}>
              Retry
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950">
              <Bus className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{totalVehicles}</p>
              <p className="text-xs text-muted-foreground">Total Vehicles</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-950">
              <Route className="h-5 w-5 text-teal-600 dark:text-teal-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{activeRoutes}</p>
              <p className="text-xs text-muted-foreground">Active Routes</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-950">
              <Users className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{totalCapacity}</p>
              <p className="text-xs text-muted-foreground">Total Capacity</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Route Cards */}
      {!loading && vehicles.filter((v) => v.status === 'active').length > 0 && (
        <div>
          <h2 className="text-base font-semibold mb-3">Active Routes</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {vehicles
              .filter((v) => v.status === 'active')
              .map((vehicle) => (
                <Card
                  key={vehicle.id}
                  className="p-4 border-l-4 border-l-emerald-500 transition-shadow hover:shadow-md"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getTypeIcon(vehicle.type)}
                        <span className="font-semibold text-sm">{vehicle.number}</span>
                      </div>
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                        {vehicle.type}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      <span>{vehicle.route}</span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3 text-muted-foreground" />
                          {vehicle.driverName}
                        </span>
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <Phone className="h-3 w-3" />
                          {vehicle.driverPhone}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs">
                        <Users className="h-3 w-3 text-muted-foreground" />
                        <span>Capacity: {vehicle.capacity} seats</span>
                      </div>
                      <Progress
                        value={Math.min(vehicle.capacity * 10, 100)}
                        className="h-1.5"
                      />
                    </div>
                  </div>
                </Card>
              ))}
          </div>
        </div>
      )}

      {/* Vehicles Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">All Vehicles</CardTitle>
          <CardDescription>Complete list of school transport vehicles</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4">
              <TableSkeleton />
            </div>
          ) : vehicles.length > 0 ? (
            <ScrollArea className="max-h-[400px]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vehicle Number</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="hidden sm:table-cell">Capacity</TableHead>
                    <TableHead className="hidden md:table-cell">Driver</TableHead>
                    <TableHead className="hidden lg:table-cell">Phone</TableHead>
                    <TableHead className="hidden xl:table-cell">Route</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vehicles.map((v) => (
                    <TableRow key={v.id} className="hover:bg-muted/50">
                      <TableCell className="font-mono text-xs font-medium">
                        {v.number}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                          {v.type}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">
                        <span className="flex items-center gap-1 text-xs">
                          <Users className="h-3 w-3 text-muted-foreground" />
                          {v.capacity}
                        </span>
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-sm">
                        {v.driverName}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Phone className="h-3 w-3" />
                          {v.driverPhone}
                        </span>
                      </TableCell>
                      <TableCell className="hidden xl:table-cell text-xs text-muted-foreground max-w-48 truncate">
                        {v.route}
                      </TableCell>
                      <TableCell>{getStatusBadge(v.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Bus className="h-12 w-12 text-muted-foreground/30 mb-3" />
              <p className="text-sm text-muted-foreground">No vehicles registered</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
