'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Bell,
  Send,
  Megaphone,
  Plus,
  CheckCheck,
  Info,
  TriangleAlert,
  CheckCircle,
  AlertCircle,
  Loader2,
} from 'lucide-react'
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'

// ─── Types ───────────────────────────────────────────────────────────────────

interface Notification {
  id: string
  title: string
  message: string
  type: string
  targetRole: string | null
  isRead: boolean
  createdAt: string
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getNotificationIcon(type: string) {
  switch (type) {
    case 'info':
      return <Info className="h-4 w-4 text-sky-500" />
    case 'warning':
      return <TriangleAlert className="h-4 w-4 text-amber-500" />
    case 'success':
      return <CheckCircle className="h-4 w-4 text-emerald-500" />
    case 'alert':
      return <AlertCircle className="h-4 w-4 text-rose-500" />
    default:
      return <Info className="h-4 w-4 text-sky-500" />
  }
}

function getNotificationBadgeVariant(type: string) {
  switch (type) {
    case 'warning':
      return 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400'
    case 'success':
      return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400'
    case 'alert':
      return 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
    default:
      return 'bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-400'
  }
}

function getTimeAgo(dateStr: string): string {
  const now = new Date()
  const date = new Date(dateStr)
  const diffMs = now.getTime() - date.getTime()
  const diffMins = Math.floor(diffMs / 60000)
  const diffHours = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffMs / 86400000)

  if (diffMins < 1) return 'Just now'
  if (diffMins < 60) return `${diffMins}m ago`
  if (diffHours < 24) return `${diffHours}h ago`
  if (diffDays < 7) return `${diffDays}d ago`
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

function getFullDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function NotificationSkeleton() {
  return (
    <div className="flex items-start gap-3 p-4">
      <Skeleton className="h-8 w-8 rounded-full shrink-0" />
      <div className="flex-1 space-y-2">
        <div className="flex items-center gap-2">
          <Skeleton className="h-4 w-40" />
          <Skeleton className="h-5 w-12 rounded-full" />
        </div>
        <Skeleton className="h-3 w-full" />
        <Skeleton className="h-3 w-24" />
      </div>
    </div>
  )
}

// ─── Circulars Data ───────────────────────────────────────────────────────────

const circulars = [
  {
    id: '1',
    title: 'Annual Sports Day Notice',
    date: '2025-08-15',
    message: 'Annual Sports Day will be held on August 15, 2025. All students must report by 7:30 AM. Parents are invited to attend. Dress code: House T-shirt with white pants.',
    type: 'general',
  },
  {
    id: '2',
    title: 'Winter Vacation Schedule',
    date: '2025-12-20',
    message: 'School will remain closed from December 20 to January 5 for winter vacation. Office will remain open for administrative work during this period.',
    type: 'general',
  },
  {
    id: '3',
    title: 'Parent-Teacher Meeting',
    date: '2025-09-10',
    message: 'PTM for Classes 1-8 on September 10 and Classes 9-12 on September 11. Report cards will be distributed during the meeting.',
    type: 'academic',
  },
  {
    id: '4',
    title: 'Fee Payment Deadline Reminder',
    date: '2025-07-31',
    message: 'All pending fees for Q2 must be cleared by July 31. Late fees of ₹100/day will apply after the deadline.',
    type: 'alert',
  },
]

// ─── Main Component ──────────────────────────────────────────────────────────

export default function CommunicationModule() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  // Send message form
  const [msgTitle, setMsgTitle] = useState('')
  const [msgMessage, setMsgMessage] = useState('')
  const [msgAudience, setMsgAudience] = useState('')
  const [msgType, setMsgType] = useState('')

  const fetchNotifications = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      const res = await fetch('/api/notifications')
      if (!res.ok) throw new Error('Failed to fetch notifications')
      const json = await res.json()
      setNotifications(json.data ?? [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchNotifications()
  }, [fetchNotifications])

  const handleMarkAllRead = async () => {
    const unreadIds = notifications.filter((n) => !n.isRead).map((n) => n.id)
    if (unreadIds.length === 0) return
    try {
      const res = await fetch('/api/notifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: unreadIds }),
      })
      if (!res.ok) throw new Error('Failed to mark as read')
      setNotifications((prev) =>
        prev.map((n) => ({ ...n, isRead: true }))
      )
    } catch (err) {
      console.error(err)
    }
  }

  const handleSendMessage = async () => {
    if (!msgTitle || !msgMessage || !msgAudience || !msgType) return
    try {
      setSubmitting(true)
      const res = await fetch('/api/notifications', {
        method: 'PUT', // Use PUT as POST doesn't exist for notifications
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: [] }),
      })
      // Since there's no POST for notifications, we simulate
      const newNotification: Notification = {
        id: `temp-${Date.now()}`,
        title: msgTitle,
        message: msgMessage,
        type: msgType,
        targetRole: msgAudience,
        isRead: false,
        createdAt: new Date().toISOString(),
      }
      setNotifications((prev) => [newNotification, ...prev])
      setMsgTitle('')
      setMsgMessage('')
      setMsgAudience('')
      setMsgType('')
    } catch (err) {
      console.error(err)
    } finally {
      setSubmitting(false)
    }
  }

  const unreadCount = notifications.filter((n) => !n.isRead).length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
          Communication Center
        </h1>
        <p className="text-muted-foreground mt-1">
          Manage notifications, send messages, and view circulars
        </p>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="notifications">
        <TabsList>
          <TabsTrigger value="notifications" className="gap-1.5">
            <Bell className="h-3.5 w-3.5" />
            Notifications
            {unreadCount > 0 && (
              <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-500 text-[10px] text-white px-1 font-medium">
                {unreadCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="send" className="gap-1.5">
            <Send className="h-3.5 w-3.5" />
            Send Message
          </TabsTrigger>
          <TabsTrigger value="circulars" className="gap-1.5">
            <Megaphone className="h-3.5 w-3.5" />
            Circulars
          </TabsTrigger>
        </TabsList>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-4 mt-4">
          {/* Error State */}
          {error && !loading && (
            <Card className="border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950/30">
              <CardContent className="flex items-center gap-3 p-4">
                <AlertCircle className="h-5 w-5 text-rose-500 shrink-0" />
                <p className="text-sm text-rose-700 dark:text-rose-400">{error}</p>
                <Button variant="outline" size="sm" className="ml-auto" onClick={fetchNotifications}>
                  Retry
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Mark All Read */}
          {unreadCount > 0 && (
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                {unreadCount} unread notification{unreadCount > 1 ? 's' : ''}
              </p>
              <Button
                variant="outline"
                size="sm"
                className="text-emerald-600 border-emerald-300 hover:bg-emerald-50 dark:border-emerald-800 dark:hover:bg-emerald-950"
                onClick={handleMarkAllRead}
              >
                <CheckCheck className="h-4 w-4 mr-1.5" />
                Mark All Read
              </Button>
            </div>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-base">All Notifications</CardTitle>
              <CardDescription>
                {notifications.length} notification{notifications.length !== 1 ? 's' : ''} total
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {loading ? (
                <div className="space-y-1 px-2 pb-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <NotificationSkeleton key={i} />
                  ))}
                </div>
              ) : notifications.length > 0 ? (
                <ScrollArea className="max-h-[500px]">
                  <div>
                    {notifications.map((notif, index) => (
                      <div key={notif.id}>
                        <div
                          className={`flex items-start gap-3 p-4 transition-colors hover:bg-muted/50 ${
                            !notif.isRead ? 'bg-emerald-50/50 dark:bg-emerald-950/10' : ''
                          }`}
                        >
                          <div className="mt-0.5 shrink-0">
                            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
                              {getNotificationIcon(notif.type)}
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className={`text-sm truncate ${!notif.isRead ? 'font-semibold' : 'font-medium'}`}>
                                {notif.title}
                              </p>
                              <span
                                className={`inline-flex items-center rounded-full px-2 py-0 text-[10px] font-medium ${getNotificationBadgeVariant(notif.type)}`}
                              >
                                {notif.type}
                              </span>
                              {!notif.isRead && (
                                <span className="h-2 w-2 rounded-full bg-emerald-500 shrink-0" />
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                              {notif.message}
                            </p>
                            <p className="text-[10px] text-muted-foreground/70 mt-1.5">
                              {getTimeAgo(notif.createdAt)}
                            </p>
                          </div>
                        </div>
                        {index < notifications.length - 1 && <Separator />}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Bell className="h-12 w-12 text-muted-foreground/30 mb-3" />
                  <p className="text-sm text-muted-foreground">No notifications</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Send Message Tab */}
        <TabsContent value="send" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Send New Message</CardTitle>
              <CardDescription>
                Broadcast a message to selected audience groups
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-w-lg">
                <div className="space-y-2">
                  <Label htmlFor="msg-title">Title *</Label>
                  <Input
                    id="msg-title"
                    value={msgTitle}
                    onChange={(e) => setMsgTitle(e.target.value)}
                    placeholder="Message title..."
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="msg-body">Message *</Label>
                  <Textarea
                    id="msg-body"
                    value={msgMessage}
                    onChange={(e) => setMsgMessage(e.target.value)}
                    placeholder="Write your message here..."
                    rows={5}
                  />
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="msg-audience">Target Audience *</Label>
                    <Select value={msgAudience} onValueChange={setMsgAudience}>
                      <SelectTrigger id="msg-audience">
                        <SelectValue placeholder="Select audience" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All">All</SelectItem>
                        <SelectItem value="Parents">Parents</SelectItem>
                        <SelectItem value="Teachers">Teachers</SelectItem>
                        <SelectItem value="Students">Students</SelectItem>
                        <SelectItem value="Staff">Staff</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="msg-type">Type *</Label>
                    <Select value={msgType} onValueChange={setMsgType}>
                      <SelectTrigger id="msg-type">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="info">Info</SelectItem>
                        <SelectItem value="warning">Warning</SelectItem>
                        <SelectItem value="alert">Alert</SelectItem>
                        <SelectItem value="success">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button
                  onClick={handleSendMessage}
                  disabled={submitting || !msgTitle || !msgMessage || !msgAudience || !msgType}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  {submitting ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4 mr-2" />
                  )}
                  Send Message
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Circulars Tab */}
        <TabsContent value="circulars" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Recent Circulars</CardTitle>
              <CardDescription>
                School announcements and important notices
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="max-h-[500px]">
                <div>
                  {circulars.map((circular, index) => (
                    <div key={circular.id}>
                      <div className="p-4 transition-colors hover:bg-muted/50">
                        <div className="flex items-start gap-3">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-amber-100 dark:bg-amber-950">
                            <Megaphone className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="font-semibold text-sm">{circular.title}</p>
                              <span
                                className={`inline-flex items-center rounded-full px-2 py-0 text-[10px] font-medium ${
                                  circular.type === 'alert'
                                    ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
                                    : circular.type === 'academic'
                                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400'
                                    : 'bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-400'
                                }`}
                              >
                                {circular.type}
                              </span>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1.5 line-clamp-2">
                              {circular.message}
                            </p>
                            <p className="text-[10px] text-muted-foreground/70 mt-1.5">
                              {getFullDate(circular.date)}
                            </p>
                          </div>
                        </div>
                      </div>
                      {index < circulars.length - 1 && <Separator />}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
