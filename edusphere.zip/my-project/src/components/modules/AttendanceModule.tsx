'use client'

import React, { useState, useEffect, useCallback, useMemo } from 'react'
import {
  ClipboardCheck,
  Loader2,
  AlertCircle,
  CircleCheck,
  XCircle,
  Clock,
  Users,
  RotateCcw,
  BarChart3,
  Save,
  CalendarDays,
  TrendingUp,
  UserCheck,
  UserX,
} from 'lucide-react'

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Progress } from '@/components/ui/progress'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'

// ─── Types ──────────────────────────────────────────────────────────────────

interface ClassWithSections {
  id: string
  name: string
  numericLevel: number
  sections: { id: string; name: string }[]
}

type AttendanceStatus = 'present' | 'absent' | 'late' | 'not_marked'

interface AttendanceStudent {
  id: string
  firstName: string
  lastName: string
  admissionNo: string
  rollNumber: string | null
  className: string | null
  sectionName: string | null
  class?: { name: string } | null
  section?: { name: string } | null
  status: AttendanceStatus
  remarks: string | null
}

interface AttendanceRecord {
  studentId: string
  status: AttendanceStatus
  remarks: string
}

interface ClassReportSummary {
  className: string
  totalStudents: number
  avgAttendance: number
  defaulterCount: number
}

interface ReportMonthlyData {
  month: string
  classes: {
    className: string
    total: number
    present: number
    percentage: number
  }[]
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function getInitials(firstName: string, lastName: string) {
  return `${(firstName?.[0] ?? '').toUpperCase()}${(lastName?.[0] ?? '').toUpperCase()}`
}

function getTodayString() {
  const d = new Date()
  return d.toISOString().split('T')[0]
}

function formatDateDisplay(dateStr: string) {
  if (!dateStr) return ''
  try {
    return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    })
  } catch {
    return dateStr
  }
}

function formatMonth(monthStr: string) {
  if (!monthStr) return ''
  const [year, month] = monthStr.split('-')
  const d = new Date(parseInt(year), parseInt(month) - 1, 1)
  return d.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })
}

// ─── Component ──────────────────────────────────────────────────────────────

export default function AttendanceModule() {
  // ── Classes & sections ──
  const [classes, setClasses] = useState<ClassWithSections[]>([])
  const [classesLoading, setClassesLoading] = useState(true)

  // ── Mark Attendance Tab state ──
  const [date, setDate] = useState(getTodayString())
  const [selectedClassId, setSelectedClassId] = useState('')
  const [selectedSectionId, setSelectedSectionId] = useState('')
  const [students, setStudents] = useState<AttendanceStudent[]>([])
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [successMsg, setSuccessMsg] = useState<string | null>(null)

  // ── Report Tab state ──
  const [reportFrom, setReportFrom] = useState('')
  const [reportTo, setReportTo] = useState('')
  const [reportClassId, setReportClassId] = useState('')
  const [reportLoading, setReportLoading] = useState(false)
  const [reportData, setReportData] = useState<ReportMonthlyData[] | null>(null)
  const [reportClassSummaries, setReportClassSummaries] = useState<ClassReportSummary[]>([])
  const [reportError, setReportError] = useState<string | null>(null)

  // ── Local attendance edits (keyed by studentId) ──
  const [localRecords, setLocalRecords] = useState<Record<string, AttendanceRecord>>({})

  // ── Derived: sections for selected class ──
  const sections = useMemo(() => {
    if (selectedClassId) {
      const cls = classes.find((c) => c.id === selectedClassId)
      return cls?.sections ?? []
    }
    return []
  }, [selectedClassId, classes])

  // ── Statistics ──
  const stats = useMemo(() => {
    const merged = students.map((s) => {
      const local = localRecords[s.id]
      return local ? local.status : s.status
    })

    const total = merged.length
    const present = merged.filter((s) => s === 'present').length
    const absent = merged.filter((s) => s === 'absent').length
    const late = merged.filter((s) => s === 'late').length
    const marked = present + late
    const percentage = total > 0 ? Math.round(((present + late * 0.5) / total) * 100) : 0

    return { total, present, absent, late, percentage, marked }
  }, [students, localRecords])

  // ─── Fetch classes ──────────────────────────────────────────────────────

  useEffect(() => {
    async function fetchClasses() {
      setClassesLoading(true)
      try {
        const res = await fetch('/api/classes')
        if (!res.ok) throw new Error('Failed to fetch classes')
        const json = await res.json()
        setClasses(json.data ?? [])
      } catch (err) {
        console.error(err)
      } finally {
        setClassesLoading(false)
      }
    }
    fetchClasses()
  }, [])

  // Reset section when class changes
  useEffect(() => {
    setSelectedSectionId('')
  }, [selectedClassId])

  // ─── Load students ──────────────────────────────────────────────────────

  const loadStudents = useCallback(async () => {
    if (!date || !selectedClassId || !selectedSectionId) {
      setError('Please select date, class, and section first.')
      return
    }

    setLoading(true)
    setError(null)
    setSuccessMsg(null)
    setLocalRecords({})

    try {
      const params = new URLSearchParams({ date, classId: selectedClassId, sectionId: selectedSectionId })
      const res = await fetch(`/api/attendance?${params.toString()}`)
      if (!res.ok) throw new Error('Failed to load attendance data')
      const json = await res.json()
      setStudents(json.data ?? [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }, [date, selectedClassId, selectedSectionId])

  // ─── Status toggle handler ──────────────────────────────────────────────

  function handleStatusChange(studentId: string, newStatus: AttendanceStatus) {
    setLocalRecords((prev) => ({
      ...prev,
      [studentId]: {
        studentId,
        status: newStatus,
        remarks: prev[studentId]?.remarks ?? '',
      },
    }))
    // Clear success/error messages on edit
    setSuccessMsg(null)
    setError(null)
  }

  // ─── Remarks handler ────────────────────────────────────────────────────

  function handleRemarksChange(studentId: string, remarks: string) {
    setLocalRecords((prev) => ({
      ...prev,
      [studentId]: {
        studentId,
        status: prev[studentId]?.status ?? 'not_marked',
        remarks,
      },
    }))
  }

  // ─── Mark All Present ───────────────────────────────────────────────────

  function markAllPresent() {
    const all: Record<string, AttendanceRecord> = {}
    for (const s of students) {
      all[s.id] = {
        studentId: s.id,
        status: 'present',
        remarks: localRecords[s.id]?.remarks ?? '',
      }
    }
    setLocalRecords(all)
    setSuccessMsg(null)
    setError(null)
  }

  // ─── Reset ──────────────────────────────────────────────────────────────

  function resetAll() {
    setLocalRecords({})
    setSuccessMsg(null)
    setError(null)
  }

  // ─── Save attendance ────────────────────────────────────────────────────

  async function saveAttendance() {
    // Build final records: merge local edits with server data
    const records: { studentId: string; status: string; remarks: string }[] = []

    for (const s of students) {
      const local = localRecords[s.id]
      const status = local ? local.status : s.status
      const remarks = local ? local.remarks : (s.remarks ?? '')

      if (status !== 'not_marked') {
        records.push({ studentId: s.id, status, remarks })
      }
    }

    if (records.length === 0) {
      setError('No attendance marked. Please mark at least one student.')
      return
    }

    setSaving(true)
    setError(null)
    setSuccessMsg(null)

    try {
      const res = await fetch('/api/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ date, records }),
      })

      if (!res.ok) throw new Error('Failed to save attendance')

      setSuccessMsg(`Attendance saved for ${records.length} student${records.length > 1 ? 's' : ''}.`)
      // Refresh to sync server state
      await loadStudents()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save attendance')
    } finally {
      setSaving(false)
    }
  }

  // ─── Report: fetch ──────────────────────────────────────────────────────

  const fetchReport = useCallback(async () => {
    if (!reportFrom || !reportTo) {
      setReportError('Please select a date range.')
      return
    }

    setReportLoading(true)
    setReportError(null)
    setReportData(null)
    setReportClassSummaries([])

    try {
      const res = await fetch(`/api/reports?type=attendance`)
      if (!res.ok) throw new Error('Failed to fetch report')
      const json = await res.json()
      const data = json.data as { monthlyByClass: ReportMonthlyData[] }

      // Filter by date range
      const filtered = (data.monthlyByClass ?? []).filter((m) => {
        return m.month >= reportFrom.slice(0, 7) && m.month <= reportTo.slice(0, 7)
      })

      // Filter by class if selected
      const classFiltered = reportClassId
        ? filtered.map((m) => ({
            ...m,
            classes: m.classes.filter((c) => {
              const cls = classes.find((cl) => cl.name === c.className)
              return cls?.id === reportClassId
            }),
          }))
        : filtered

      setReportData(classFiltered)

      // Build class summary
      const classMap: Record<string, { total: number; present: number; students: Set<string> }> = {}

      for (const month of classFiltered) {
        for (const cls of month.classes) {
          if (!classMap[cls.className]) {
            classMap[cls.className] = { total: 0, present: 0, students: new Set() }
          }
          classMap[cls.className].total += cls.total
          classMap[cls.className].present += cls.present
        }
      }

      const summaries: ClassReportSummary[] = Object.entries(classMap)
        .filter(([name]) => {
          if (reportClassId) {
            const cls = classes.find((c) => c.name === name)
            return cls?.id === reportClassId
          }
          return true
        })
        .map(([className, data]) => {
          const avgAttendance = data.total > 0 ? Math.round((data.present / data.total) * 100) : 0
          // Estimate total students from class data
          const cls = classes.find((c) => c.name === className)
          const totalStudents = cls?.sections?.reduce((sum, s) => {
            // rough estimation: we don't have per-section student count here
            return sum + Math.ceil(data.total / Math.max(classFiltered.length, 1))
          }, 0) ?? 0
          // Defaulter: students below 75%
          const defaulterCount = avgAttendance < 75 ? Math.ceil(totalStudents * (1 - avgAttendance / 100)) : 0

          return {
            className,
            totalStudents: totalStudents > 0 ? totalStudents : Math.ceil(data.total / Math.max(classFiltered.length, 1)),
            avgAttendance,
            defaulterCount,
          }
        })
        .sort((a, b) => a.className.localeCompare(b.className))

      setReportClassSummaries(summaries)
    } catch (err) {
      setReportError(err instanceof Error ? err.message : 'Failed to fetch report')
    } finally {
      setReportLoading(false)
    }
  }, [reportFrom, reportTo, reportClassId, classes])

  // ─── Get effective status for a student ─────────────────────────────────

  function getEffectiveStatus(student: AttendanceStudent): AttendanceStatus {
    return localRecords[student.id]?.status ?? student.status
  }

  function getEffectiveRemarks(student: AttendanceStudent): string {
    return localRecords[student.id]?.remarks ?? student.remarks ?? ''
  }

  // ─── Render ─────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* ─── Header ─────────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-lg bg-emerald-100 dark:bg-emerald-900/30">
            <ClipboardCheck className="size-5 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Attendance Management</h1>
            <p className="text-sm text-muted-foreground">Track and manage daily student attendance</p>
          </div>
        </div>
      </div>

      {/* ─── Tabs ───────────────────────────────────────────────────────── */}
      <Tabs defaultValue="mark" className="space-y-6">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="mark" className="flex items-center gap-2">
            <ClipboardCheck className="size-4" />
            <span className="hidden sm:inline">Mark Attendance</span>
            <span className="sm:hidden">Mark</span>
          </TabsTrigger>
          <TabsTrigger value="report" className="flex items-center gap-2">
            <BarChart3 className="size-4" />
            <span className="hidden sm:inline">Attendance Report</span>
            <span className="sm:hidden">Report</span>
          </TabsTrigger>
        </TabsList>

        {/* ═══════════════════════════════════════════════════════════════════
            TAB 1: MARK ATTENDANCE
        ═══════════════════════════════════════════════════════════════════ */}
        <TabsContent value="mark" className="space-y-6">
          {/* ─── Top Bar: Filters ──────────────────────────────────────── */}
          <Card>
            <CardContent className="p-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
                {/* Date */}
                <div className="space-y-1.5">
                  <Label htmlFor="att-date" className="text-xs font-medium text-muted-foreground">
                    Date
                  </Label>
                  <div className="relative">
                    <CalendarDays className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                    <Input
                      id="att-date"
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>

                {/* Class */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-muted-foreground">Class</Label>
                  <Select
                    value={selectedClassId}
                    onValueChange={(val) => setSelectedClassId(val)}
                    disabled={classesLoading}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={classesLoading ? 'Loading...' : 'Select class'} />
                    </SelectTrigger>
                    <SelectContent>
                      {classes.map((cls) => (
                        <SelectItem key={cls.id} value={cls.id}>
                          {cls.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Section */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-muted-foreground">Section</Label>
                  <Select
                    value={selectedSectionId}
                    onValueChange={(val) => setSelectedSectionId(val)}
                    disabled={!selectedClassId || sections.length === 0}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue
                        placeholder={!selectedClassId ? 'Select class first' : 'Select section'}
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {sections.map((sec) => (
                        <SelectItem key={sec.id} value={sec.id}>
                          {sec.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Load Button */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-muted-foreground invisible">Load</Label>
                  <Button
                    onClick={loadStudents}
                    disabled={loading || !date || !selectedClassId || !selectedSectionId}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                  >
                    {loading ? (
                      <Loader2 className="size-4 mr-2 animate-spin" />
                    ) : (
                      <Users className="size-4 mr-2" />
                    )}
                    Load Students
                  </Button>
                </div>

                {/* Quick info */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-muted-foreground">Students Loaded</Label>
                  <div className="flex h-10 items-center rounded-md border bg-muted/50 px-3 text-sm font-medium">
                    {students.length > 0 ? (
                      <span>{students.length} student{students.length > 1 ? 's' : ''}</span>
                    ) : (
                      <span className="text-muted-foreground">None</span>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* ─── Error Banner ──────────────────────────────────────────── */}
          {error && (
            <Card className="border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950/30">
              <CardContent className="flex items-center gap-3 p-4">
                <AlertCircle className="size-5 text-rose-600 dark:text-rose-400 shrink-0" />
                <p className="text-sm text-rose-700 dark:text-rose-300">{error}</p>
                <Button
                  variant="ghost"
                  size="sm"
                  className="ml-auto text-rose-600"
                  onClick={() => setError(null)}
                >
                  Dismiss
                </Button>
              </CardContent>
            </Card>
          )}

          {/* ─── Success Banner ────────────────────────────────────────── */}
          {successMsg && (
            <Card className="border-emerald-200 bg-emerald-50 dark:border-emerald-900 dark:bg-emerald-950/30">
              <CardContent className="flex items-center gap-3 p-4">
                <CircleCheck className="size-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <p className="text-sm text-emerald-700 dark:text-emerald-300">{successMsg}</p>
                <Button
                  variant="ghost"
                  size="sm"
                  className="ml-auto text-emerald-600"
                  onClick={() => setSuccessMsg(null)}
                >
                  Dismiss
                </Button>
              </CardContent>
            </Card>
          )}

          {/* ─── Statistics Panel ──────────────────────────────────────── */}
          {students.length > 0 && (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Card className="border-emerald-200 dark:border-emerald-900/50">
                <CardContent className="flex items-center gap-3 p-4">
                  <div className="flex size-10 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/30">
                    <UserCheck className="size-5 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Present</p>
                    <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
                      {stats.present}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-rose-200 dark:border-rose-900/50">
                <CardContent className="flex items-center gap-3 p-4">
                  <div className="flex size-10 items-center justify-center rounded-full bg-rose-100 dark:bg-rose-900/30">
                    <UserX className="size-5 text-rose-600 dark:text-rose-400" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Absent</p>
                    <p className="text-2xl font-bold text-rose-600 dark:text-rose-400">
                      {stats.absent}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-amber-200 dark:border-amber-900/50">
                <CardContent className="flex items-center gap-3 p-4">
                  <div className="flex size-10 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/30">
                    <Clock className="size-5 text-amber-600 dark:text-amber-400" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Late</p>
                    <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">
                      {stats.late}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-emerald-200 dark:border-emerald-900/50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex size-10 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/30">
                      <TrendingUp className="size-5 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-muted-foreground">Attendance %</p>
                      <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
                        {stats.percentage}%
                      </p>
                    </div>
                  </div>
                  <Progress
                    value={stats.percentage}
                    className="mt-2 h-2"
                  />
                </CardContent>
              </Card>
            </div>
          )}

          {/* ─── Attendance Table ──────────────────────────────────────── */}
          <Card>
            {students.length > 0 && (
              <CardHeader className="pb-3">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <CardTitle className="text-lg">
                      {formatDateDisplay(date)} — {classes.find((c) => c.id === selectedClassId)?.name ?? ''} {sections.find((s) => s.id === selectedSectionId)?.name ?? ''}
                    </CardTitle>
                    <CardDescription>
                      {stats.marked} of {stats.total} marked · {stats.total - stats.marked} remaining
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={markAllPresent}
                      className="border-emerald-300 text-emerald-700 hover:bg-emerald-50 dark:border-emerald-800 dark:text-emerald-400 dark:hover:bg-emerald-950/30"
                    >
                      <CircleCheck className="size-4 mr-1.5" />
                      Mark All Present
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={resetAll}
                    >
                      <RotateCcw className="size-4 mr-1.5" />
                      Reset
                    </Button>
                    <Button
                      size="sm"
                      onClick={saveAttendance}
                      disabled={saving || stats.marked === 0}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white"
                    >
                      {saving ? (
                        <Loader2 className="size-4 mr-1.5 animate-spin" />
                      ) : (
                        <Save className="size-4 mr-1.5" />
                      )}
                      Save Attendance
                    </Button>
                  </div>
                </div>
              </CardHeader>
            )}
            <CardContent className="p-0">
              <ScrollArea className="max-h-[520px]">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead className="w-[70px] pl-4">Roll No.</TableHead>
                        <TableHead>Student Name</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                        <TableHead className="hidden sm:table-cell w-[200px]">Remarks</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loading ? (
                        Array.from({ length: 10 }).map((_, i) => (
                          <TableRow key={i} className="hover:bg-transparent">
                            <TableCell className="pl-4"><Skeleton className="h-4 w-12" /></TableCell>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                <Skeleton className="size-9 rounded-full shrink-0" />
                                <Skeleton className="h-4 w-32" />
                              </div>
                            </TableCell>
                            <TableCell><Skeleton className="h-8 w-48 mx-auto" /></TableCell>
                            <TableCell className="hidden sm:table-cell"><Skeleton className="h-8 w-full" /></TableCell>
                          </TableRow>
                        ))
                      ) : students.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="h-48 text-center">
                            <div className="flex flex-col items-center gap-2 text-muted-foreground">
                              <ClipboardCheck className="size-12 opacity-30" />
                              <p className="text-sm font-medium">No students loaded</p>
                              <p className="text-xs">Select class, section, and date, then click &quot;Load Students&quot;</p>
                            </div>
                          </TableCell>
                        </TableRow>
                      ) : (
                        students.map((student) => {
                          const effectiveStatus = getEffectiveStatus(student)
                          const effectiveRemarks = getEffectiveRemarks(student)

                          return (
                            <TableRow
                              key={student.id}
                              className={
                                effectiveStatus === 'present'
                                  ? 'bg-emerald-50/50 dark:bg-emerald-950/10'
                                  : effectiveStatus === 'absent'
                                    ? 'bg-rose-50/50 dark:bg-rose-950/10'
                                    : effectiveStatus === 'late'
                                      ? 'bg-amber-50/50 dark:bg-amber-950/10'
                                      : ''
                              }
                            >
                              {/* Roll Number */}
                              <TableCell className="pl-4 font-mono text-sm text-muted-foreground">
                                {student.rollNumber ?? '—'}
                              </TableCell>

                              {/* Student Name with Avatar */}
                              <TableCell>
                                <div className="flex items-center gap-3">
                                  <Avatar className="size-9 shrink-0">
                                    <AvatarFallback className="bg-emerald-100 text-emerald-700 text-xs font-medium dark:bg-emerald-900/30 dark:text-emerald-400">
                                      {getInitials(student.firstName, student.lastName)}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <span className="font-medium text-sm">
                                      {student.firstName} {student.lastName}
                                    </span>
                                    <p className="text-xs text-muted-foreground">{student.admissionNo}</p>
                                  </div>
                                </div>
                              </TableCell>

                              {/* Status Toggle Buttons */}
                              <TableCell>
                                <div className="flex items-center justify-center gap-1">
                                  {/* Present */}
                                  <button
                                    type="button"
                                    onClick={() => handleStatusChange(student.id, 'present')}
                                    className={`
                                      inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium
                                      transition-colors border cursor-pointer
                                      ${effectiveStatus === 'present'
                                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                                        : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50 dark:bg-gray-900 dark:text-emerald-400 dark:border-emerald-800 dark:hover:bg-emerald-950/30'
                                      }
                                    `}
                                  >
                                    <CircleCheck className="size-3.5" />
                                    <span className="hidden sm:inline">Present</span>
                                  </button>

                                  {/* Absent */}
                                  <button
                                    type="button"
                                    onClick={() => handleStatusChange(student.id, 'absent')}
                                    className={`
                                      inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium
                                      transition-colors border cursor-pointer
                                      ${effectiveStatus === 'absent'
                                        ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                                        : 'bg-white text-rose-700 border-rose-200 hover:bg-rose-50 dark:bg-gray-900 dark:text-rose-400 dark:border-rose-800 dark:hover:bg-rose-950/30'
                                      }
                                    `}
                                  >
                                    <XCircle className="size-3.5" />
                                    <span className="hidden sm:inline">Absent</span>
                                  </button>

                                  {/* Late */}
                                  <button
                                    type="button"
                                    onClick={() => handleStatusChange(student.id, 'late')}
                                    className={`
                                      inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium
                                      transition-colors border cursor-pointer
                                      ${effectiveStatus === 'late'
                                        ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                                        : 'bg-white text-amber-700 border-amber-200 hover:bg-amber-50 dark:bg-gray-900 dark:text-amber-400 dark:border-amber-800 dark:hover:bg-amber-950/30'
                                      }
                                    `}
                                  >
                                    <Clock className="size-3.5" />
                                    <span className="hidden sm:inline">Late</span>
                                  </button>
                                </div>
                              </TableCell>

                              {/* Remarks */}
                              <TableCell className="hidden sm:table-cell pr-4">
                                <Input
                                  placeholder="Add remarks..."
                                  value={effectiveRemarks}
                                  onChange={(e) => handleRemarksChange(student.id, e.target.value)}
                                  className="h-8 text-xs"
                                />
                              </TableCell>
                            </TableRow>
                          )
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══════════════════════════════════════════════════════════════════
            TAB 2: ATTENDANCE REPORT
        ═══════════════════════════════════════════════════════════════════ */}
        <TabsContent value="report" className="space-y-6">
          {/* ─── Report Filters ───────────────────────────────────────── */}
          <Card>
            <CardContent className="p-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {/* From Date */}
                <div className="space-y-1.5">
                  <Label htmlFor="report-from" className="text-xs font-medium text-muted-foreground">
                    From Date
                  </Label>
                  <div className="relative">
                    <CalendarDays className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                    <Input
                      id="report-from"
                      type="date"
                      value={reportFrom}
                      onChange={(e) => setReportFrom(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>

                {/* To Date */}
                <div className="space-y-1.5">
                  <Label htmlFor="report-to" className="text-xs font-medium text-muted-foreground">
                    To Date
                  </Label>
                  <div className="relative">
                    <CalendarDays className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                    <Input
                      id="report-to"
                      type="date"
                      value={reportTo}
                      onChange={(e) => setReportTo(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>

                {/* Class Filter (optional) */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-muted-foreground">
                    Class (optional)
                  </Label>
                  <Select
                    value={reportClassId}
                    onValueChange={(val) => setReportClassId(val === '__all__' ? '' : val)}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="All Classes" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__all__">All Classes</SelectItem>
                      {classes.map((cls) => (
                        <SelectItem key={cls.id} value={cls.id}>
                          {cls.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Generate Report */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-muted-foreground invisible">Generate</Label>
                  <Button
                    onClick={fetchReport}
                    disabled={reportLoading || !reportFrom || !reportTo}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                  >
                    {reportLoading ? (
                      <Loader2 className="size-4 mr-2 animate-spin" />
                    ) : (
                      <BarChart3 className="size-4 mr-2" />
                    )}
                    Generate Report
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* ─── Report Error ─────────────────────────────────────────── */}
          {reportError && (
            <Card className="border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950/30">
              <CardContent className="flex items-center gap-3 p-4">
                <AlertCircle className="size-5 text-rose-600 dark:text-rose-400 shrink-0" />
                <p className="text-sm text-rose-700 dark:text-rose-300">{reportError}</p>
                <Button
                  variant="ghost"
                  size="sm"
                  className="ml-auto text-rose-600"
                  onClick={() => setReportError(null)}
                >
                  Dismiss
                </Button>
              </CardContent>
            </Card>
          )}

          {/* ─── Report Loading ───────────────────────────────────────── */}
          {reportLoading && (
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader className="pb-3">
                  <Skeleton className="h-5 w-40" />
                  <Skeleton className="h-4 w-56" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-64 w-full" />
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3">
                  <Skeleton className="h-5 w-48" />
                  <Skeleton className="h-4 w-56" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-64 w-full" />
                </CardContent>
              </Card>
            </div>
          )}

          {/* ─── Class-wise Summary Table ─────────────────────────────── */}
          {!reportLoading && reportClassSummaries.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <BarChart3 className="size-5 text-emerald-600" />
                  Class-wise Attendance Summary
                </CardTitle>
                <CardDescription>
                  {formatDateDisplay(reportFrom)} — {formatDateDisplay(reportTo)}
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="max-h-96">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead className="pl-4">Class</TableHead>
                        <TableHead className="text-center">Total Students</TableHead>
                        <TableHead className="text-center">Avg Attendance %</TableHead>
                        <TableHead className="text-center">Defaulter Count</TableHead>
                        <TableHead className="text-center pr-4">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reportClassSummaries.map((cls) => (
                        <TableRow key={cls.className}>
                          <TableCell className="pl-4 font-medium">{cls.className}</TableCell>
                          <TableCell className="text-center">{cls.totalStudents}</TableCell>
                          <TableCell className="text-center">
                            <div className="flex items-center justify-center gap-2">
                              <Progress
                                value={cls.avgAttendance}
                                className="h-2 w-16"
                              />
                              <span className={`
                                font-semibold text-sm
                                ${cls.avgAttendance >= 85
                                  ? 'text-emerald-600 dark:text-emerald-400'
                                  : cls.avgAttendance >= 75
                                    ? 'text-amber-600 dark:text-amber-400'
                                    : 'text-rose-600 dark:text-rose-400'
                                }
                              `}>
                                {cls.avgAttendance}%
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <span className={`
                              font-semibold
                              ${cls.defaulterCount > 0
                                ? 'text-rose-600 dark:text-rose-400'
                                : 'text-emerald-600 dark:text-emerald-400'
                              }
                            `}>
                              {cls.defaulterCount}
                            </span>
                          </TableCell>
                          <TableCell className="text-center pr-4">
                            <Badge
                              className={
                                cls.avgAttendance >= 85
                                  ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-transparent'
                                  : cls.avgAttendance >= 75
                                    ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-transparent'
                                    : 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400 border-transparent'
                              }
                            >
                              {cls.avgAttendance >= 85
                                ? 'Good'
                                : cls.avgAttendance >= 75
                                  ? 'Warning'
                                  : 'Critical'
                              }
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          )}

          {/* ─── Monthly Detailed Table ───────────────────────────────── */}
          {!reportLoading && reportData && reportData.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <CalendarDays className="size-5 text-emerald-600" />
                  Monthly Attendance Details
                </CardTitle>
                <CardDescription>
                  Attendance percentage by class for each month in the selected range
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="max-h-96">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead className="pl-4 sticky left-0 bg-background z-10">Month</TableHead>
                        {reportData.length > 0 &&
                          reportData[0]?.classes.map((c) => (
                            <TableHead key={c.className} className="text-center">
                              {c.className}
                            </TableHead>
                          ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reportData.map((monthData) => (
                        <TableRow key={monthData.month}>
                          <TableCell className="pl-4 font-medium sticky left-0 bg-background z-10">
                            {formatMonth(monthData.month)}
                          </TableCell>
                          {monthData.classes.map((cls) => (
                            <TableCell key={cls.className} className="text-center">
                              <span className={`
                                inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-semibold
                                ${cls.percentage >= 85
                                  ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
                                  : cls.percentage >= 75
                                    ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
                                    : 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'
                                }
                              `}>
                                {cls.percentage}%
                                <span className="text-[10px] opacity-70">({cls.present}/{cls.total})</span>
                              </span>
                            </TableCell>
                          ))}
                          {monthData.classes.length === 0 && (
                            <TableCell colSpan={99} className="text-center text-muted-foreground text-sm">
                              No data
                            </TableCell>
                          )}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          )}

          {/* ─── Report Empty State ───────────────────────────────────── */}
          {!reportLoading && !reportError && reportData && reportData.length === 0 && (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <BarChart3 className="size-12 text-muted-foreground/30 mb-3" />
                <p className="text-sm font-medium text-muted-foreground">No report data available</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Try adjusting the date range or class filter
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}