'use client'

import React, { useState, useEffect, useCallback } from 'react'
import {
  CalendarDays,
  Clock,
  AlertCircle,
  Users,
  Coffee,
  RefreshCw,
  BookOpen,
} from 'lucide-react'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select'

// ─── Types ──────────────────────────────────────────────────────────────────

interface ClassWithSections {
  id: string
  name: string
  numericLevel: number
  sections: { id: string; name: string }[]
}

interface TimetableEntry {
  id: string
  day: string
  period: number
  startTime: string
  endTime: string
  subjectId: string
  teacherId: string
  subject: { id: string; name: string; code: string }
  teacher: { id: string; firstName: string; lastName: string }
}

type TimetableData = Record<string, TimetableEntry[]>

interface TeacherWorkload {
  name: string
  periods: number
  subjects: string[]
}

// ─── Constants ──────────────────────────────────────────────────────────────

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] as const

const PERIOD_TIMES = [
  { period: 1, start: '8:00', end: '8:45' },
  { period: 2, start: '8:45', end: '9:30' },
  { period: 3, start: '9:30', end: '10:15' },
  { period: 4, start: '10:30', end: '11:15' },
  { period: 5, start: '11:15', end: '12:00' },
  { period: 6, start: '12:45', end: '1:30' },
  { period: 7, start: '1:30', end: '2:15' },
  { period: 8, start: '2:15', end: '3:00' },
] as const

// Subject color palette — no indigo/blue
const SUBJECT_COLORS = [
  { bg: 'bg-emerald-100 dark:bg-emerald-900/30', text: 'text-emerald-800 dark:text-emerald-300', border: 'border-emerald-200 dark:border-emerald-800/50' },
  { bg: 'bg-teal-100 dark:bg-teal-900/30', text: 'text-teal-800 dark:text-teal-300', border: 'border-teal-200 dark:border-teal-800/50' },
  { bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-800 dark:text-amber-300', border: 'border-amber-200 dark:border-amber-800/50' },
  { bg: 'bg-rose-100 dark:bg-rose-900/30', text: 'text-rose-800 dark:text-rose-300', border: 'border-rose-200 dark:border-rose-800/50' },
  { bg: 'bg-cyan-100 dark:bg-cyan-900/30', text: 'text-cyan-800 dark:text-cyan-300', border: 'border-cyan-200 dark:border-cyan-800/50' },
  { bg: 'bg-orange-100 dark:bg-orange-900/30', text: 'text-orange-800 dark:text-orange-300', border: 'border-orange-200 dark:border-orange-800/50' },
  { bg: 'bg-violet-100 dark:bg-violet-900/30', text: 'text-violet-800 dark:text-violet-300', border: 'border-violet-200 dark:border-violet-800/50' },
  { bg: 'bg-lime-100 dark:bg-lime-900/30', text: 'text-lime-800 dark:text-lime-300', border: 'border-lime-200 dark:border-lime-800/50' },
  { bg: 'bg-fuchsia-100 dark:bg-fuchsia-900/30', text: 'text-fuchsia-800 dark:text-fuchsia-300', border: 'border-fuchsia-200 dark:border-fuchsia-800/50' },
  { bg: 'bg-pink-100 dark:bg-pink-900/30', text: 'text-pink-800 dark:text-pink-300', border: 'border-pink-200 dark:border-pink-800/50' },
  { bg: 'bg-sky-100 dark:bg-sky-900/30', text: 'text-sky-800 dark:text-sky-300', border: 'border-sky-200 dark:border-sky-800/50' },
  { bg: 'bg-yellow-100 dark:bg-yellow-900/30', text: 'text-yellow-800 dark:text-yellow-300', border: 'border-yellow-200 dark:border-yellow-800/50' },
  { bg: 'bg-stone-100 dark:bg-stone-900/30', text: 'text-stone-800 dark:text-stone-300', border: 'border-stone-200 dark:border-stone-800/50' },
] as const

// ─── Helpers ────────────────────────────────────────────────────────────────

// Deterministic color assignment per subject name
const subjectColorMap = new Map<string, number>()
let colorIndex = 0

function getSubjectColor(subjectName: string) {
  if (!subjectColorMap.has(subjectName)) {
    subjectColorMap.set(subjectName, colorIndex % SUBJECT_COLORS.length)
    colorIndex++
  }
  return SUBJECT_COLORS[subjectColorMap.get(subjectName)!]
}

// ─── Component ──────────────────────────────────────────────────────────────

export default function TimetableModule() {
  // Data state
  const [classes, setClasses] = useState<ClassWithSections[]>([])
  const [timetable, setTimetable] = useState<TimetableData>({})
  const [loading, setLoading] = useState(false)
  const [timetableLoading, setTimetableLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Filter state
  const [selectedClassId, setSelectedClassId] = useState('')
  const [selectedSectionId, setSelectedSectionId] = useState('')

  // Derived: sections for selected class
  const availableSections = selectedClassId
    ? classes.find((c) => c.id === selectedClassId)?.sections ?? []
    : []

  // ─── Fetch classes ──────────────────────────────────────────────────────

  useEffect(() => {
    async function fetchClasses() {
      setLoading(true)
      try {
        const res = await fetch('/api/classes')
        if (!res.ok) throw new Error('Failed to fetch classes')
        const json = await res.json()
        setClasses(json.data ?? [])
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load classes')
      } finally {
        setLoading(false)
      }
    }
    fetchClasses()
  }, [])

  // ─── Fetch timetable when section changes ──────────────────────────────

  const fetchTimetable = useCallback(async (sectionId: string) => {
    if (!sectionId) {
      setTimetable({})
      return
    }
    setTimetableLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/timetable?sectionId=${sectionId}`)
      if (!res.ok) throw new Error('Failed to fetch timetable')
      const json = await res.json()
      setTimetable(json.data ?? {})
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load timetable')
    } finally {
      setTimetableLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchTimetable(selectedSectionId)
  }, [selectedSectionId, fetchTimetable])

  // Reset section when class changes
  function handleClassChange(classId: string) {
    setSelectedClassId(classId === '__none__' ? '' : classId)
    setSelectedSectionId('')
    setTimetable({})
    subjectColorMap.clear()
    colorIndex = 0
  }

  function handleSectionChange(sectionId: string) {
    setSelectedSectionId(sectionId === '__none__' ? '' : sectionId)
    subjectColorMap.clear()
    colorIndex = 0
  }

  // ─── Compute teacher workload ──────────────────────────────────────────

  function computeTeacherWorkload(): TeacherWorkload[] {
    const teacherMap = new Map<string, { name: string; periods: number; subjects: Set<string> }>()

    for (const day of DAYS) {
      const entries = timetable[day] ?? []
      for (const entry of entries) {
        const key = entry.teacherId
        const existing = teacherMap.get(key)
        const fullName = `${entry.teacher.firstName} ${entry.teacher.lastName}`
        if (existing) {
          existing.periods++
          existing.subjects.add(entry.subject.name)
        } else {
          teacherMap.set(key, {
            name: fullName,
            periods: 1,
            subjects: new Set([entry.subject.name]),
          })
        }
      }
    }

    return Array.from(teacherMap.entries())
      .map(([, data]) => ({
        name: data.name,
        periods: data.periods,
        subjects: Array.from(data.subjects),
      }))
      .sort((a, b) => b.periods - a.periods)
  }

  const teacherWorkload = computeTeacherWorkload()
  const hasTimetable = DAYS.some((day) => (timetable[day]?.length ?? 0) > 0)

  // ─── Get entry for a specific cell ─────────────────────────────────────

  function getEntryForCell(day: string, period: number): TimetableEntry | undefined {
    const entries = timetable[day] ?? []
    return entries.find((e) => e.period === period)
  }

  // ─── Total periods count ───────────────────────────────────────────────

  const totalPeriods = DAYS.reduce((sum, day) => sum + (timetable[day]?.length ?? 0), 0)

  // ─── Period Row Renderer (must be before return) ───────────────────────

  function renderPeriodRow(period: number, pt: { start: string; end: string }) {
    return (
      <div className="grid grid-cols-[140px_repeat(5,1fr)] border-b last:border-b-0">
        {/* Time column */}
        <div className="p-3 border-r bg-muted/30">
          <div className="text-sm font-semibold">P{period}</div>
          <div className="text-[11px] text-muted-foreground tabular-nums">
            {pt.start} – {pt.end}
          </div>
        </div>
        {/* Day cells */}
        {DAYS.map((day) => {
          const entry = getEntryForCell(day, period)
          if (!entry) {
            return (
              <div
                key={day}
                className="p-2 border-r last:border-r-0 min-h-[60px] flex items-center justify-center"
              >
                <span className="text-xs text-muted-foreground/40">—</span>
              </div>
            )
          }
          const color = getSubjectColor(entry.subject.name)
          return (
            <div
              key={day}
              className={`p-2 border-r last:border-r-0 min-h-[60px] ${color.bg} ${color.border}`}
            >
              <p className={`text-sm font-semibold leading-tight ${color.text}`}>
                {entry.subject.name}
              </p>
              <p className="text-[11px] text-muted-foreground mt-1 leading-tight">
                {entry.teacher.firstName} {entry.teacher.lastName}
              </p>
            </div>
          )
        })}
      </div>
    )
  }

  // ─── Render ────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* ─── Top Bar ─────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold tracking-tight">Timetable</h1>
          {hasTimetable && (
            <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400">
              {totalPeriods} periods
            </Badge>
          )}
        </div>
        {error && (
          <Button variant="outline" size="sm" onClick={() => { if (selectedSectionId) fetchTimetable(selectedSectionId) }}>
            <RefreshCw className="size-4 mr-2" />
            Retry
          </Button>
        )}
      </div>

      {/* ─── Class & Section Selectors ────────────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <Select
          value={selectedClassId || '__none__'}
          onValueChange={handleClassChange}
          disabled={loading}
        >
          <SelectTrigger className="w-full sm:w-[200px]">
            <SelectValue placeholder={loading ? 'Loading classes...' : 'Select Class'} />
          </SelectTrigger>
          <SelectContent>
            {classes.map((cls) => (
              <SelectItem key={cls.id} value={cls.id}>
                {cls.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={selectedSectionId || '__none__'}
          onValueChange={handleSectionChange}
          disabled={!selectedClassId || availableSections.length === 0}
        >
          <SelectTrigger className="w-full sm:w-[200px]">
            <SelectValue
              placeholder={
                !selectedClassId
                  ? 'Select a class first'
                  : availableSections.length === 0
                    ? 'No sections available'
                    : 'Select Section'
              }
            />
          </SelectTrigger>
          <SelectContent>
            {availableSections.map((sec) => (
              <SelectItem key={sec.id} value={sec.id}>
                Section {sec.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {selectedClassId && selectedSectionId && hasTimetable && (
          <p className="text-sm text-muted-foreground">
            <CalendarDays className="size-4 inline mr-1" />
            Showing {classes.find((c) => c.id === selectedClassId)?.name} — Section{' '}
            {availableSections.find((s) => s.id === selectedSectionId)?.name}
          </p>
        )}
      </div>

      {/* ─── Error Banner ─────────────────────────────────────────────── */}
      {error && (
        <Card className="border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950/30">
          <CardContent className="flex items-center gap-3 p-4">
            <AlertCircle className="size-5 text-red-600 dark:text-red-400 shrink-0" />
            <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
            <Button
              variant="ghost"
              size="sm"
              className="ml-auto text-red-600"
              onClick={() => setError(null)}
            >
              Dismiss
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ─── Timetable Grid ───────────────────────────────────────────── */}
      {!selectedSectionId ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-20 text-center">
            <div className="rounded-full bg-muted p-4 mb-4">
              <CalendarDays className="size-10 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-1">Select a Class &amp; Section</h3>
            <p className="text-sm text-muted-foreground max-w-md">
              Choose a class and section from the dropdowns above to view the weekly timetable.
            </p>
          </CardContent>
        </Card>
      ) : timetableLoading ? (
        <Card>
          <CardContent className="p-6 space-y-4">
            <div className="flex gap-4">
              <Skeleton className="h-10 w-32 shrink-0" />
              {DAYS.map((day) => (
                <Skeleton key={day} className="h-10 flex-1" />
              ))}
            </div>
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="flex gap-4">
                <Skeleton className="h-16 w-32 shrink-0" />
                {DAYS.map((day) => (
                  <Skeleton key={day} className="h-16 flex-1" />
                ))}
              </div>
            ))}
          </CardContent>
        </Card>
      ) : !hasTimetable ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-20 text-center">
            <div className="rounded-full bg-amber-100 p-4 mb-4 dark:bg-amber-900/30">
              <BookOpen className="size-10 text-amber-600 dark:text-amber-400" />
            </div>
            <h3 className="text-lg font-semibold mb-1">No Timetable Configured</h3>
            <p className="text-sm text-muted-foreground max-w-md">
              No timetable configured for this section. Please contact the administrator to set up the weekly timetable.
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <CalendarDays className="size-5 text-emerald-600 dark:text-emerald-400" />
              Weekly Timetable
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <div className="min-w-[720px]">
                {/* Table Header — Days */}
                <div className="grid grid-cols-[140px_repeat(5,1fr)] border-b bg-muted/50">
                  <div className="p-3 text-sm font-semibold text-muted-foreground border-r">
                    <div className="flex items-center gap-1.5">
                      <Clock className="size-3.5" />
                      Period
                    </div>
                  </div>
                  {DAYS.map((day) => (
                    <div
                      key={day}
                      className="p-3 text-center text-sm font-semibold text-foreground border-r last:border-r-0"
                    >
                      {day}
                    </div>
                  ))}
                </div>

                {/* Table Body — Periods with Break after P4 */}
                {PERIOD_TIMES.map((pt, idx) => {
                  // Insert break row after 4th period (index 4 = period 5 row)
                  if (idx === 4) {
                    return (
                      <React.Fragment key="break-wrapper">
                        {renderPeriodRow(5, pt)}
                        <div className="grid grid-cols-[140px_repeat(5,1fr)] border-b bg-amber-50/60 dark:bg-amber-950/20">
                          <div className="p-3 border-r flex items-center gap-2">
                            <Coffee className="size-4 text-amber-600 dark:text-amber-400" />
                            <div>
                              <div className="text-xs font-semibold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
                                Break
                              </div>
                              <div className="text-[11px] text-amber-600/70 dark:text-amber-500/70">
                                12:00 – 12:45
                              </div>
                            </div>
                          </div>
                          <div className="p-3 text-center text-xs text-amber-600/60 dark:text-amber-500/60 col-span-5 flex items-center justify-center">
                            Lunch Break
                          </div>
                        </div>
                      </React.Fragment>
                    )
                  }
                  return <React.Fragment key={pt.period}>{renderPeriodRow(pt.period, pt)}</React.Fragment>
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ─── Teacher Workload Summary ─────────────────────────────────── */}
      {hasTimetable && teacherWorkload.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Users className="size-5 text-emerald-600 dark:text-emerald-400" />
              Teacher Workload Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="max-h-96">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                {teacherWorkload.map((tw) => {
                  const isOverloaded = tw.periods > 40
                  return (
                    <div
                      key={tw.name}
                      className={`p-4 flex items-start gap-3 border-b sm:border-b-0 sm:border-r lg:border-r border-border last:border-0 ${isOverloaded ? 'bg-rose-50/60 dark:bg-rose-950/20' : ''}`}
                    >
                      <div
                        className={`shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-xs font-bold ${
                          isOverloaded
                            ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300'
                            : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
                        }`}
                      >
                        {tw.name
                          .split(' ')
                          .map((n) => n[0])
                          .join('')
                          .toUpperCase()
                          .slice(0, 2)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-sm font-semibold truncate">{tw.name}</p>
                          {isOverloaded && (
                            <Badge className="bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300 border-transparent text-[10px] px-1.5 py-0">
                              Overloaded
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5 truncate">
                          {tw.subjects.join(', ')}
                        </p>
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full transition-all ${
                                isOverloaded
                                  ? 'bg-rose-500'
                                  : tw.periods > 30
                                    ? 'bg-amber-500'
                                    : 'bg-emerald-500'
                              }`}
                              style={{ width: `${Math.min((tw.periods / 50) * 100, 100)}%` }}
                            />
                          </div>
                          <span
                            className={`text-xs font-semibold tabular-nums shrink-0 ${
                              isOverloaded
                                ? 'text-rose-600 dark:text-rose-400'
                                : tw.periods > 30
                                  ? 'text-amber-600 dark:text-amber-400'
                                  : 'text-emerald-600 dark:text-emerald-400'
                            }`}
                          >
                            {tw.periods}
                            <span className="text-muted-foreground font-normal"> /wk</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  )
}