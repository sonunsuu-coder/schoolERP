'use client'

import React, { useState, useEffect, useCallback, useMemo } from 'react'
import {
  FileText,
  CheckCircle,
  Clock,
  Plus,
  Loader2,
  AlertCircle,
  Trophy,
  Save,
  TrendingUp,
  TrendingDown,
  BarChart3,
} from 'lucide-react'
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, Cell } from 'recharts'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart'

// ─── Types ──────────────────────────────────────────────────────────────────

interface Exam {
  id: string
  name: string
  type: string
  startDate: string
  endDate: string
  status: string
  subjectName: string
  sectionId: string | null
  sectionName: string | null
  maxMarks: number
  className: string | null
  _count?: { marks: number }
  section?: { id: string; name: string; class: { name: string } } | null
}

interface ExamWithMarks extends Exam {
  marks: MarkRecord[]
}

interface MarkRecord {
  id: string
  studentId: string
  examId: string
  marksObtained: number
  grade: string | null
  remarks: string | null
  studentName: string | null
  student?: {
    id: string
    firstName: string
    lastName: string
    admissionNo: string
    rollNumber: string | null
  }
}

interface StudentForMarks {
  id: string
  firstName: string
  lastName: string
  admissionNo: string
  rollNumber: string | null
  sectionId: string | null
}

interface ClassWithSections {
  id: string
  name: string
  numericLevel: number
  sections: { id: string; name: string }[]
}

interface StudentMarkInput {
  studentId: string
  studentName: string
  marksObtained: number | ''
  remarks: string
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function getGrade(percentage: number): string {
  if (percentage >= 90) return 'A+'
  if (percentage >= 80) return 'A'
  if (percentage >= 70) return 'B+'
  if (percentage >= 60) return 'B'
  if (percentage >= 50) return 'C'
  if (percentage >= 40) return 'D'
  return 'F'
}

function getGradeColor(grade: string): string {
  switch (grade) {
    case 'A+': return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
    case 'A': return 'bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400'
    case 'B+': return 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-400'
    case 'B': return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
    case 'C': return 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400'
    case 'D': return 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'
    case 'F': return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
    default: return 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400'
  }
}

function formatDate(dateStr: string) {
  if (!dateStr) return 'N/A'
  try {
    return new Date(dateStr).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    })
  } catch {
    return dateStr
  }
}

function getStatusBadge(status: string) {
  switch (status) {
    case 'completed':
      return (
        <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-transparent">
          <CheckCircle className="size-3 mr-1" />Completed
        </Badge>
      )
    case 'upcoming':
      return (
        <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-transparent">
          <Clock className="size-3 mr-1" />Upcoming
        </Badge>
      )
    case 'ongoing':
      return (
        <Badge className="bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-400 border-transparent">
          <Loader2 className="size-3 mr-1 animate-spin" />Ongoing
        </Badge>
      )
    default:
      return <Badge variant="secondary">{status}</Badge>
  }
}

const chartConfig = {
  count: { label: 'Students', color: '#059669' },
} satisfies import('@/components/ui/chart').ChartConfig

// ─── Component ──────────────────────────────────────────────────────────────

export default function ExamModule() {
  // ── Shared data ──────────────────────────────────────────────────────────
  const [exams, setExams] = useState<Exam[]>([])
  const [classes, setClasses] = useState<ClassWithSections[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // ── Exam List filters ────────────────────────────────────────────────────
  const [filterType, setFilterType] = useState('')
  const [filterStatus, setFilterStatus] = useState('')

  // ── Create Exam dialog ───────────────────────────────────────────────────
  const [createOpen, setCreateOpen] = useState(false)
  const [creating, setCreating] = useState(false)
  const [createForm, setCreateForm] = useState({
    name: '',
    type: '',
    subjectName: '',
    classId: '',
    sectionId: '',
    maxMarks: '100',
    startDate: '',
    endDate: '',
    status: 'upcoming',
  })
  const [formErrors, setFormErrors] = useState<Record<string, string>>({})

  // ── Enter Marks state ────────────────────────────────────────────────────
  const [marksExamId, setMarksExamId] = useState('')
  const [marksLoading, setMarksLoading] = useState(false)
  const [studentsForMarks, setStudentsForMarks] = useState<StudentForMarks[]>([])
  const [markInputs, setMarkInputs] = useState<StudentMarkInput[]>([])
  const [savingMarks, setSavingMarks] = useState(false)
  const [marksSuccess, setMarksSuccess] = useState<string | null>(null)

  // ── Results state ────────────────────────────────────────────────────────
  const [resultsExamId, setResultsExamId] = useState('')
  const [resultsLoading, setResultsLoading] = useState(false)
  const [examResult, setExamResult] = useState<ExamWithMarks | null>(null)

  // ── Available exams for marks entry (completed + upcoming) ───────────────
  const examsForMarks = useMemo(
    () => exams.filter((e) => e.status === 'completed' || e.status === 'upcoming'),
    [exams]
  )

  // ── Available exams for results (any with marks) ─────────────────────────
  const examsForResults = useMemo(
    () => exams.filter((e) => e._count && e._count.marks > 0),
    [exams]
  )

  // ── Summary stats ───────────────────────────────────────────────────────
  const summaryStats = useMemo(() => {
    const total = exams.length
    const completed = exams.filter((e) => e.status === 'completed').length
    const upcoming = exams.filter((e) => e.status === 'upcoming').length
    return { total, completed, upcoming }
  }, [exams])

  // ── Filtered exams for list ──────────────────────────────────────────────
  const filteredExams = useMemo(() => {
    return exams.filter((e) => {
      if (filterType && e.type !== filterType) return false
      if (filterStatus && e.status !== filterStatus) return false
      return true
    })
  }, [exams, filterType, filterStatus])

  // ── Form sections (dependent on class) ───────────────────────────────────
  const formSections = createForm.classId
    ? classes.find((c) => c.id === createForm.classId)?.sections ?? []
    : []

  // ── Chart data for results ───────────────────────────────────────────────
  const gradeDistribution = useMemo(() => {
    if (!examResult || !examResult.marks.length) return []
    const maxMarks = examResult.maxMarks || 100
    const brackets = [
      { grade: 'A+', label: 'A+ (90+)', min: 90, count: 0, color: '#059669' },
      { grade: 'A', label: 'A (80-89)', min: 80, count: 0, color: '#0d9488' },
      { grade: 'B+', label: 'B+ (70-79)', min: 70, count: 0, color: '#0891b2' },
      { grade: 'B', label: 'B (60-69)', min: 60, count: 0, color: '#d97706' },
      { grade: 'C', label: 'C (50-59)', min: 50, count: 0, color: '#ea580c' },
      { grade: 'D', label: 'D (40-49)', min: 40, count: 0, color: '#e11d48' },
      { grade: 'F', label: 'F (<40)', min: 0, count: 0, color: '#dc2626' },
    ]
    for (const mark of examResult.marks) {
      const pct = maxMarks > 0 ? (mark.marksObtained / maxMarks) * 100 : 0
      if (pct >= 90) brackets[0].count++
      else if (pct >= 80) brackets[1].count++
      else if (pct >= 70) brackets[2].count++
      else if (pct >= 60) brackets[3].count++
      else if (pct >= 50) brackets[4].count++
      else if (pct >= 40) brackets[5].count++
      else brackets[6].count++
    }
    return brackets.map((b) => ({ ...b, count: b.count, fill: b.color }))
  }, [examResult])

  // ── Results table data ───────────────────────────────────────────────────
  const resultsTableData = useMemo(() => {
    if (!examResult) return []
    const maxMarks = examResult.maxMarks || 100
    const sorted = [...examResult.marks].sort(
      (a, b) => b.marksObtained - a.marksObtained
    )
    const highest = sorted[0]?.marksObtained ?? 0

    return sorted.map((m, idx) => {
      const name =
        m.student?.firstName && m.student?.lastName
          ? `${m.student.firstName} ${m.student.lastName}`
          : m.studentName ?? 'Unknown'
      const pct = maxMarks > 0 ? (m.marksObtained / maxMarks) * 100 : 0
      const grade = getGrade(pct)
      const isTopper = m.marksObtained === highest && idx === 0
      return {
        rank: idx + 1,
        studentId: m.studentId,
        name,
        rollNo: m.student?.rollNumber ?? m.student?.admissionNo ?? '—',
        marksObtained: m.marksObtained,
        percentage: pct.toFixed(1),
        grade,
        isTopper,
        pass: pct >= 40,
      }
    })
  }, [examResult])

  const resultsStats = useMemo(() => {
    if (!resultsTableData.length) return null
    const percentages = resultsTableData.map((r) => parseFloat(r.percentage))
    const avg = (percentages.reduce((a, b) => a + b, 0) / percentages.length).toFixed(1)
    const highest = Math.max(...percentages).toFixed(1)
    const lowest = Math.min(...percentages).toFixed(1)
    const passCount = resultsTableData.filter((r) => r.pass).length
    const passRate = ((passCount / resultsTableData.length) * 100).toFixed(1)
    return { avg, highest, lowest, passRate, total: resultsTableData.length }
  }, [resultsTableData])

  // ─── Fetch classes ───────────────────────────────────────────────────────

  useEffect(() => {
    async function fetchClasses() {
      try {
        const res = await fetch('/api/classes')
        if (!res.ok) throw new Error('Failed to fetch classes')
        const json = await res.json()
        setClasses(json.data ?? [])
      } catch (err) {
        console.error(err)
      }
    }
    fetchClasses()
  }, [])

  // ─── Fetch exams ─────────────────────────────────────────────────────────

  const fetchExams = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/exams')
      if (!res.ok) throw new Error('Failed to fetch exams')
      const json = await res.json()
      setExams(json.data ?? [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchExams()
  }, [fetchExams])

  // ─── Create Exam ─────────────────────────────────────────────────────────

  function openCreateDialog() {
    setCreateForm({
      name: '',
      type: '',
      subjectName: '',
      classId: '',
      sectionId: '',
      maxMarks: '100',
      startDate: '',
      endDate: '',
      status: 'upcoming',
    })
    setFormErrors({})
    setCreateOpen(true)
  }

  function validateCreateForm(): boolean {
    const errors: Record<string, string> = {}
    if (!createForm.name.trim()) errors.name = 'Exam name is required'
    if (!createForm.type) errors.type = 'Type is required'
    if (!createForm.subjectName.trim()) errors.subjectName = 'Subject is required'
    if (!createForm.classId) errors.classId = 'Class is required'
    if (!createForm.sectionId) errors.sectionId = 'Section is required'
    if (!createForm.startDate) errors.startDate = 'Start date is required'
    if (!createForm.endDate) errors.endDate = 'End date is required'
    if (createForm.maxMarks && Number(createForm.maxMarks) <= 0) errors.maxMarks = 'Must be > 0'
    setFormErrors(errors)
    return Object.keys(errors).length === 0
  }

  async function handleCreateExam() {
    if (!validateCreateForm()) return
    setCreating(true)
    try {
      const selectedClass = classes.find((c) => c.id === createForm.classId)
      const selectedSection = formSections.find((s) => s.id === createForm.sectionId)

      const payload = {
        ...createForm,
        maxMarks: Number(createForm.maxMarks) || 100,
        className: selectedClass?.name ?? null,
        sectionName: selectedSection?.name ?? null,
        schoolId: 'school_1', // Default school
      }

      const res = await fetch('/api/exams', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })

      if (!res.ok) throw new Error('Failed to create exam')
      setCreateOpen(false)
      fetchExams()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create exam')
    } finally {
      setCreating(false)
    }
  }

  // ─── Enter Marks: Load students for selected exam ────────────────────────

  useEffect(() => {
    if (!marksExamId) {
      setStudentsForMarks([])
      setMarkInputs([])
      return
    }

    async function loadExamForMarks() {
      setMarksLoading(true)
      setMarksSuccess(null)
      try {
        // Fetch exam detail to get marks + section
        const res = await fetch(`/api/exams/${marksExamId}`)
        if (!res.ok) throw new Error('Failed to fetch exam')
        const json = await res.json()
        const exam: ExamWithMarks = json.data

        // Get sectionId from exam
        const sectionId = exam.sectionId
        if (!sectionId) {
          setStudentsForMarks([])
          setMarkInputs([])
          setMarksLoading(false)
          return
        }

        // Fetch all active students for the section
        const stuRes = await fetch(
          `/api/students?sectionId=${sectionId}&status=active&limit=100`
        )
        if (!stuRes.ok) throw new Error('Failed to fetch students')
        const stuJson = await stuRes.json()
        const students: StudentForMarks[] = stuJson.data ?? []

        // Build mark inputs: pre-fill with existing marks if any
        const existingMarksMap = new Map<string, number | ''>()
        const existingRemarksMap = new Map<string, string>()
        for (const m of exam.marks) {
          existingMarksMap.set(m.studentId, m.marksObtained)
          existingRemarksMap.set(m.studentId, m.remarks ?? '')
        }

        const inputs: StudentMarkInput[] = students.map((s) => ({
          studentId: s.id,
          studentName: `${s.firstName} ${s.lastName}`,
          marksObtained: existingMarksMap.get(s.id) ?? '',
          remarks: existingRemarksMap.get(s.id) ?? '',
        }))

        setStudentsForMarks(students)
        setMarkInputs(inputs)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load exam data')
      } finally {
        setMarksLoading(false)
      }
    }

    loadExamForMarks()
  }, [marksExamId])

  function updateMarkInput(
    studentId: string,
    field: 'marksObtained' | 'remarks',
    value: string | number
  ) {
    setMarkInputs((prev) =>
      prev.map((m) => (m.studentId === studentId ? { ...m, [field]: value } : m))
    )
  }

  async function handleSaveMarks() {
    if (!marksExamId) return
    const exam = exams.find((e) => e.id === marksExamId)
    const maxMarks = exam?.maxMarks ?? 100

    // Build payload
    const marks = markInputs.map((m) => {
      const obtained = typeof m.marksObtained === 'number' ? m.marksObtained : 0
      const pct = maxMarks > 0 ? (obtained / maxMarks) * 100 : 0
      return {
        studentId: m.studentId,
        studentName: m.studentName,
        marksObtained: obtained,
        grade: getGrade(pct),
        remarks: m.remarks || null,
      }
    })

    setSavingMarks(true)
    setMarksSuccess(null)
    try {
      const res = await fetch(`/api/exams/${marksExamId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ marks }),
      })

      if (!res.ok) throw new Error('Failed to save marks')
      setMarksSuccess('Marks saved successfully!')
      fetchExams()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save marks')
    } finally {
      setSavingMarks(false)
    }
  }

  // ─── Results: Load exam results ──────────────────────────────────────────

  useEffect(() => {
    if (!resultsExamId) {
      setExamResult(null)
      return
    }

    async function loadResults() {
      setResultsLoading(true)
      try {
        const res = await fetch(`/api/exams/${resultsExamId}`)
        if (!res.ok) throw new Error('Failed to fetch exam')
        const json = await res.json()
        setExamResult(json.data)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load results')
      } finally {
        setResultsLoading(false)
      }
    }

    loadResults()
  }, [resultsExamId])

  // ─── Render ─────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* ─── Top Bar ─────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold tracking-tight">Examinations</h1>
        </div>
        <Button
          onClick={openCreateDialog}
          className="bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          <Plus className="size-4 mr-2" />
          Create Exam
        </Button>
      </div>

      {/* ─── Summary Cards ───────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex size-12 items-center justify-center rounded-xl bg-emerald-100 dark:bg-emerald-900/30">
              <FileText className="size-6 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Exams</p>
              <p className="text-2xl font-bold">{summaryStats.total}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex size-12 items-center justify-center rounded-xl bg-emerald-100 dark:bg-emerald-900/30">
              <CheckCircle className="size-6 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Completed</p>
              <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
                {summaryStats.completed}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex size-12 items-center justify-center rounded-xl bg-amber-100 dark:bg-amber-900/30">
              <Clock className="size-6 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Upcoming</p>
              <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">
                {summaryStats.upcoming}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ─── Error Banner ────────────────────────────────────────────── */}
      {error && (
        <Card className="border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950/30">
          <CardContent className="flex items-center gap-3 p-4">
            <AlertCircle className="size-5 text-red-600 dark:text-red-400 shrink-0" />
            <p className="text-sm text-red-700 dark:text-red-300 flex-1">{error}</p>
            <Button
              variant="ghost"
              size="sm"
              className="text-red-600"
              onClick={() => setError(null)}
            >
              Dismiss
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ─── Tabs ────────────────────────────────────────────────────── */}
      <Tabs defaultValue="exam-list" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3 sm:w-[400px]">
          <TabsTrigger value="exam-list">Exam List</TabsTrigger>
          <TabsTrigger value="enter-marks">Enter Marks</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
        </TabsList>

        {/* ────────────────────────────────────────────────────────────── */}
        {/* EXAM LIST TAB                                               */}
        {/* ────────────────────────────────────────────────────────────── */}
        <TabsContent value="exam-list" className="space-y-4">
          {/* Filters */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <Select
              value={filterType}
              onValueChange={(val) => setFilterType(val === '__all__' ? '' : val)}
            >
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">All Types</SelectItem>
                <SelectItem value="Unit Test">Unit Test</SelectItem>
                <SelectItem value="Mid Term">Mid Term</SelectItem>
                <SelectItem value="Annual">Annual</SelectItem>
                <SelectItem value="Final">Final</SelectItem>
                <SelectItem value="Quiz">Quiz</SelectItem>
                <SelectItem value="Practical">Practical</SelectItem>
              </SelectContent>
            </Select>
            <Select
              value={filterStatus}
              onValueChange={(val) => setFilterStatus(val === '__all__' ? '' : val)}
            >
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">All Status</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="upcoming">Upcoming</SelectItem>
                <SelectItem value="ongoing">Ongoing</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground ml-auto">
              {filteredExams.length} exam{filteredExams.length !== 1 ? 's' : ''}
            </p>
          </div>

          {/* Table */}
          <Card>
            <CardContent className="p-0">
              <ScrollArea className="max-h-[500px]">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead className="pl-4">Exam Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead className="hidden sm:table-cell">Subject</TableHead>
                        <TableHead className="hidden md:table-cell">Class</TableHead>
                        <TableHead className="hidden md:table-cell">Section</TableHead>
                        <TableHead className="hidden lg:table-cell">Start Date</TableHead>
                        <TableHead className="hidden lg:table-cell">Max Marks</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="hidden sm:table-cell text-right pr-4">Marks</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loading ? (
                        Array.from({ length: 8 }).map((_, i) => (
                          <TableRow key={i} className="hover:bg-transparent">
                            <TableCell className="pl-4"><Skeleton className="h-4 w-40" /></TableCell>
                            <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                            <TableCell className="hidden sm:table-cell"><Skeleton className="h-4 w-16" /></TableCell>
                            <TableCell className="hidden md:table-cell"><Skeleton className="h-4 w-14" /></TableCell>
                            <TableCell className="hidden md:table-cell"><Skeleton className="h-4 w-10" /></TableCell>
                            <TableCell className="hidden lg:table-cell"><Skeleton className="h-4 w-24" /></TableCell>
                            <TableCell className="hidden lg:table-cell"><Skeleton className="h-4 w-16" /></TableCell>
                            <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                            <TableCell className="hidden sm:table-cell"><Skeleton className="h-4 w-12 ml-auto" /></TableCell>
                          </TableRow>
                        ))
                      ) : filteredExams.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={9} className="h-40 text-center">
                            <div className="flex flex-col items-center gap-2 text-muted-foreground">
                              <FileText className="size-10 opacity-40" />
                              <p className="text-sm font-medium">No exams found</p>
                              <p className="text-xs">Try adjusting your filters or create a new exam</p>
                            </div>
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredExams.map((exam) => {
                          const className =
                            exam.className ?? exam.section?.class?.name ?? '—'
                          const sectionName =
                            exam.sectionName ?? exam.section?.name ?? '—'
                          return (
                            <TableRow key={exam.id} className="group">
                              <TableCell className="pl-4">
                                <div className="font-medium">{exam.name}</div>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline" className="font-normal">
                                  {exam.type}
                                </Badge>
                              </TableCell>
                              <TableCell className="hidden sm:table-cell">
                                {exam.subjectName}
                              </TableCell>
                              <TableCell className="hidden md:table-cell">
                                {className}
                              </TableCell>
                              <TableCell className="hidden md:table-cell">
                                {sectionName}
                              </TableCell>
                              <TableCell className="hidden lg:table-cell text-sm">
                                {formatDate(exam.startDate)}
                              </TableCell>
                              <TableCell className="hidden lg:table-cell font-mono">
                                {exam.maxMarks}
                              </TableCell>
                              <TableCell>{getStatusBadge(exam.status)}</TableCell>
                              <TableCell className="hidden sm:table-cell text-right pr-4">
                                <span className="text-sm text-muted-foreground">
                                  {exam._count?.marks ?? 0}
                                </span>
                              </TableCell>
                            </TableRow>
                          )
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ────────────────────────────────────────────────────────────── */}
        {/* ENTER MARKS TAB                                              */}
        {/* ────────────────────────────────────────────────────────────── */}
        <TabsContent value="enter-marks" className="space-y-4">
          {/* Exam selector */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <div className="space-y-2 flex-1 sm:max-w-sm">
              <Label htmlFor="marksExam">Select Exam</Label>
              <Select
                value={marksExamId}
                onValueChange={(val) => setMarksExamId(val === '__none__' ? '' : val)}
              >
                <SelectTrigger id="marksExam">
                  <SelectValue placeholder="Choose an exam..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">Select an exam</SelectItem>
                  {examsForMarks.map((exam) => {
                    const cls = exam.className ?? exam.section?.class?.name ?? '—'
                    const sec = exam.sectionName ?? exam.section?.name ?? '—'
                    return (
                      <SelectItem key={exam.id} value={exam.id}>
                        {exam.name} — {exam.subjectName} ({cls} {sec})
                      </SelectItem>
                    )
                  })}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Success message */}
          {marksSuccess && (
            <Card className="border-emerald-200 bg-emerald-50 dark:border-emerald-900 dark:bg-emerald-950/30">
              <CardContent className="flex items-center gap-3 p-4">
                <CheckCircle className="size-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <p className="text-sm text-emerald-700 dark:text-emerald-300">{marksSuccess}</p>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-emerald-600 ml-auto"
                  onClick={() => setMarksSuccess(null)}
                >
                  Dismiss
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Marks table */}
          {!marksExamId ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center h-40 text-muted-foreground">
                <FileText className="size-10 opacity-40 mb-2" />
                <p className="text-sm font-medium">Select an exam to enter marks</p>
                <p className="text-xs">Choose from completed or upcoming exams above</p>
              </CardContent>
            </Card>
          ) : marksLoading ? (
            <Card>
              <CardContent className="p-4 space-y-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex gap-4">
                    <Skeleton className="h-10 flex-1" />
                    <Skeleton className="h-10 w-24" />
                    <Skeleton className="h-10 w-20" />
                  </div>
                ))}
              </CardContent>
            </Card>
          ) : markInputs.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center h-40 text-muted-foreground">
                <FileText className="size-10 opacity-40 mb-2" />
                <p className="text-sm font-medium">No students found for this exam</p>
                <p className="text-xs">This exam may not have a section assigned</p>
              </CardContent>
            </Card>
          ) : (
            <>
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">
                    Enter Marks
                    <span className="text-sm font-normal text-muted-foreground ml-2">
                      ({markInputs.length} students)
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="max-h-[450px]">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="hover:bg-transparent">
                            <TableHead className="pl-4 w-[40px]">#</TableHead>
                            <TableHead>Student Name</TableHead>
                            <TableHead className="hidden sm:table-cell">Roll No</TableHead>
                            <TableHead className="w-[140px]">Marks</TableHead>
                            <TableHead className="hidden sm:table-cell w-[80px]">Max</TableHead>
                            <TableHead className="w-[70px]">Grade</TableHead>
                            <TableHead className="hidden md:table-cell w-[160px]">Remarks</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {markInputs.map((input, idx) => {
                            const maxMarks =
                              exams.find((e) => e.id === marksExamId)?.maxMarks ?? 100
                            const obtained =
                              typeof input.marksObtained === 'number'
                                ? input.marksObtained
                                : 0
                            const pct = maxMarks > 0 ? (obtained / maxMarks) * 100 : 0
                            const grade =
                              input.marksObtained !== '' ? getGrade(pct) : '—'

                            return (
                              <TableRow key={input.studentId}>
                                <TableCell className="pl-4 text-muted-foreground text-sm">
                                  {idx + 1}
                                </TableCell>
                                <TableCell className="font-medium">
                                  {input.studentName}
                                </TableCell>
                                <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                                  {studentsForMarks.find(
                                    (s) => s.id === input.studentId
                                  )?.rollNumber ??
                                    studentsForMarks.find(
                                      (s) => s.id === input.studentId
                                    )?.admissionNo ??
                                    '—'}
                                </TableCell>
                                <TableCell>
                                  <Input
                                    type="number"
                                    min={0}
                                    max={maxMarks}
                                    value={input.marksObtained === '' ? '' : input.marksObtained}
                                    onChange={(e) => {
                                      const val = e.target.value
                                      if (val === '') {
                                        updateMarkInput(input.studentId, 'marksObtained', '')
                                      } else {
                                        const num = parseFloat(val)
                                        if (!isNaN(num)) {
                                          updateMarkInput(
                                            input.studentId,
                                            'marksObtained',
                                            Math.min(num, maxMarks)
                                          )
                                        }
                                      }
                                    }}
                                    className="h-9 w-[100px]"
                                    placeholder="0"
                                  />
                                </TableCell>
                                <TableCell className="hidden sm:table-cell font-mono text-sm text-muted-foreground">
                                  {maxMarks}
                                </TableCell>
                                <TableCell>
                                  <Badge
                                    variant="secondary"
                                    className={input.marksObtained !== '' ? getGradeColor(grade) : ''}
                                  >
                                    {grade}
                                  </Badge>
                                </TableCell>
                                <TableCell className="hidden md:table-cell">
                                  <Input
                                    value={input.remarks}
                                    onChange={(e) =>
                                      updateMarkInput(input.studentId, 'remarks', e.target.value)
                                    }
                                    className="h-9"
                                    placeholder="Optional"
                                  />
                                </TableCell>
                              </TableRow>
                            )
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <div className="flex justify-end">
                <Button
                  onClick={handleSaveMarks}
                  disabled={savingMarks}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  {savingMarks ? (
                    <Loader2 className="size-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="size-4 mr-2" />
                  )}
                  Save Marks
                </Button>
              </div>
            </>
          )}
        </TabsContent>

        {/* ────────────────────────────────────────────────────────────── */}
        {/* RESULTS TAB                                                  */}
        {/* ────────────────────────────────────────────────────────────── */}
        <TabsContent value="results" className="space-y-4">
          {/* Exam selector */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <div className="space-y-2 flex-1 sm:max-w-sm">
              <Label htmlFor="resultsExam">Select Exam</Label>
              <Select
                value={resultsExamId}
                onValueChange={(val) =>
                  setResultsExamId(val === '__none__' ? '' : val)
                }
              >
                <SelectTrigger id="resultsExam">
                  <SelectValue placeholder="Choose an exam with marks..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">Select an exam</SelectItem>
                  {examsForResults.map((exam) => {
                    const cls =
                      exam.className ?? exam.section?.class?.name ?? '—'
                    const sec =
                      exam.sectionName ?? exam.section?.name ?? '—'
                    return (
                      <SelectItem key={exam.id} value={exam.id}>
                        {exam.name} — {exam.subjectName} ({cls} {sec})
                        <span className="text-muted-foreground ml-1">
                          [{exam._count?.marks ?? 0} marks]
                        </span>
                      </SelectItem>
                    )
                  })}
                </SelectContent>
              </Select>
            </div>
          </div>

          {!resultsExamId ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center h-40 text-muted-foreground">
                <BarChart3 className="size-10 opacity-40 mb-2" />
                <p className="text-sm font-medium">Select an exam to view results</p>
                <p className="text-xs">
                  Only exams with marks entered will appear in the dropdown
                </p>
              </CardContent>
            </Card>
          ) : resultsLoading ? (
            <Card>
              <CardContent className="p-4 space-y-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </CardContent>
            </Card>
          ) : !examResult || examResult.marks.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center h-40 text-muted-foreground">
                <BarChart3 className="size-10 opacity-40 mb-2" />
                <p className="text-sm font-medium">No marks data available</p>
                <p className="text-xs">Enter marks first to view results</p>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Results Table */}
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">
                      {examResult.name} — {examResult.subjectName}
                      <span className="text-sm font-normal text-muted-foreground ml-2">
                        ({examResult.className} {examResult.sectionName})
                      </span>
                    </CardTitle>
                    <Badge variant="outline">Max: {examResult.maxMarks}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="max-h-[450px]">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="hover:bg-transparent">
                            <TableHead className="w-[60px] pl-4">Rank</TableHead>
                            <TableHead>Student Name</TableHead>
                            <TableHead className="hidden sm:table-cell">Roll No</TableHead>
                            <TableHead className="w-[100px]">Marks</TableHead>
                            <TableHead className="w-[90px]">Percentage</TableHead>
                            <TableHead className="w-[70px]">Grade</TableHead>
                            <TableHead className="w-[80px]">Status</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {resultsTableData.map((row) => (
                            <TableRow
                              key={row.studentId}
                              className={row.isTopper ? 'bg-emerald-50 dark:bg-emerald-950/20' : ''}
                            >
                              <TableCell className="pl-4">
                                {row.isTopper ? (
                                  <div className="flex items-center gap-1.5">
                                    <Trophy className="size-4 text-amber-500" />
                                    <span className="font-bold text-emerald-700 dark:text-emerald-400">
                                      {row.rank}
                                    </span>
                                  </div>
                                ) : (
                                  <span className="text-muted-foreground">
                                    {row.rank}
                                  </span>
                                )}
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <span className="font-medium">{row.name}</span>
                                  {row.isTopper && (
                                    <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-transparent text-[10px] px-1.5">
                                      Topper
                                    </Badge>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                                {row.rollNo}
                              </TableCell>
                              <TableCell className="font-mono font-medium">
                                {row.marksObtained}
                              </TableCell>
                              <TableCell className="font-mono text-sm">
                                {row.percentage}%
                              </TableCell>
                              <TableCell>
                                <Badge
                                  variant="secondary"
                                  className={getGradeColor(row.grade)}
                                >
                                  {row.grade}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  className={
                                    row.pass
                                      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-transparent'
                                      : 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400 border-transparent'
                                  }
                                >
                                  {row.pass ? 'Pass' : 'Fail'}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Stats Row */}
              {resultsStats && (
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
                  <Card>
                    <CardContent className="p-4 text-center">
                      <p className="text-xs text-muted-foreground">Class Average</p>
                      <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                        {resultsStats.avg}%
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
                        <TrendingUp className="size-3" /> Highest
                      </p>
                      <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                        {resultsStats.highest}%
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
                        <TrendingDown className="size-3" /> Lowest
                      </p>
                      <p className="text-xl font-bold text-rose-600 dark:text-rose-400">
                        {resultsStats.lowest}%
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <p className="text-xs text-muted-foreground">Pass Rate</p>
                      <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                        {resultsStats.passRate}%
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <p className="text-xs text-muted-foreground">Students</p>
                      <p className="text-xl font-bold">{resultsStats.total}</p>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Grade Distribution Chart */}
              {gradeDistribution.length > 0 && (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <BarChart3 className="size-4" />
                      Grade Distribution
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ChartContainer config={chartConfig} className="h-[250px] w-full">
                      <BarChart
                        data={gradeDistribution}
                        margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis
                          dataKey="grade"
                          tickLine={false}
                          axisLine={false}
                          fontSize={12}
                        />
                        <YAxis
                          tickLine={false}
                          axisLine={false}
                          fontSize={12}
                          allowDecimals={false}
                        />
                        <ChartTooltip
                          cursor={false}
                          content={<ChartTooltipContent hideLabel />}
                        />
                        <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                          {gradeDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ChartContainer>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>

      {/* ─── Create Exam Dialog ───────────────────────────────────────── */}
      <Dialog open={createOpen} onOpenChange={(open) => { if (!open) setCreateOpen(false) }}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Exam</DialogTitle>
            <DialogDescription>
              Fill in the details to create a new examination.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="examName">Exam Name <span className="text-red-500">*</span></Label>
              <Input
                id="examName"
                value={createForm.name}
                onChange={(e) => setCreateForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="e.g. Unit Test 1"
              />
              {formErrors.name && <p className="text-xs text-red-500">{formErrors.name}</p>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="examType">Type <span className="text-red-500">*</span></Label>
                <Select
                  value={createForm.type}
                  onValueChange={(val) => setCreateForm((f) => ({ ...f, type: val }))}
                >
                  <SelectTrigger id="examType">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Unit Test">Unit Test</SelectItem>
                    <SelectItem value="Mid Term">Mid Term</SelectItem>
                    <SelectItem value="Annual">Annual</SelectItem>
                    <SelectItem value="Final">Final</SelectItem>
                    <SelectItem value="Quiz">Quiz</SelectItem>
                    <SelectItem value="Practical">Practical</SelectItem>
                  </SelectContent>
                </Select>
                {formErrors.type && <p className="text-xs text-red-500">{formErrors.type}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="examSubject">Subject <span className="text-red-500">*</span></Label>
                <Input
                  id="examSubject"
                  value={createForm.subjectName}
                  onChange={(e) => setCreateForm((f) => ({ ...f, subjectName: e.target.value }))}
                  placeholder="e.g. Mathematics"
                />
                {formErrors.subjectName && (
                  <p className="text-xs text-red-500">{formErrors.subjectName}</p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="examClass">Class <span className="text-red-500">*</span></Label>
                <Select
                  value={createForm.classId}
                  onValueChange={(val) =>
                    setCreateForm((f) => ({ ...f, classId: val, sectionId: '' }))
                  }
                >
                  <SelectTrigger id="examClass">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes.map((cls) => (
                      <SelectItem key={cls.id} value={cls.id}>
                        {cls.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {formErrors.classId && (
                  <p className="text-xs text-red-500">{formErrors.classId}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="examSection">Section <span className="text-red-500">*</span></Label>
                <Select
                  value={createForm.sectionId}
                  onValueChange={(val) =>
                    setCreateForm((f) => ({ ...f, sectionId: val }))
                  }
                >
                  <SelectTrigger id="examSection">
                    <SelectValue placeholder="Select section" />
                  </SelectTrigger>
                  <SelectContent>
                    {formSections.map((sec) => (
                      <SelectItem key={sec.id} value={sec.id}>
                        {sec.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {formErrors.sectionId && (
                  <p className="text-xs text-red-500">{formErrors.sectionId}</p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="maxMarks">Max Marks</Label>
                <Input
                  id="maxMarks"
                  type="number"
                  min={1}
                  value={createForm.maxMarks}
                  onChange={(e) => setCreateForm((f) => ({ ...f, maxMarks: e.target.value }))}
                />
                {formErrors.maxMarks && (
                  <p className="text-xs text-red-500">{formErrors.maxMarks}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="startDate">Start Date <span className="text-red-500">*</span></Label>
                <Input
                  id="startDate"
                  type="date"
                  value={createForm.startDate}
                  onChange={(e) => setCreateForm((f) => ({ ...f, startDate: e.target.value }))}
                />
                {formErrors.startDate && (
                  <p className="text-xs text-red-500">{formErrors.startDate}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="endDate">End Date <span className="text-red-500">*</span></Label>
                <Input
                  id="endDate"
                  type="date"
                  value={createForm.endDate}
                  onChange={(e) => setCreateForm((f) => ({ ...f, endDate: e.target.value }))}
                />
                {formErrors.endDate && (
                  <p className="text-xs text-red-500">{formErrors.endDate}</p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={createForm.status}
                onValueChange={(val) => setCreateForm((f) => ({ ...f, status: val }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="upcoming">Upcoming</SelectItem>
                  <SelectItem value="ongoing">Ongoing</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="gap-2 pt-4">
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleCreateExam}
              disabled={creating}
              className="bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              {creating ? (
                <Loader2 className="size-4 mr-2 animate-spin" />
              ) : (
                <Plus className="size-4 mr-2" />
              )}
              Create Exam
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}