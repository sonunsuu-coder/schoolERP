'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  GraduationCap,
  UserCheck,
  IndianRupee,
  Users,
  Info,
  TriangleAlert,
  CheckCircle,
  AlertCircle,
  CalendarDays,
  ClipboardList,
  UserPlus,
  BarChart3,
} from 'lucide-react'
import {
  AreaChart,
  BarChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Area,
  Bar,
} from 'recharts'

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  type ChartConfig,
} from '@/components/ui/chart'

// ─── Types ───────────────────────────────────────────────────────────────────

interface DashboardData {
  totalStudents: number
  totalTeachers: number
  totalStaff: number
  todayAttendancePercentage: number
  feeCollection: {
    collectedThisMonth: number
    outstandingAmount: number
  }
  upcomingEvents: Array<{
    id: string
    title: string
    description: string | null
    date: string
    endDate: string | null
    venue: string | null
    type: string
    status: string
  }>
  recentNotifications: Array<{
    id: string
    title: string
    message: string
    type: string
    targetRole: string | null
    isRead: boolean
    createdAt: string
  }>
  monthlyAttendanceTrend: Array<{
    month: string
    percentage: number
    total: number
    present: number
  }>
  feeCollectionTrend: Array<{
    month: string
    amount: number
  }>
  genderDistribution: Array<{
    gender: string
    count: number
  }>
  classWiseEnrollment: Array<{
    className: string
    count: number
  }>
  revenueVsExpense: Array<{
    month: string
    revenue: number
    expense: number
  }>
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatIndianCurrency(amount: number): string {
  return '₹' + amount.toLocaleString('en-IN')
}

function formatMonthShort(monthStr: string): string {
  // "2025-07" -> "Jul"
  const date = new Date(monthStr + '-01')
  return date.toLocaleDateString('en-US', { month: 'short' })
}

function getTimeAgo(dateStr: string): string {
  const now = new Date()
  const date = new Date(dateStr)
  const diffMs = now.getTime() - date.getTime()
  const diffMins = Math.floor(diffMs / 60000)
  const diffHours = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffMs / 86400000)

  if (diffMins < 1) return 'Just now'
  if (diffMins < 60) return `${diffMins}m ago`
  if (diffHours < 24) return `${diffHours}h ago`
  if (diffDays < 7) return `${diffDays}d ago`
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

function getNotificationIcon(type: string) {
  switch (type) {
    case 'info':
      return <Info className="h-4 w-4 text-sky-500" />
    case 'warning':
      return <TriangleAlert className="h-4 w-4 text-amber-500" />
    case 'success':
      return <CheckCircle className="h-4 w-4 text-emerald-500" />
    case 'alert':
      return <AlertCircle className="h-4 w-4 text-rose-500" />
    default:
      return <Info className="h-4 w-4 text-sky-500" />
  }
}

function getNotificationBadgeVariant(
  type: string
): 'default' | 'secondary' | 'destructive' | 'outline' {
  switch (type) {
    case 'warning':
      return 'secondary'
    case 'success':
      return 'default'
    case 'alert':
      return 'destructive'
    default:
      return 'outline'
  }
}

function getEventBadgeVariant(
  type: string
): 'default' | 'secondary' | 'destructive' | 'outline' {
  switch (type) {
    case 'sports':
      return 'default'
    case 'cultural':
      return 'secondary'
    case 'academic':
      return 'outline'
    case 'holiday':
      return 'secondary'
    default:
      return 'outline'
  }
}

// ─── Chart Configs ───────────────────────────────────────────────────────────

const attendanceChartConfig = {
  attendance: { label: 'Attendance %', color: 'hsl(160, 84%, 39%)' },
} satisfies ChartConfig

const feeCollectionChartConfig = {
  amount: { label: 'Collected', color: 'hsl(160, 84%, 39%)' },
} satisfies ChartConfig

const enrollmentChartConfig = {
  count: { label: 'Students', color: 'hsl(174, 72%, 40%)' },
} satisfies ChartConfig

const revenueExpenseChartConfig = {
  revenue: { label: 'Income', color: 'hsl(160, 84%, 39%)' },
  expense: { label: 'Expense', color: 'hsl(346, 77%, 50%)' },
} satisfies ChartConfig

// ─── Circular Progress ──────────────────────────────────────────────────────

function CircularProgress({
  percentage,
  size = 48,
  strokeWidth = 4,
}: {
  percentage: number
  size?: number
  strokeWidth?: number
}) {
  const radius = (size - strokeWidth) / 2
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (percentage / 100) * circumference

  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke="currentColor"
        strokeWidth={strokeWidth}
        className="text-muted/30"
      />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke="hsl(160, 84%, 39%)"
        strokeWidth={strokeWidth}
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        strokeLinecap="round"
        className="transition-all duration-700 ease-out"
      />
    </svg>
  )
}

// ─── Skeleton Loaders ───────────────────────────────────────────────────────

function KpiCardSkeleton() {
  return (
    <Card className="p-6">
      <div className="flex items-start justify-between">
        <div className="space-y-3 flex-1">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-8 w-20" />
          <Skeleton className="h-3 w-32" />
        </div>
        <Skeleton className="h-10 w-10 rounded-full" />
      </div>
    </Card>
  )
}

function ChartCardSkeleton() {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-5 w-40" />
        <Skeleton className="h-3 w-56" />
      </CardHeader>
      <CardContent>
        <Skeleton className="h-[250px] w-full" />
      </CardContent>
    </Card>
  )
}

function EventListSkeleton() {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-5 w-36" />
      </CardHeader>
      <CardContent className="space-y-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="flex items-start gap-3">
            <Skeleton className="h-12 w-12 rounded-lg shrink-0" />
            <div className="space-y-2 flex-1">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-3 w-1/2" />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

// ─── Quick Actions ───────────────────────────────────────────────────────────

const quickActions = [
  { label: 'Mark Attendance', icon: ClipboardList, accent: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400' },
  { label: 'Collect Fee', icon: IndianRupee, accent: 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400' },
  { label: 'Add Student', icon: UserPlus, accent: 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-400' },
  { label: 'View Reports', icon: BarChart3, accent: 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400' },
]

// ─── Main Component ──────────────────────────────────────────────────────────

export default function DashboardModule() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchDashboard = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      const res = await fetch('/api/dashboard')
      if (!res.ok) throw new Error('Failed to load dashboard')
      const json = await res.json()
      setData(json.data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchDashboard()
  }, [fetchDashboard])

  // ── Derived values ──────────────────────────────────────────────────────

  const attendancePresent = data
    ? Math.round((data.todayAttendancePercentage / 100) * data.totalStudents)
    : 0

  const totalCollected = data
    ? data.feeCollectionTrend.reduce((sum, m) => sum + m.amount, 0)
    : 0

  const totalRevenue = data
    ? data.revenueVsExpense.reduce((sum, m) => sum + m.revenue, 0)
    : 0
  const totalExpense = data
    ? data.revenueVsExpense.reduce((sum, m) => sum + m.expense, 0)
    : 0

  // Transform chart data
  const attendanceChartData = (data?.monthlyAttendanceTrend ?? []).map((d) => ({
    ...d,
    month: formatMonthShort(d.month),
  }))

  const feeChartData = (data?.feeCollectionTrend ?? []).map((d) => ({
    ...d,
    month: formatMonthShort(d.month),
  }))

  const enrollmentChartData = data?.classWiseEnrollment ?? []

  const revenueChartData = (data?.revenueVsExpense ?? []).map((d) => ({
    ...d,
    month: formatMonthShort(d.month),
  }))

  // ── Render ──────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
          Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          Welcome back! Here&apos;s what&apos;s happening at your school today.
        </p>
      </div>

      {/* Error State */}
      {error && !loading && (
        <Card className="border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950/30">
          <CardContent className="flex items-center gap-3 p-6">
            <AlertCircle className="h-5 w-5 text-rose-500 shrink-0" />
            <div>
              <p className="font-medium text-rose-700 dark:text-rose-400">
                Failed to load dashboard
              </p>
              <p className="text-sm text-rose-600/80 dark:text-rose-400/80">
                {error}
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="ml-auto shrink-0"
              onClick={fetchDashboard}
            >
              Retry
            </Button>
          </CardContent>
        </Card>
      )}

      {/* KPI Cards */}
      <section aria-label="Key metrics">
        {loading ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <KpiCardSkeleton />
            <KpiCardSkeleton />
            <KpiCardSkeleton />
            <KpiCardSkeleton />
          </div>
        ) : data ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {/* Total Students */}
            <Card className="p-6 transition-shadow hover:shadow-md">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">
                    Total Students
                  </p>
                  <p className="text-3xl font-bold tracking-tight">
                    {data.totalStudents}
                  </p>
                  <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                    +12% from last year
                  </p>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950">
                  <GraduationCap className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                </div>
              </div>
            </Card>

            {/* Today's Attendance */}
            <Card className="p-6 transition-shadow hover:shadow-md">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">
                    Today&apos;s Attendance
                  </p>
                  <div className="flex items-baseline gap-2">
                    <p className="text-3xl font-bold tracking-tight">
                      {data.todayAttendancePercentage}%
                    </p>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {attendancePresent}/{data.totalStudents} present
                  </p>
                </div>
                <div className="relative flex items-center justify-center">
                  <CircularProgress
                    percentage={data.todayAttendancePercentage}
                    size={48}
                    strokeWidth={4}
                  />
                  <span className="absolute text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">
                    {data.todayAttendancePercentage}
                  </span>
                </div>
              </div>
            </Card>

            {/* Fee Collection */}
            <Card className="p-6 transition-shadow hover:shadow-md">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">
                    Fee Collected
                  </p>
                  <p className="text-3xl font-bold tracking-tight">
                    {formatIndianCurrency(data.feeCollection.collectedThisMonth)}
                  </p>
                  <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">
                    {formatIndianCurrency(data.feeCollection.outstandingAmount)}{' '}
                    outstanding
                  </p>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-950">
                  <IndianRupee className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                </div>
              </div>
            </Card>

            {/* Total Staff */}
            <Card className="p-6 transition-shadow hover:shadow-md">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">
                    Total Staff
                  </p>
                  <p className="text-3xl font-bold tracking-tight">
                    {data.totalTeachers + data.totalStaff}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {data.totalTeachers} Teachers, {data.totalStaff} Staff
                  </p>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-950">
                  <Users className="h-5 w-5 text-teal-600 dark:text-teal-400" />
                </div>
              </div>
            </Card>
          </div>
        ) : null}
      </section>

      {/* Charts Section */}
      <section aria-label="Charts" className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {/* Attendance Trend */}
        {loading ? (
          <ChartCardSkeleton />
        ) : (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Attendance Trend</CardTitle>
              <CardDescription>
                Monthly student attendance over last 6 months
              </CardDescription>
            </CardHeader>
            <CardContent>
              {attendanceChartData.length > 0 ? (
                <ChartContainer
                  config={attendanceChartConfig}
                  className="h-[250px] w-full"
                >
                  <AreaChart
                    data={attendanceChartData}
                    margin={{ top: 8, right: 8, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient
                        id="attendanceGradient"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="0%"
                          stopColor="hsl(160, 84%, 39%)"
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="100%"
                          stopColor="hsl(160, 84%, 39%)"
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>
                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                    <XAxis
                      dataKey="month"
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                    />
                    <YAxis
                      domain={[60, 100]}
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      tickFormatter={(v: number) => `${v}%`}
                    />
                    <ChartTooltip
                      content={<ChartTooltipContent indicator="dot" />}
                    />
                    <Area
                      type="monotone"
                      dataKey="attendance"
                      fill="url(#attendanceGradient)"
                      stroke="var(--color-attendance)"
                      strokeWidth={2}
                      dot={{ r: 4, fill: 'var(--color-attendance)' }}
                      activeDot={{ r: 6 }}
                    />
                  </AreaChart>
                </ChartContainer>
              ) : (
                <div className="flex h-[250px] items-center justify-center text-muted-foreground text-sm">
                  No attendance data available
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Fee Collection Trend */}
        {loading ? (
          <ChartCardSkeleton />
        ) : (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Fee Collection Trend</CardTitle>
              <CardDescription>
                Monthly fee collections &middot; Total:{' '}
                {formatIndianCurrency(totalCollected)}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {feeChartData.length > 0 ? (
                <ChartContainer
                  config={feeCollectionChartConfig}
                  className="h-[250px] w-full"
                >
                  <BarChart
                    data={feeChartData}
                    margin={{ top: 8, right: 8, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                    <XAxis
                      dataKey="month"
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                    />
                    <YAxis
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      tickFormatter={(v: number) =>
                        `${(v / 1000).toFixed(0)}k`
                      }
                    />
                    <ChartTooltip
                      content={<ChartTooltipContent indicator="dot" />}
                    />
                    <Bar
                      dataKey="amount"
                      fill="var(--color-amount)"
                      radius={[4, 4, 0, 0]}
                      maxBarSize={48}
                    />
                  </BarChart>
                </ChartContainer>
              ) : (
                <div className="flex h-[250px] items-center justify-center text-muted-foreground text-sm">
                  No fee data available
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Class-wise Enrollment */}
        {loading ? (
          <ChartCardSkeleton />
        ) : (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Class-wise Enrollment</CardTitle>
              <CardDescription>
                Student distribution across classes
              </CardDescription>
            </CardHeader>
            <CardContent>
              {enrollmentChartData.length > 0 ? (
                <ChartContainer
                  config={enrollmentChartConfig}
                  className="h-[250px] w-full"
                >
                  <BarChart
                    data={enrollmentChartData}
                    layout="vertical"
                    margin={{ top: 8, right: 8, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid horizontal={false} strokeDasharray="3 3" />
                    <XAxis
                      type="number"
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                    />
                    <YAxis
                      type="category"
                      dataKey="className"
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      width={64}
                    />
                    <ChartTooltip
                      content={<ChartTooltipContent indicator="dot" />}
                    />
                    <Bar
                      dataKey="count"
                      fill="var(--color-count)"
                      radius={[0, 4, 4, 0]}
                      maxBarSize={20}
                    />
                  </BarChart>
                </ChartContainer>
              ) : (
                <div className="flex h-[250px] items-center justify-center text-muted-foreground text-sm">
                  No enrollment data available
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Revenue vs Expense */}
        {loading ? (
          <ChartCardSkeleton />
        ) : (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Revenue vs Expense</CardTitle>
              <CardDescription>
                Income:{' '}
                {formatIndianCurrency(totalRevenue)} &middot; Expense:{' '}
                {formatIndianCurrency(totalExpense)}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {revenueChartData.length > 0 ? (
                <ChartContainer
                  config={revenueExpenseChartConfig}
                  className="h-[250px] w-full"
                >
                  <AreaChart
                    data={revenueChartData}
                    margin={{ top: 8, right: 8, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient
                        id="revenueGradient"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="0%"
                          stopColor="hsl(160, 84%, 39%)"
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="100%"
                          stopColor="hsl(160, 84%, 39%)"
                          stopOpacity={0}
                        />
                      </linearGradient>
                      <linearGradient
                        id="expenseGradient"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="0%"
                          stopColor="hsl(346, 77%, 50%)"
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="100%"
                          stopColor="hsl(346, 77%, 50%)"
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>
                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                    <XAxis
                      dataKey="month"
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                    />
                    <YAxis
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      tickFormatter={(v: number) =>
                        `${(v / 1000).toFixed(0)}k`
                      }
                    />
                    <ChartTooltip
                      content={<ChartTooltipContent indicator="dot" />}
                    />
                    <ChartLegend content={<ChartLegendContent />} />
                    <Area
                      type="monotone"
                      dataKey="revenue"
                      fill="url(#revenueGradient)"
                      stroke="var(--color-revenue)"
                      strokeWidth={2}
                      dot={{ r: 3, fill: 'var(--color-revenue)' }}
                      activeDot={{ r: 5 }}
                    />
                    <Area
                      type="monotone"
                      dataKey="expense"
                      fill="url(#expenseGradient)"
                      stroke="var(--color-expense)"
                      strokeWidth={2}
                      dot={{ r: 3, fill: 'var(--color-expense)' }}
                      activeDot={{ r: 5 }}
                    />
                  </AreaChart>
                </ChartContainer>
              ) : (
                <div className="flex h-[250px] items-center justify-center text-muted-foreground text-sm">
                  No financial data available
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </section>

      {/* Bottom Section: Events & Notifications */}
      <section
        aria-label="Events and notifications"
        className="grid grid-cols-1 gap-4 md:grid-cols-2"
      >
        {/* Upcoming Events */}
        {loading ? (
          <EventListSkeleton />
        ) : (
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-muted-foreground" />
                <CardTitle className="text-base">Upcoming Events</CardTitle>
              </div>
              <CardDescription>
                {data?.upcomingEvents.length ?? 0} events coming up
              </CardDescription>
            </CardHeader>
            <CardContent>
              {data && data.upcomingEvents.length > 0 ? (
                <ScrollArea className="max-h-96 pr-3">
                  <div className="space-y-3">
                    {data.upcomingEvents.map((event) => {
                      const eventDate = new Date(event.date)
                      const day = eventDate.getDate()
                      const monthShort = eventDate.toLocaleDateString('en-US', {
                        month: 'short',
                      })

                      return (
                        <div
                          key={event.id}
                          className="flex items-start gap-3 rounded-lg border p-3 transition-colors hover:bg-muted/50"
                        >
                          {/* Date badge */}
                          <div className="flex h-12 w-12 shrink-0 flex-col items-center justify-center rounded-lg bg-emerald-50 text-center dark:bg-emerald-950/50">
                            <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 uppercase leading-none">
                              {monthShort}
                            </span>
                            <span className="text-lg font-bold text-emerald-700 dark:text-emerald-300 leading-tight">
                              {day}
                            </span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">
                              {event.title}
                            </p>
                            {event.venue && (
                              <p className="text-xs text-muted-foreground mt-0.5 truncate">
                                📍 {event.venue}
                              </p>
                            )}
                          </div>
                          <Badge
                            variant={getEventBadgeVariant(event.type)}
                            className="shrink-0 text-[10px] px-1.5 py-0"
                          >
                            {event.type}
                          </Badge>
                        </div>
                      )
                    })}
                  </div>
                </ScrollArea>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <CalendarDays className="h-10 w-10 text-muted-foreground/40 mb-2" />
                  <p className="text-sm text-muted-foreground">
                    No upcoming events
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Recent Notifications */}
        {loading ? (
          <EventListSkeleton />
        ) : (
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Info className="h-4 w-4 text-muted-foreground" />
                <CardTitle className="text-base">Recent Notifications</CardTitle>
              </div>
              <CardDescription>
                {data?.recentNotifications.length ?? 0} notifications
              </CardDescription>
            </CardHeader>
            <CardContent>
              {data && data.recentNotifications.length > 0 ? (
                <ScrollArea className="max-h-96 pr-3">
                  <div className="space-y-1">
                    {data.recentNotifications.map((notif, index) => (
                      <div key={notif.id}>
                        <div className="flex items-start gap-3 rounded-lg p-3 transition-colors hover:bg-muted/50">
                          <div className="mt-0.5 shrink-0">
                            {getNotificationIcon(notif.type)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-medium text-sm truncate">
                                {notif.title}
                              </p>
                              <Badge
                                variant={getNotificationBadgeVariant(notif.type)}
                                className="shrink-0 text-[10px] px-1.5 py-0"
                              >
                                {notif.type}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                              {notif.message}
                            </p>
                            <p className="text-[10px] text-muted-foreground/70 mt-1">
                              {getTimeAgo(notif.createdAt)}
                            </p>
                          </div>
                        </div>
                        {index < data.recentNotifications.length - 1 && (
                          <Separator className="mx-3" />
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Info className="h-10 w-10 text-muted-foreground/40 mb-2" />
                  <p className="text-sm text-muted-foreground">
                    No notifications
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </section>

      {/* Quick Actions */}
      <section aria-label="Quick actions">
        <Card>
          <CardContent className="p-6">
            <p className="text-sm font-medium text-muted-foreground mb-4">
              Quick Actions
            </p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {quickActions.map((action) => (
                <Button
                  key={action.label}
                  variant="outline"
                  className="h-auto flex-col items-center gap-2 py-4 px-3 transition-colors hover:border-primary/30"
                >
                  <div
                    className={`flex h-9 w-9 items-center justify-center rounded-full ${action.accent}`}
                  >
                    <action.icon className="h-4 w-4" />
                  </div>
                  <span className="text-xs font-medium">{action.label}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}