'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Users,
  UserCog,
  Plus,
  Phone,
  Mail,
  Loader2,
  Building2,
  UserCheck,
} from 'lucide-react'
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'

// ─── Types ───────────────────────────────────────────────────────────────────

interface Staff {
  id: string
  employeeId: string
  firstName: string
  lastName: string
  email: string | null
  phone: string | null
  department: string
  designation: string
  salary: number | null
  status: string
  experience?: number | null
  createdAt: string
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getFullName(staff: Staff): string {
  return `${staff.firstName} ${staff.lastName}`
}

function getStatusBadge(status: string) {
  return status === 'active' ? (
    <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 text-[10px] px-1.5 py-0 hover:bg-emerald-100">
      <UserCheck className="h-3 w-3 mr-0.5" />
      Active
    </Badge>
  ) : (
    <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
      Inactive
    </Badge>
  )
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 px-4">
          <Skeleton className="h-4 w-20" />
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-4 w-40 hidden md:block" />
          <Skeleton className="h-4 w-24 hidden lg:block" />
          <Skeleton className="h-4 w-16" />
        </div>
      ))}
    </div>
  )
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function StaffModule() {
  const [staff, setStaff] = useState<Staff[]>([])
  const [teachers, setTeachers] = useState<Staff[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  // Form state
  const [formEmpId, setFormEmpId] = useState('')
  const [formFirstName, setFormFirstName] = useState('')
  const [formLastName, setFormLastName] = useState('')
  const [formEmail, setFormEmail] = useState('')
  const [formPhone, setFormPhone] = useState('')
  const [formDepartment, setFormDepartment] = useState('')
  const [formDesignation, setFormDesignation] = useState('')
  const [formSalary, setFormSalary] = useState('')

  const fetchStaff = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      const [staffRes, teachersRes] = await Promise.all([
        fetch('/api/staff'),
        fetch('/api/teachers'),
      ])
      if (!staffRes.ok) throw new Error('Failed to fetch staff')
      const staffJson = await staffRes.json()
      // Map teachers into the staff shape; teachers fall back gracefully if the
      // teachers endpoint is unavailable (e.g. older builds).
      if (teachersRes.ok) {
        const teachersJson = await teachersRes.json()
        const mapped = ((teachersJson.data ?? []) as Array<Record<string, unknown>>).map(
          (t) => ({
            id: String(t.id),
            employeeId: String(t.employeeId),
            firstName: String(t.firstName),
            lastName: String(t.lastName),
            email: (t.email as string) ?? null,
            phone: (t.phone as string) ?? null,
            department: 'Teaching',
            designation: (t.specialization as string) || 'Teacher',
            salary: (t.salary as number) ?? null,
            status: String(t.status ?? 'active'),
            experience: (t.experience as number) ?? null,
            createdAt: String(t.createdAt ?? new Date().toISOString()),
          })
        )
        setTeachers(mapped)
      } else {
        setTeachers([])
      }
      setStaff(staffJson.data ?? [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchStaff()
  }, [fetchStaff])

  const handleSubmit = async () => {
    if (!formEmpId || !formFirstName || !formLastName || !formDepartment || !formDesignation) return
    try {
      setSubmitting(true)
      const res = await fetch('/api/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          employeeId: formEmpId,
          firstName: formFirstName,
          lastName: formLastName,
          email: formEmail || null,
          phone: formPhone || null,
          department: formDepartment,
          designation: formDesignation,
          salary: formSalary ? parseFloat(formSalary) : null,
        }),
      })
      if (!res.ok) throw new Error('Failed to add staff')
      setDialogOpen(false)
      setFormEmpId('')
      setFormFirstName('')
      setFormLastName('')
      setFormEmail('')
      setFormPhone('')
      setFormDepartment('')
      setFormDesignation('')
      setFormSalary('')
      fetchStaff()
    } catch (err) {
      console.error(err)
    } finally {
      setSubmitting(false)
    }
  }

  const teachingStaff = teachers
  const nonTeachingStaff = staff

  const totalStaff = staff.length + teachers.length
  const activeStaff =
    staff.filter((s) => s.status === 'active').length +
    teachers.filter((s) => s.status === 'active').length
  const departments = new Set([...staff, ...teachers].map((s) => s.department))
    .size

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Staff & HR Management
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage teaching and non-teaching staff
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Add Staff
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Staff Member</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="staff-fname">First Name *</Label>
                  <Input
                    id="staff-fname"
                    value={formFirstName}
                    onChange={(e) => setFormFirstName(e.target.value)}
                    placeholder="First name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="staff-lname">Last Name *</Label>
                  <Input
                    id="staff-lname"
                    value={formLastName}
                    onChange={(e) => setFormLastName(e.target.value)}
                    placeholder="Last name"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="staff-empid">Employee ID *</Label>
                <Input
                  id="staff-empid"
                  value={formEmpId}
                  onChange={(e) => setFormEmpId(e.target.value)}
                  placeholder="e.g., STF-001"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="staff-email">Email</Label>
                  <Input
                    id="staff-email"
                    type="email"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    placeholder="Email address"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="staff-phone">Phone</Label>
                  <Input
                    id="staff-phone"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="Phone number"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="staff-dept">Department *</Label>
                  <Select value={formDepartment} onValueChange={setFormDepartment}>
                    <SelectTrigger id="staff-dept">
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Teaching">Teaching</SelectItem>
                      <SelectItem value="Administration">Administration</SelectItem>
                      <SelectItem value="Accounts">Accounts</SelectItem>
                      <SelectItem value="Library">Library</SelectItem>
                      <SelectItem value="Transport">Transport</SelectItem>
                      <SelectItem value="Maintenance">Maintenance</SelectItem>
                      <SelectItem value="Sports">Sports</SelectItem>
                      <SelectItem value="IT">IT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="staff-desg">Designation *</Label>
                  <Input
                    id="staff-desg"
                    value={formDesignation}
                    onChange={(e) => setFormDesignation(e.target.value)}
                    placeholder="e.g., Clerk"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="staff-salary">Salary (optional)</Label>
                <Input
                  id="staff-salary"
                  type="number"
                  value={formSalary}
                  onChange={(e) => setFormSalary(e.target.value)}
                  placeholder="Monthly salary"
                />
              </div>
              <Button
                onClick={handleSubmit}
                disabled={
                  submitting ||
                  !formEmpId ||
                  !formFirstName ||
                  !formLastName ||
                  !formDepartment ||
                  !formDesignation
                }
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Add Staff Member
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Error State */}
      {error && !loading && (
        <Card className="border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950/30">
          <CardContent className="flex items-center gap-3 p-4">
            <span className="text-rose-500 text-lg">⚠</span>
            <p className="text-sm text-rose-700 dark:text-rose-400">{error}</p>
            <Button variant="outline" size="sm" className="ml-auto" onClick={fetchStaff}>
              Retry
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950">
              <Users className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{totalStaff}</p>
              <p className="text-xs text-muted-foreground">Total Staff</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-950">
              <UserCheck className="h-5 w-5 text-teal-600 dark:text-teal-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{activeStaff}</p>
              <p className="text-xs text-muted-foreground">Active</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-950">
              <Building2 className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{departments}</p>
              <p className="text-xs text-muted-foreground">Departments</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="teaching">
        <TabsList>
          <TabsTrigger value="teaching" className="gap-1.5">
            <UserCog className="h-3.5 w-3.5" />
            Teaching Staff ({teachingStaff.length})
          </TabsTrigger>
          <TabsTrigger value="non-teaching" className="gap-1.5">
            <Users className="h-3.5 w-3.5" />
            Non-Teaching Staff ({nonTeachingStaff.length})
          </TabsTrigger>
        </TabsList>

        {/* Teaching Staff Tab */}
        <TabsContent value="teaching" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Teaching Staff</CardTitle>
              <CardDescription>Teachers and academic staff members</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {loading ? (
                <div className="p-4">
                  <TableSkeleton rows={5} />
                </div>
              ) : teachingStaff.length > 0 ? (
                <ScrollArea className="max-h-[400px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-28">Employee ID</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead className="hidden md:table-cell">Email</TableHead>
                        <TableHead className="hidden lg:table-cell">Specialization</TableHead>
                        <TableHead className="hidden lg:table-cell">Experience</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {teachingStaff.map((s) => (
                        <TableRow key={s.id} className="hover:bg-muted/50">
                          <TableCell className="font-mono text-xs">
                            {s.employeeId}
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium text-sm">{getFullName(s)}</p>
                              <p className="text-xs text-muted-foreground md:hidden">
                                {s.email}
                              </p>
                            </div>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            {s.email ? (
                              <span className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Mail className="h-3 w-3" />
                                {s.email}
                              </span>
                            ) : (
                              <span className="text-xs text-muted-foreground">—</span>
                            )}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                              {s.designation}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden lg:table-cell text-xs text-muted-foreground">
                            {s.experience ? `${s.experience} yrs` : '—'}
                          </TableCell>
                          <TableCell>{getStatusBadge(s.status)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <UserCog className="h-12 w-12 text-muted-foreground/30 mb-3" />
                  <p className="text-sm text-muted-foreground">No teaching staff found</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Non-Teaching Staff Tab */}
        <TabsContent value="non-teaching" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Non-Teaching Staff</CardTitle>
              <CardDescription>Administrative and support staff members</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {loading ? (
                <div className="p-4">
                  <TableSkeleton rows={5} />
                </div>
              ) : nonTeachingStaff.length > 0 ? (
                <ScrollArea className="max-h-[400px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-28">Employee ID</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead className="hidden md:table-cell">Department</TableHead>
                        <TableHead className="hidden lg:table-cell">Designation</TableHead>
                        <TableHead className="hidden lg:table-cell">Phone</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {nonTeachingStaff.map((s) => (
                        <TableRow key={s.id} className="hover:bg-muted/50">
                          <TableCell className="font-mono text-xs">
                            {s.employeeId}
                          </TableCell>
                          <TableCell>
                            <p className="font-medium text-sm">{getFullName(s)}</p>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                              {s.department}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden lg:table-cell text-sm">
                            {s.designation}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            {s.phone ? (
                              <span className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Phone className="h-3 w-3" />
                                {s.phone}
                              </span>
                            ) : (
                              <span className="text-xs text-muted-foreground">—</span>
                            )}
                          </TableCell>
                          <TableCell>{getStatusBadge(s.status)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Users className="h-12 w-12 text-muted-foreground/30 mb-3" />
                  <p className="text-sm text-muted-foreground">No non-teaching staff found</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
