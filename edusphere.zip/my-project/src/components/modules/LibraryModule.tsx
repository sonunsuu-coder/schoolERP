'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  BookOpen,
  Plus,
  Search,
  Library,
  BookCheck,
  BookX,
  Layers,
  Loader2,
} from 'lucide-react'
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Progress } from '@/components/ui/progress'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'

// ─── Types ───────────────────────────────────────────────────────────────────

interface LibraryBook {
  id: string
  title: string
  author: string
  isbn: string | null
  category: string
  totalCopies: number
  availableCopies: number
  schoolId: string
  createdAt: string
}

// ─── Categories ─────────────────────────────────────────────────────────────

const categories = [
  'Fiction',
  'Science',
  'Mathematics',
  'History',
  'Literature',
  'Reference',
]

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getCategoryColor(category: string) {
  switch (category) {
    case 'Fiction':
      return 'bg-violet-100 text-violet-700 dark:bg-violet-950 dark:text-violet-400'
    case 'Science':
      return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400'
    case 'Mathematics':
      return 'bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-400'
    case 'History':
      return 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400'
    case 'Literature':
      return 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
    case 'Reference':
      return 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-400'
    default:
      return 'bg-muted text-muted-foreground'
  }
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function BookCardSkeleton() {
  return (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-start justify-between">
          <Skeleton className="h-5 w-3/4" />
          <Skeleton className="h-5 w-16 rounded-full" />
        </div>
        <Skeleton className="h-4 w-1/2" />
        <Skeleton className="h-2 w-full" />
        <div className="flex items-center justify-between">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-24" />
        </div>
      </div>
    </Card>
  )
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function LibraryModule() {
  const [books, setBooks] = useState<LibraryBook[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  // Form state
  const [formTitle, setFormTitle] = useState('')
  const [formAuthor, setFormAuthor] = useState('')
  const [formIsbn, setFormIsbn] = useState('')
  const [formCategory, setFormCategory] = useState('')
  const [formCopies, setFormCopies] = useState('')

  const fetchBooks = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      let url = '/api/library'
      const params = new URLSearchParams()
      if (category) params.set('category', category)
      if (search) params.set('search', search)
      if (params.toString()) url += `?${params.toString()}`
      const res = await fetch(url)
      if (!res.ok) throw new Error('Failed to fetch books')
      const json = await res.json()
      setBooks(json.data ?? [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }, [category, search])

  useEffect(() => {
    const debounce = setTimeout(() => {
      fetchBooks()
    }, 300)
    return () => clearTimeout(debounce)
  }, [fetchBooks])

  const handleSubmit = async () => {
    if (!formTitle || !formAuthor || !formCategory || !formCopies) return
    try {
      setSubmitting(true)
      const res = await fetch('/api/library', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formTitle,
          author: formAuthor,
          isbn: formIsbn || null,
          category: formCategory,
          totalCopies: parseInt(formCopies),
        }),
      })
      if (!res.ok) throw new Error('Failed to add book')
      setDialogOpen(false)
      setFormTitle('')
      setFormAuthor('')
      setFormIsbn('')
      setFormCategory('')
      setFormCopies('')
      fetchBooks()
    } catch (err) {
      console.error(err)
    } finally {
      setSubmitting(false)
    }
  }

  // Summary stats
  const totalBooks = books.reduce((sum, b) => sum + b.totalCopies, 0)
  const availableBooks = books.reduce((sum, b) => sum + b.availableCopies, 0)
  const issuedBooks = totalBooks - availableBooks
  const uniqueCategories = new Set(books.map((b) => b.category)).size

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Library Management
          </h1>
          <p className="text-muted-foreground mt-1">
            Browse, search, and manage the school library collection
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Add Book
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Book</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label htmlFor="book-title">Title *</Label>
                <Input
                  id="book-title"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="Book title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="book-author">Author *</Label>
                <Input
                  id="book-author"
                  value={formAuthor}
                  onChange={(e) => setFormAuthor(e.target.value)}
                  placeholder="Author name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="book-isbn">ISBN</Label>
                <Input
                  id="book-isbn"
                  value={formIsbn}
                  onChange={(e) => setFormIsbn(e.target.value)}
                  placeholder="ISBN number"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="book-category">Category *</Label>
                <Select value={formCategory} onValueChange={setFormCategory}>
                  <SelectTrigger id="book-category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="book-copies">Total Copies *</Label>
                <Input
                  id="book-copies"
                  type="number"
                  min={1}
                  value={formCopies}
                  onChange={(e) => setFormCopies(e.target.value)}
                  placeholder="Number of copies"
                />
              </div>
              <Button
                onClick={handleSubmit}
                disabled={submitting || !formTitle || !formAuthor || !formCategory || !formCopies}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Add Book
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Error State */}
      {error && !loading && (
        <Card className="border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950/30">
          <CardContent className="flex items-center gap-3 p-4">
            <span className="text-rose-500 text-lg">⚠</span>
            <p className="text-sm text-rose-700 dark:text-rose-400">{error}</p>
            <Button variant="outline" size="sm" className="ml-auto" onClick={fetchBooks}>
              Retry
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Summary Stats */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950">
              <Library className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{totalBooks}</p>
              <p className="text-xs text-muted-foreground">Total Books</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-950">
              <BookCheck className="h-5 w-5 text-teal-600 dark:text-teal-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{availableBooks}</p>
              <p className="text-xs text-muted-foreground">Available</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-950">
              <BookX className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{issuedBooks}</p>
              <p className="text-xs text-muted-foreground">Issued</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-rose-100 dark:bg-rose-950">
              <Layers className="h-5 w-5 text-rose-600 dark:text-rose-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{uniqueCategories}</p>
              <p className="text-xs text-muted-foreground">Categories</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by title, author, or ISBN..."
            className="pl-9"
          />
        </div>
        <Select value={category} onValueChange={(v) => setCategory(v === '__all__' ? '' : v)}>
          <SelectTrigger className="w-full sm:w-44">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All Categories</SelectItem>
            {categories.map((cat) => (
              <SelectItem key={cat} value={cat}>
                {cat}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Book Grid */}
      {loading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <BookCardSkeleton key={i} />
          ))}
        </div>
      ) : books.length > 0 ? (
        <ScrollArea className="max-h-[650px]">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 pr-3">
            {books.map((book) => {
              const availabilityPercent =
                book.totalCopies > 0
                  ? Math.round((book.availableCopies / book.totalCopies) * 100)
                  : 0
              const isAvailable = book.availableCopies > 0

              return (
                <Card
                  key={book.id}
                  className="p-4 transition-shadow hover:shadow-md"
                >
                  <div className="space-y-3">
                    {/* Title & Category */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2 min-w-0">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-100 dark:bg-emerald-950">
                          <BookOpen className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                        </div>
                        <h3 className="font-semibold text-sm leading-tight line-clamp-2">
                          {book.title}
                        </h3>
                      </div>
                    </div>

                    {/* Category Badge */}
                    <span
                      className={`inline-flex items-center rounded-full px-2 py-0 text-[10px] font-medium ${getCategoryColor(book.category)}`}
                    >
                      {book.category}
                    </span>

                    {/* Author */}
                    <p className="text-xs text-muted-foreground">
                      by {book.author}
                    </p>

                    {/* Availability Bar */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">
                          {book.availableCopies}/{book.totalCopies} available
                        </span>
                        <span
                          className={`font-medium ${
                            isAvailable
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-rose-600 dark:text-rose-400'
                          }`}
                        >
                          {availabilityPercent}%
                        </span>
                      </div>
                      <Progress
                        value={availabilityPercent}
                        className="h-1.5"
                      />
                    </div>

                    {/* Status */}
                    <div className="flex items-center gap-1.5">
                      {isAvailable ? (
                        <>
                          <span className="h-2 w-2 rounded-full bg-emerald-500" />
                          <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                            Available
                          </span>
                        </>
                      ) : (
                        <>
                          <span className="h-2 w-2 rounded-full bg-rose-500" />
                          <span className="text-xs text-rose-600 dark:text-rose-400 font-medium">
                            All Issued
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        </ScrollArea>
      ) : (
        <Card className="p-12">
          <div className="flex flex-col items-center justify-center text-center">
            <Library className="h-12 w-12 text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground text-sm">No books found</p>
            <p className="text-muted-foreground/70 text-xs mt-1">
              Try adjusting your search or filter
            </p>
          </div>
        </Card>
      )}
    </div>
  )
}
