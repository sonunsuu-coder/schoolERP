'use client'

import { useEffect, useState, useCallback, useMemo, useRef } from 'react'
import {
  IndianRupee,
  AlertCircle,
  Users,
  TrendingUp,
  Search,
  Filter,
  CreditCard,
  Plus,
  ChevronLeft,
  ChevronRight,
  Loader2,
  CircleX,
  CircleCheck,
  Clock,
  CalendarClock,
  Receipt,
  Building2,
} from 'lucide-react'

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { useToast } from '@/hooks/use-toast'

// ─── Types ───────────────────────────────────────────────────────────────────

interface DashboardFeeSummary {
  collectedThisMonth: number
  outstandingAmount: number
}

interface FeeRecordStudent {
  id: string
  firstName: string
  lastName: string
  admissionNo: string
  className: string | null
  sectionName: string | null
}

interface FeeRecordStructure {
  name: string
  type: string
  frequency: string
}

interface FeeRecordPayment {
  id: string
  amount: number
  method: string
  transactionId: string | null
  paidAt: string
}

interface FeeRecord {
  id: string
  studentId: string
  feeStructureId: string
  feeName: string
  studentName: string | null
  amount: number
  paidAmount: number
  dueDate: string
  paidDate: string | null
  status: string
  lateFine: number
  discount: number
  createdAt: string
  student: FeeRecordStudent
  feeStructure: FeeRecordStructure
  payment: FeeRecordPayment | null
}

interface ClassOption {
  id: string
  name: string
  numericLevel: number
}

interface FeeStructure {
  id: string
  name: string
  amount: number
  frequency: string
  type: string
  className: string | null
  status: string
  createdAt: string
  _count: { feeRecords: number }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount)
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
}

function getStatusBadge(status: string) {
  const s = status.toLowerCase()
  if (s === 'paid') {
    return (
      <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950 dark:text-emerald-400 border-0">
        <CircleCheck className="mr-1 h-3 w-3" />
        Paid
      </Badge>
    )
  }
  if (s === 'overdue') {
    return (
      <Badge className="bg-rose-100 text-rose-700 hover:bg-rose-100 dark:bg-rose-950 dark:text-rose-400 border-0">
        <CircleX className="mr-1 h-3 w-3" />
        Overdue
      </Badge>
    )
  }
  if (s === 'partial') {
    return (
      <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 dark:bg-amber-950 dark:text-amber-400 border-0">
        <Clock className="mr-1 h-3 w-3" />
        Partial
      </Badge>
    )
  }
  return (
    <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 dark:bg-amber-950 dark:text-amber-400 border-0">
      <Clock className="mr-1 h-3 w-3" />
      Pending
    </Badge>
  )
}

const PAYMENT_METHODS = ['UPI', 'Cash', 'Bank Transfer', 'Online']

const ITEMS_PER_PAGE = 10

// ─── Skeleton Loaders ───────────────────────────────────────────────────────

function SummaryCardSkeleton() {
  return (
    <Card className="p-6">
      <div className="flex items-start justify-between">
        <div className="space-y-3 flex-1">
          <Skeleton className="h-4 w-28" />
          <Skeleton className="h-8 w-24" />
          <Skeleton className="h-3 w-36" />
        </div>
        <Skeleton className="h-10 w-10 rounded-full" />
      </div>
    </Card>
  )
}

function TableSkeleton() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 px-2">
          <Skeleton className="h-4 w-[140px]" />
          <Skeleton className="h-4 w-[100px]" />
          <Skeleton className="h-4 w-[80px]" />
          <Skeleton className="h-4 w-[90px]" />
          <Skeleton className="h-4 w-[80px]" />
          <Skeleton className="h-5 w-[60px]" />
          <Skeleton className="h-8 w-[70px] ml-auto" />
        </div>
      ))}
    </div>
  )
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function FeeModule() {
  const { toast } = useToast()

  // ── Data State ──────────────────────────────────────────────────────────
  const [feeSummary, setFeeSummary] = useState<DashboardFeeSummary | null>(null)
  const [feeRecords, setFeeRecords] = useState<FeeRecord[]>([])
  const [classes, setClasses] = useState<ClassOption[]>([])
  const [feeStructures, setFeeStructures] = useState<FeeStructure[]>([])

  const [summaryLoading, setSummaryLoading] = useState(true)
  const [recordsLoading, setRecordsLoading] = useState(true)
  const [structuresLoading, setStructuresLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // ── Filter State ────────────────────────────────────────────────────────
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [classFilter, setClassFilter] = useState<string>('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [currentPage, setCurrentPage] = useState(1)

  // ── Collect Fee Dialog State ────────────────────────────────────────────
  const [collectDialogOpen, setCollectDialogOpen] = useState(false)
  const [selectedFeeRecord, setSelectedFeeRecord] = useState<FeeRecord | null>(null)
  const [paymentMethod, setPaymentMethod] = useState<string>('')
  const [transactionId, setTransactionId] = useState('')
  const [discountInput, setDiscountInput] = useState<string>('0')
  const [collecting, setCollecting] = useState(false)

  // ── Add Fee Structure Dialog State ──────────────────────────────────────
  const [addStructureOpen, setAddStructureOpen] = useState(false)
  const [newStructure, setNewStructure] = useState({
    name: '',
    amount: '',
    frequency: 'monthly',
    type: 'tuition',
    className: '',
  })
  const [creatingStructure, setCreatingStructure] = useState(false)

  // ── Search debounce ─────────────────────────────────────────────────────
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  // ── Data Fetching ───────────────────────────────────────────────────────
  const fetchSummary = useCallback(async () => {
    try {
      setSummaryLoading(true)
      const res = await fetch('/api/dashboard')
      if (!res.ok) throw new Error('Failed to fetch dashboard')
      const json = await res.json()
      setFeeSummary(json.data.feeCollection)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load summary')
    } finally {
      setSummaryLoading(false)
    }
  }, [])

  const fetchFeeRecords = useCallback(async () => {
    try {
      setRecordsLoading(true)
      const params = new URLSearchParams()
      if (statusFilter !== 'all') params.set('status', statusFilter)
      if (classFilter !== 'all') params.set('classId', classFilter)
      const qs = params.toString()
      const res = await fetch(`/api/fees${qs ? `?${qs}` : ''}`)
      if (!res.ok) throw new Error('Failed to fetch fee records')
      const json = await res.json()
      setFeeRecords(json.data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load records')
    } finally {
      setRecordsLoading(false)
    }
  }, [statusFilter, classFilter])

  const fetchClasses = useCallback(async () => {
    try {
      const res = await fetch('/api/classes')
      if (!res.ok) throw new Error('Failed to fetch classes')
      const json = await res.json()
      setClasses(json.data)
    } catch {
      // silent fail for classes
    }
  }, [])

  const fetchFeeStructures = useCallback(async () => {
    try {
      setStructuresLoading(true)
      const res = await fetch('/api/fee-structures')
      if (!res.ok) throw new Error('Failed to fetch fee structures')
      const json = await res.json()
      setFeeStructures(json.data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load structures')
    } finally {
      setStructuresLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchSummary()
    fetchClasses()
    fetchFeeRecords()
    fetchFeeStructures()
  }, [fetchSummary, fetchClasses, fetchFeeRecords, fetchFeeStructures])

  // Reset page on filter change
  useEffect(() => {
    setCurrentPage(1)
  }, [statusFilter, classFilter, searchQuery])

  // ── Derived / Computed ──────────────────────────────────────────────────
  const filteredRecords = useMemo(() => {
    let records = feeRecords

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase()
      records = records.filter(
        (r) =>
          r.student?.firstName?.toLowerCase().includes(q) ||
          r.student?.lastName?.toLowerCase().includes(q) ||
          r.studentName?.toLowerCase().includes(q) ||
          r.feeName?.toLowerCase().includes(q)
      )
    }

    return records
  }, [feeRecords, searchQuery])

  const totalPages = Math.max(1, Math.ceil(filteredRecords.length / ITEMS_PER_PAGE))
  const paginatedRecords = filteredRecords.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  )

  const todayStr = new Date().toISOString().split('T')[0]
  const todayCollection = useMemo(
    () =>
      feeRecords
        .filter((r) => r.payment && r.payment.paidAt?.startsWith(todayStr))
        .reduce((sum, r) => sum + (r.payment?.amount ?? 0), 0),
    [feeRecords, todayStr]
  )

  const studentsWithDues = useMemo(() => {
    const studentIds = new Set(
      feeRecords
        .filter((r) => r.status === 'pending' || r.status === 'overdue' || r.status === 'partial')
        .map((r) => r.studentId)
    )
    return studentIds.size
  }, [feeRecords])

  const pageStart = (currentPage - 1) * ITEMS_PER_PAGE + 1
  const pageEnd = Math.min(currentPage * ITEMS_PER_PAGE, filteredRecords.length)

  // ── Handlers ───────────────────────────────────────────────────────────

  function handleSearchChange(value: string) {
    setSearchQuery(value)
    if (searchTimer.current) clearTimeout(searchTimer.current)
    searchTimer.current = setTimeout(() => {
      setCurrentPage(1)
    }, 300)
  }

  function openCollectDialog(record: FeeRecord) {
    setSelectedFeeRecord(record)
    setPaymentMethod('')
    setTransactionId('')
    setDiscountInput('0')
    setCollectDialogOpen(true)
  }

  async function handleCollectFee() {
    if (!selectedFeeRecord || !paymentMethod) return

    const discount = Number(discountInput) || 0
    const dueAmount = selectedFeeRecord.amount - selectedFeeRecord.paidAmount - discount
    const lateFine =
      new Date(selectedFeeRecord.dueDate) < new Date() && selectedFeeRecord.status !== 'paid'
        ? Math.min(selectedFeeRecord.amount * 0.02, 500)
        : 0
    const totalPayable = Math.max(dueAmount + lateFine, 0)

    if (totalPayable <= 0) return

    try {
      setCollecting(true)
      const res = await fetch('/api/fees/collect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          feeRecordId: selectedFeeRecord.id,
          amount: totalPayable,
          method: paymentMethod,
          transactionId: transactionId.trim() || undefined,
        }),
      })

      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.error || 'Failed to collect fee')
      }

      toast({
        title: 'Payment collected successfully',
        description: `${formatINR(totalPayable)} received from ${selectedFeeRecord.studentName || selectedFeeRecord.student?.firstName + ' ' + selectedFeeRecord.student?.lastName}`,
      })

      setCollectDialogOpen(false)
      setSelectedFeeRecord(null)
      // Refresh data
      fetchFeeRecords()
      fetchSummary()
      fetchFeeStructures()
    } catch (err) {
      toast({
        title: 'Payment failed',
        description: err instanceof Error ? err.message : 'Something went wrong',
        variant: 'destructive',
      })
    } finally {
      setCollecting(false)
    }
  }

  async function handleAddFeeStructure() {
    if (!newStructure.name || !newStructure.amount) return

    try {
      setCreatingStructure(true)
      const res = await fetch('/api/fee-structures', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newStructure,
          amount: Number(newStructure.amount),
          className: newStructure.className || null,
          schoolId: 'school_01',
        }),
      })

      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.error || 'Failed to create fee structure')
      }

      toast({
        title: 'Fee structure created',
        description: `"${newStructure.name}" has been added successfully.`,
      })

      setAddStructureOpen(false)
      setNewStructure({ name: '', amount: '', frequency: 'monthly', type: 'tuition', className: '' })
      fetchFeeStructures()
    } catch (err) {
      toast({
        title: 'Failed to create',
        description: err instanceof Error ? err.message : 'Something went wrong',
        variant: 'destructive',
      })
    } finally {
      setCreatingStructure(false)
    }
  }

  // ── Pagination Helper ──────────────────────────────────────────────────
  function getPageNumbers(current: number, total: number): (number | '...')[] {
    if (total <= 5) return Array.from({ length: total }, (_, i) => i + 1)
    const pages: (number | '...')[] = [1]
    if (current > 3) pages.push('...')
    const start = Math.max(2, current - 1)
    const end = Math.min(total - 1, current + 1)
    for (let i = start; i <= end; i++) pages.push(i)
    if (current < total - 2) pages.push('...')
    if (total > 1) pages.push(total)
    return pages
  }

  // ── Render ─────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
          Fee Management
        </h1>
        <p className="text-muted-foreground mt-1">
          Collect fees, track payments, and manage fee structures.
        </p>
      </div>

      {/* Error Banner */}
      {error && !summaryLoading && (
        <Card className="border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950/30">
          <CardContent className="flex items-center gap-3 p-4">
            <AlertCircle className="h-5 w-5 text-rose-500 shrink-0" />
            <p className="text-sm text-rose-700 dark:text-rose-400 flex-1">{error}</p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setError(null)
                fetchSummary()
                fetchFeeRecords()
                fetchFeeStructures()
              }}
            >
              Retry
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Summary Cards */}
      <section aria-label="Fee summary" className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {summaryLoading ? (
          <>
            <SummaryCardSkeleton />
            <SummaryCardSkeleton />
            <SummaryCardSkeleton />
            <SummaryCardSkeleton />
          </>
        ) : feeSummary ? (
          <>
            {/* Total Collected This Month */}
            <Card className="p-6 transition-shadow hover:shadow-md">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">
                    Total Collected
                  </p>
                  <p className="text-2xl font-bold tracking-tight sm:text-3xl">
                    {formatINR(feeSummary.collectedThisMonth)}
                  </p>
                  <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                    This month
                  </p>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950">
                  <IndianRupee className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                </div>
              </div>
            </Card>

            {/* Outstanding Fees */}
            <Card className="p-6 transition-shadow hover:shadow-md">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">
                    Outstanding Fees
                  </p>
                  <p className="text-2xl font-bold tracking-tight sm:text-3xl">
                    {formatINR(feeSummary.outstandingAmount)}
                  </p>
                  <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">
                    Needs collection
                  </p>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-rose-100 dark:bg-rose-950">
                  <AlertCircle className="h-5 w-5 text-rose-600 dark:text-rose-400" />
                </div>
              </div>
            </Card>

            {/* Students with Dues */}
            <Card className="p-6 transition-shadow hover:shadow-md">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">
                    Students with Dues
                  </p>
                  <p className="text-2xl font-bold tracking-tight sm:text-3xl">
                    {studentsWithDues}
                  </p>
                  <p className="text-xs text-amber-600 dark:text-amber-400 font-medium">
                    Have pending or overdue fees
                  </p>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-950">
                  <Users className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                </div>
              </div>
            </Card>

            {/* Today's Collection */}
            <Card className="p-6 transition-shadow hover:shadow-md">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">
                    Today&apos;s Collection
                  </p>
                  <p className="text-2xl font-bold tracking-tight sm:text-3xl">
                    {formatINR(todayCollection)}
                  </p>
                  <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                    Collected today
                  </p>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950">
                  <TrendingUp className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                </div>
              </div>
            </Card>
          </>
        ) : null}
      </section>

      {/* Tabs */}
      <Tabs defaultValue="fee-records">
        <TabsList>
          <TabsTrigger value="fee-records">
            <Receipt className="mr-1.5 h-4 w-4 hidden sm:block" />
            Fee Records
          </TabsTrigger>
          <TabsTrigger value="collect-fee">
            <CreditCard className="mr-1.5 h-4 w-4 hidden sm:block" />
            Collect Fee
          </TabsTrigger>
          <TabsTrigger value="fee-structures">
            <Building2 className="mr-1.5 h-4 w-4 hidden sm:block" />
            Fee Structures
          </TabsTrigger>
        </TabsList>

        {/* ════════════════════════════════════════════════════════════════
            FEE RECORDS TAB
        ════════════════════════════════════════════════════════════════ */}
        <TabsContent value="fee-records">
          <Card>
            <CardHeader className="pb-4">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <CardTitle className="text-lg">Fee Records</CardTitle>
                  <CardDescription>
                    {filteredRecords.length} record{filteredRecords.length !== 1 ? 's' : ''} found
                  </CardDescription>
                </div>
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                  {/* Search */}
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Search student name..."
                      value={searchQuery}
                      onChange={(e) => handleSearchChange(e.target.value)}
                      className="pl-9 w-full sm:w-[220px]"
                    />
                  </div>
                  {/* Status Filter */}
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full sm:w-[140px]">
                      <Filter className="mr-1.5 h-3.5 w-3.5 text-muted-foreground" />
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="overdue">Overdue</SelectItem>
                      <SelectItem value="partial">Partial</SelectItem>
                    </SelectContent>
                  </Select>
                  {/* Class Filter */}
                  <Select value={classFilter} onValueChange={setClassFilter}>
                    <SelectTrigger className="w-full sm:w-[140px]">
                      <SelectValue placeholder="Class" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Classes</SelectItem>
                      {classes.map((cls) => (
                        <SelectItem key={cls.id} value={cls.id}>
                          {cls.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {recordsLoading ? (
                <TableSkeleton />
              ) : filteredRecords.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Receipt className="h-12 w-12 text-muted-foreground/30 mb-3" />
                  <p className="text-sm font-medium text-muted-foreground">
                    No fee records found
                  </p>
                  <p className="text-xs text-muted-foreground/70 mt-1">
                    Try adjusting your filters or search query
                  </p>
                </div>
              ) : (
                <>
                  {/* Desktop Table */}
                  <div className="hidden md:block">
                    <ScrollArea className="max-h-[480px]">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Student Name</TableHead>
                            <TableHead>Fee Type</TableHead>
                            <TableHead className="text-right">Amount</TableHead>
                            <TableHead>Due Date</TableHead>
                            <TableHead className="text-right">Paid</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {paginatedRecords.map((record) => {
                            const fullName =
                              record.studentName ||
                              `${record.student?.firstName} ${record.student?.lastName}`.trim()
                            const isCollectable =
                              record.status === 'pending' ||
                              record.status === 'overdue' ||
                              record.status === 'partial'

                            return (
                              <TableRow key={record.id} className="group">
                                <TableCell>
                                  <div>
                                    <p className="font-medium text-sm">{fullName}</p>
                                    <p className="text-xs text-muted-foreground">
                                      {record.student?.className}
                                      {record.student?.sectionName
                                        ? ` - ${record.student.sectionName}`
                                        : ''}
                                    </p>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div>
                                    <p className="text-sm">{record.feeName}</p>
                                    <p className="text-xs text-muted-foreground capitalize">
                                      {record.feeStructure?.type} &middot;{' '}
                                      {record.feeStructure?.frequency}
                                    </p>
                                  </div>
                                </TableCell>
                                <TableCell className="text-right font-medium">
                                  {formatINR(record.amount)}
                                </TableCell>
                                <TableCell>
                                  <span className="text-sm">{formatDate(record.dueDate)}</span>
                                </TableCell>
                                <TableCell className="text-right">
                                  <span
                                    className={
                                      record.paidAmount >= record.amount
                                        ? 'text-emerald-600 dark:text-emerald-400 font-medium'
                                        : 'text-sm'
                                    }
                                  >
                                    {formatINR(record.paidAmount)}
                                  </span>
                                </TableCell>
                                <TableCell>{getStatusBadge(record.status)}</TableCell>
                                <TableCell className="text-right">
                                  {isCollectable && (
                                    <Button
                                      size="sm"
                                      onClick={() => openCollectDialog(record)}
                                      className="bg-emerald-600 hover:bg-emerald-700 text-white"
                                    >
                                      Collect
                                    </Button>
                                  )}
                                </TableCell>
                              </TableRow>
                            )
                          })}
                        </TableBody>
                      </Table>
                    </ScrollArea>
                  </div>

                  {/* Mobile Cards */}
                  <div className="md:hidden space-y-3">
                    {paginatedRecords.map((record) => {
                      const fullName =
                        record.studentName ||
                        `${record.student?.firstName} ${record.student?.lastName}`.trim()
                      const isCollectable =
                        record.status === 'pending' ||
                        record.status === 'overdue' ||
                        record.status === 'partial'

                      return (
                        <Card key={record.id} className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <p className="font-medium text-sm">{fullName}</p>
                              <p className="text-xs text-muted-foreground">
                                {record.student?.className}
                                {record.student?.sectionName
                                  ? ` - ${record.student.sectionName}`
                                  : ''}
                              </p>
                            </div>
                            {getStatusBadge(record.status)}
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                            <div>
                              <p className="text-xs text-muted-foreground">Fee Type</p>
                              <p className="font-medium">{record.feeName}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Amount</p>
                              <p className="font-medium">{formatINR(record.amount)}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Due Date</p>
                              <p className="text-sm">{formatDate(record.dueDate)}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Paid</p>
                              <p className="font-medium text-emerald-600 dark:text-emerald-400">
                                {formatINR(record.paidAmount)}
                              </p>
                            </div>
                          </div>
                          {isCollectable && (
                            <Button
                              size="sm"
                              onClick={() => openCollectDialog(record)}
                              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                            >
                              <CreditCard className="mr-1.5 h-3.5 w-3.5" />
                              Collect Fee
                            </Button>
                          )}
                        </Card>
                      )
                    })}
                  </div>

                  {/* Pagination */}
                  {totalPages > 1 && (
                    <div className="flex items-center justify-between mt-4 pt-4 border-t">
                      <p className="text-sm text-muted-foreground">
                        Showing {pageStart}–{pageEnd} of {filteredRecords.length}
                      </p>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                          disabled={currentPage === 1}
                        >
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        {getPageNumbers(currentPage, totalPages).map((page, idx) =>
                          page === '...' ? (
                            <span
                              key={`dots-${idx}`}
                              className="px-1 text-sm text-muted-foreground"
                            >
                              ...
                            </span>
                          ) : (
                            <Button
                              key={page}
                              variant={currentPage === page ? 'default' : 'outline'}
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => setCurrentPage(page)}
                            >
                              {page}
                            </Button>
                          )
                        )}
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                          disabled={currentPage === totalPages}
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ════════════════════════════════════════════════════════════════
            COLLECT FEE TAB
        ════════════════════════════════════════════════════════════════ */}
        <TabsContent value="collect-fee">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Fee Collection</CardTitle>
              <CardDescription>
                Click &quot;Collect&quot; on any pending record from the Fee Records tab, or
                search for a student below.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <CreditCard className="h-16 w-16 text-muted-foreground/20 mb-4" />
                <p className="text-base font-medium text-muted-foreground">
                  No payment in progress
                </p>
                <p className="text-sm text-muted-foreground/70 mt-1 max-w-md">
                  Go to the <strong>Fee Records</strong> tab and click the &quot;Collect&quot;
                  button on any pending or overdue fee to initiate payment.
                </p>
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => {
                    setStatusFilter('pending')
                  }}
                >
                  <Receipt className="mr-1.5 h-4 w-4" />
                  View Pending Fees
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ════════════════════════════════════════════════════════════════
            FEE STRUCTURES TAB
        ════════════════════════════════════════════════════════════════ */}
        <TabsContent value="fee-structures">
          <Card>
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">Fee Structures</CardTitle>
                  <CardDescription>
                    {feeStructures.length} structure{feeStructures.length !== 1 ? 's' : ''} configured
                  </CardDescription>
                </div>
                <Button
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                  onClick={() => setAddStructureOpen(true)}
                >
                  <Plus className="mr-1.5 h-4 w-4" />
                  Add Structure
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {structuresLoading ? (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <Card key={i} className="p-4">
                      <Skeleton className="h-5 w-32 mb-3" />
                      <Skeleton className="h-4 w-20 mb-2" />
                      <Skeleton className="h-3 w-40" />
                    </Card>
                  ))}
                </div>
              ) : feeStructures.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Building2 className="h-12 w-12 text-muted-foreground/30 mb-3" />
                  <p className="text-sm font-medium text-muted-foreground">
                    No fee structures configured
                  </p>
                  <p className="text-xs text-muted-foreground/70 mt-1">
                    Click &quot;Add Structure&quot; to create your first fee structure.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {feeStructures.map((fs) => (
                    <Card
                      key={fs.id}
                      className="p-4 transition-shadow hover:shadow-md"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="space-y-1">
                          <p className="font-semibold text-sm">{fs.name}</p>
                          <p className="text-xs text-muted-foreground capitalize">
                            {fs.type} &middot; {fs.frequency}
                          </p>
                        </div>
                        {fs.status === 'active' ? (
                          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950 dark:text-emerald-400 border-0 text-[10px]">
                            Active
                          </Badge>
                        ) : (
                          <Badge className="bg-gray-100 text-gray-700 hover:bg-gray-100 dark:bg-gray-800 dark:text-gray-400 border-0 text-[10px]">
                            Inactive
                          </Badge>
                        )}
                      </div>
                      <Separator className="my-3" />
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">Amount</span>
                          <span className="text-sm font-semibold">
                            {formatINR(fs.amount)}
                          </span>
                        </div>
                        {fs.className && (
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-muted-foreground">Class</span>
                            <span className="text-sm">{fs.className}</span>
                          </div>
                        )}
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">Records</span>
                          <span className="text-sm">{fs._count.feeRecords}</span>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ════════════════════════════════════════════════════════════════
          COLLECT FEE DIALOG
      ════════════════════════════════════════════════════════════════ */}
      <Dialog open={collectDialogOpen} onOpenChange={setCollectDialogOpen}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-emerald-600" />
              Collect Fee
            </DialogTitle>
            <DialogDescription>
              Process payment for the selected fee record.
            </DialogDescription>
          </DialogHeader>

          {selectedFeeRecord && (
            <div className="space-y-5">
              {/* Student & Fee Info */}
              <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Student</span>
                  <span className="text-sm font-medium">
                    {selectedFeeRecord.studentName ||
                      `${selectedFeeRecord.student?.firstName} ${selectedFeeRecord.student?.lastName}`.trim()}
                  </span>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Fee Type</span>
                  <span className="text-sm">{selectedFeeRecord.feeName}</span>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Due Amount</span>
                  <span className="text-sm font-medium">
                    {formatINR(selectedFeeRecord.amount - selectedFeeRecord.paidAmount)}
                  </span>
                </div>
                <Separator />
                {(() => {
                  const isLate =
                    new Date(selectedFeeRecord.dueDate) < new Date() &&
                    selectedFeeRecord.status !== 'paid'
                  const lateFine = isLate
                    ? Math.min((selectedFeeRecord.amount - selectedFeeRecord.paidAmount) * 0.02, 500)
                    : 0
                  return (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">Late Fine</span>
                        <span
                          className={`text-sm ${lateFine > 0 ? 'text-rose-600 dark:text-rose-400 font-medium' : ''}`}
                        >
                          {lateFine > 0 ? `+ ${formatINR(lateFine)}` : '₹0'}
                        </span>
                      </div>
                      <Separator />
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">Discount</span>
                        <Input
                          type="number"
                          min="0"
                          max={selectedFeeRecord.amount - selectedFeeRecord.paidAmount}
                          value={discountInput}
                          onChange={(e) => setDiscountInput(e.target.value)}
                          className="h-7 w-28 text-right text-sm"
                        />
                      </div>
                    </>
                  )
                })()}
              </div>

              {/* Total Payable */}
              {(() => {
                const isLate =
                  new Date(selectedFeeRecord.dueDate) < new Date() &&
                  selectedFeeRecord.status !== 'paid'
                const lateFine = isLate
                  ? Math.min((selectedFeeRecord.amount - selectedFeeRecord.paidAmount) * 0.02, 500)
                  : 0
                const discount = Number(discountInput) || 0
                const total =
                  selectedFeeRecord.amount -
                  selectedFeeRecord.paidAmount +
                  lateFine -
                  discount
                return (
                  <div className="flex items-center justify-between rounded-lg border border-emerald-200 bg-emerald-50 p-3 dark:border-emerald-900 dark:bg-emerald-950/30">
                    <span className="text-sm font-medium text-emerald-700 dark:text-emerald-400">
                      Total Payable
                    </span>
                    <span className="text-xl font-bold text-emerald-700 dark:text-emerald-400">
                      {formatINR(Math.max(total, 0))}
                    </span>
                  </div>
                )
              })()}

              {/* Payment Method */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">Payment Method *</Label>
                <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    {PAYMENT_METHODS.map((method) => (
                      <SelectItem key={method} value={method}>
                        {method}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Transaction ID */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  Transaction ID{' '}
                  <span className="text-muted-foreground font-normal">(optional)</span>
                </Label>
                <Input
                  placeholder="Enter transaction ID"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                />
              </div>
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setCollectDialogOpen(false)}
              disabled={collecting}
            >
              Cancel
            </Button>
            <Button
              className="bg-emerald-600 hover:bg-emerald-700 text-white"
              onClick={handleCollectFee}
              disabled={collecting || !paymentMethod}
            >
              {collecting ? (
                <>
                  <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <CircleCheck className="mr-1.5 h-4 w-4" />
                  Process Payment
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ════════════════════════════════════════════════════════════════
          ADD FEE STRUCTURE DIALOG
      ════════════════════════════════════════════════════════════════ */}
      <Dialog open={addStructureOpen} onOpenChange={setAddStructureOpen}>
        <DialogContent className="sm:max-w-[440px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-emerald-600" />
              Add Fee Structure
            </DialogTitle>
            <DialogDescription>
              Create a new fee structure for the school.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium">Structure Name *</Label>
              <Input
                placeholder="e.g., Class 10 Tuition Fee"
                value={newStructure.name}
                onChange={(e) =>
                  setNewStructure((s) => ({ ...s, name: e.target.value }))
                }
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Amount (₹) *</Label>
                <Input
                  type="number"
                  placeholder="e.g., 5000"
                  value={newStructure.amount}
                  onChange={(e) =>
                    setNewStructure((s) => ({ ...s, amount: e.target.value }))
                  }
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Frequency</Label>
                <Select
                  value={newStructure.frequency}
                  onValueChange={(v) =>
                    setNewStructure((s) => ({ ...s, frequency: v }))
                  }
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="half-yearly">Half-Yearly</SelectItem>
                    <SelectItem value="annually">Annually</SelectItem>
                    <SelectItem value="one-time">One-Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Type</Label>
                <Select
                  value={newStructure.type}
                  onValueChange={(v) =>
                    setNewStructure((s) => ({ ...s, type: v }))
                  }
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tuition">Tuition</SelectItem>
                    <SelectItem value="transport">Transport</SelectItem>
                    <SelectItem value="lab">Lab</SelectItem>
                    <SelectItem value="sports">Sports</SelectItem>
                    <SelectItem value="library">Library</SelectItem>
                    <SelectItem value="exam">Exam</SelectItem>
                    <SelectItem value="development">Development</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  Class{' '}
                  <span className="text-muted-foreground font-normal">(optional)</span>
                </Label>
                <Select
                  value={newStructure.className}
                  onValueChange={(v) =>
                    setNewStructure((s) => ({ ...s, className: v }))
                  }
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Classes</SelectItem>
                    {classes.map((cls) => (
                      <SelectItem key={cls.id} value={cls.name}>
                        {cls.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setAddStructureOpen(false)}
              disabled={creatingStructure}
            >
              Cancel
            </Button>
            <Button
              className="bg-emerald-600 hover:bg-emerald-700 text-white"
              onClick={handleAddFeeStructure}
              disabled={
                creatingStructure || !newStructure.name || !newStructure.amount
              }
            >
              {creatingStructure ? (
                <>
                  <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : (
                <>
                  <Plus className="mr-1.5 h-4 w-4" />
                  Create Structure
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}