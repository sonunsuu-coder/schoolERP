'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import {
  BarChart3,
  FileText,
  CalendarDays,
  Download,
  AlertCircle,
  TrendingUp,
  TrendingDown,
  Users,
  UserCheck,
  IndianRupee,
  GraduationCap,
  Wallet,
  Loader2,
  CircleDot,
} from 'lucide-react'
import {
  BarChart,
  LineChart,
  PieChart as RechartsPieChart,
  AreaChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Bar,
  Line,
  Pie,
  Cell,
  Area,
  Legend,
} from 'recharts'

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Label } from '@/components/ui/label'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  type ChartConfig,
} from '@/components/ui/chart'

// ─── Color Palette ──────────────────────────────────────────────────────────

const COLORS = {
  emerald: 'hsl(160, 84%, 39%)',
  teal: 'hsl(174, 72%, 56%)',
  amber: 'hsl(45, 93%, 47%)',
  rose: 'hsl(350, 89%, 60%)',
  orange: 'hsl(24, 95%, 53%)',
  cyan: 'hsl(185, 80%, 45%)',
  violet: 'hsl(262, 83%, 58%)',
  lime: 'hsl(84, 81%, 44%)',
} as const

const PIE_COLORS = [
  COLORS.emerald,
  COLORS.teal,
  COLORS.amber,
  COLORS.rose,
  COLORS.orange,
  COLORS.cyan,
  COLORS.violet,
  COLORS.lime,
]

// ─── Types ──────────────────────────────────────────────────────────────────

type ReportType = 'attendance' | 'fees' | 'academic' | 'financial'

interface AttendanceClassEntry {
  className: string
  total: number
  present: number
  percentage: number
}

interface AttendanceReport {
  type: 'attendance'
  monthlyByClass: Array<{
    month: string
    classes: AttendanceClassEntry[]
  }>
}

interface FeesReport {
  type: 'fees'
  collectionByMonth: Array<{ month: string; amount: number }>
  outstandingByClass: Array<{ className: string; amount: number }>
  totalOutstanding: number
}

interface AcademicReport {
  type: 'academic'
  averageBySubject: Array<{
    subject: string
    averageMarks: number
    maxMarks: number
    averagePercentage: number
    studentsCount: number
  }>
  classPerformance: Array<{
    className: string
    averageMarks: number
    averagePercentage: number
    totalEntries: number
  }>
}

interface FinancialReport {
  type: 'financial'
  incomeVsExpense: Array<{
    month: string
    income: number
    expense: number
    net: number
  }>
  plSummary: {
    totalIncome: number
    totalExpense: number
    netProfit: number
    profitMargin: number
    thisMonthIncome: number
    thisMonthExpense: number
    thisMonthNet: number
  }
  expenseBreakdown: Array<{ category: string; amount: number }>
  incomeBreakdown: Array<{ category: string; amount: number }>
}

type ReportData =
  | AttendanceReport
  | FeesReport
  | AcademicReport
  | FinancialReport

// ─── Helpers ────────────────────────────────────────────────────────────────

function formatMonthShort(monthStr: string): string {
  const date = new Date(monthStr + '-01')
  return date.toLocaleDateString('en-US', { month: 'short' })
}

function formatIndianCurrency(amount: number): string {
  return '\u20B9' + amount.toLocaleString('en-IN')
}

function formatCompact(amount: number): string {
  if (amount >= 100000) return `${(amount / 100000).toFixed(1)}L`
  if (amount >= 1000) return `${(amount / 1000).toFixed(1)}k`
  return amount.toString()
}

function getTodayStr(): string {
  return new Date().toISOString().split('T')[0]
}

function getSixMonthsAgoStr(): string {
  const d = new Date()
  d.setMonth(d.getMonth() - 6)
  return d.toISOString().split('T')[0]
}

// ─── Chart Configs ──────────────────────────────────────────────────────────

const attendanceBarConfig = {
  percentage: { label: 'Attendance %', color: COLORS.emerald },
} satisfies ChartConfig

const attendanceTrendConfig = {
  avgPercentage: { label: 'Avg Attendance %', color: COLORS.teal },
} satisfies ChartConfig

const feeCollectionConfig = {
  amount: { label: 'Collected', color: COLORS.emerald },
} satisfies ChartConfig

const feeOutstandingConfig = {
  amount: { label: 'Outstanding', color: COLORS.rose },
} satisfies ChartConfig

const feePieConfig = {
  value: { label: 'Amount' },
  className: { label: 'Class' },
} satisfies ChartConfig

const academicSubjectConfig = {
  averagePercentage: { label: 'Avg %', color: COLORS.emerald },
} satisfies ChartConfig

const academicClassConfig = {
  averagePercentage: { label: 'Avg %', color: COLORS.teal },
} satisfies ChartConfig

const academicPieConfig = {
  value: { label: 'Count' },
  grade: { label: 'Grade' },
} satisfies ChartConfig

const financialAreaConfig = {
  income: { label: 'Income', color: COLORS.emerald },
  expense: { label: 'Expense', color: COLORS.rose },
} satisfies ChartConfig

const financialExpensePieConfig = {
  value: { label: 'Amount' },
  category: { label: 'Category' },
} satisfies ChartConfig

const financialNetConfig = {
  net: { label: 'Net P/L', color: COLORS.amber },
} satisfies ChartConfig

// ─── Skeleton Components ───────────────────────────────────────────────────

function KpiCardSkeleton() {
  return (
    <Card className="p-4">
      <div className="flex items-center gap-3">
        <Skeleton className="h-10 w-10 rounded-full shrink-0" />
        <div className="space-y-2 flex-1">
          <Skeleton className="h-3 w-24" />
          <Skeleton className="h-6 w-20" />
          <Skeleton className="h-3 w-16" />
        </div>
      </div>
    </Card>
  )
}

function ChartCardSkeleton() {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-5 w-48" />
        <Skeleton className="h-3 w-64" />
      </CardHeader>
      <CardContent>
        <Skeleton className="h-[280px] w-full" />
      </CardContent>
    </Card>
  )
}

function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-5 w-40" />
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <Skeleton className="h-8 w-full" />
          {Array.from({ length: rows }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

function FullSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCardSkeleton />
        <KpiCardSkeleton />
        <KpiCardSkeleton />
        <KpiCardSkeleton />
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <ChartCardSkeleton />
        <ChartCardSkeleton />
      </div>
      <TableSkeleton />
    </div>
  )
}

// ─── KPI Card Component ─────────────────────────────────────────────────────

function KpiCard({
  label,
  value,
  subtext,
  icon: Icon,
  iconBg,
  iconColor,
  trend,
}: {
  label: string
  value: string
  subtext?: string
  icon: React.ComponentType<{ className?: string }>
  iconBg: string
  iconColor: string
  trend?: 'up' | 'down' | 'neutral'
}) {
  return (
    <Card className="p-4 transition-shadow hover:shadow-md">
      <div className="flex items-center gap-3">
        <div className={`flex h-10 w-10 items-center justify-center rounded-full shrink-0 ${iconBg}`}>
          <Icon className={`h-5 w-5 ${iconColor}`} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-xs font-medium text-muted-foreground truncate">{label}</p>
          <p className="text-xl font-bold tracking-tight truncate">{value}</p>
          {subtext && (
            <p className="text-[11px] text-muted-foreground flex items-center gap-1 mt-0.5">
              {trend === 'up' && <TrendingUp className="h-3 w-3 text-emerald-500" />}
              {trend === 'down' && <TrendingDown className="h-3 w-3 text-rose-500" />}
              {subtext}
            </p>
          )}
        </div>
      </div>
    </Card>
  )
}

// ─── Empty Chart State ─────────────────────────────────────────────────────

function EmptyChartState({ message }: { message: string }) {
  return (
    <div className="flex h-[280px] items-center justify-center text-muted-foreground text-sm">
      <div className="text-center">
        <BarChart3 className="h-10 w-10 mx-auto mb-2 opacity-30" />
        <p>{message}</p>
      </div>
    </div>
  )
}

// ─── Attendance Report ─────────────────────────────────────────────────────

function AttendanceReportView({ data }: { data: AttendanceReport }) {
  // Get all unique class names
  const allClasses = useMemo(() => {
    const classSet = new Set<string>()
    data.monthlyByClass.forEach((m) => m.classes.forEach((c) => classSet.add(c.className)))
    return Array.from(classSet).sort()
  }, [data.monthlyByClass])

  // Latest month bar chart data (class-wise)
  const latestMonth = data.monthlyByClass[data.monthlyByClass.length - 1]
  const classBarData = latestMonth
    ? latestMonth.classes
        .slice()
        .sort((a, b) => b.percentage - a.percentage)
        .map((c) => ({ className: c.className, percentage: c.percentage }))
    : []

  // Trend line data: overall average per month
  const trendData = data.monthlyByClass.map((m) => {
    const totalPct = m.classes.reduce((s, c) => s + c.percentage, 0)
    const avg = m.classes.length > 0 ? Math.round(totalPct / m.classes.length) : 0
    return { month: formatMonthShort(m.month), avgPercentage: avg }
  })

  // Summary stats
  const allPercentages = data.monthlyByClass.flatMap((m) =>
    m.classes.map((c) => c.percentage)
  )
  const avgAttendance =
    allPercentages.length > 0
      ? Math.round(allPercentages.reduce((s, v) => s + v, 0) / allPercentages.length)
      : 0

  // Find most regular and most absent class (from latest month)
  const mostRegular = latestMonth?.classes.slice().sort((a, b) => b.percentage - a.percentage)[0]
  const mostAbsent = latestMonth?.classes.slice().sort((a, b) => a.percentage - b.percentage)[0]

  // Defaulter table: classes with lowest attendance
  const defaulterData = latestMonth
    ? latestMonth.classes
        .slice()
        .sort((a, b) => a.percentage - b.percentage)
        .slice(0, 10)
    : []

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <KpiCard
          label="Average Attendance"
          value={`${avgAttendance}%`}
          subtext="Across all classes"
          icon={UserCheck}
          iconBg="bg-emerald-100 dark:bg-emerald-950"
          iconColor="text-emerald-600 dark:text-emerald-400"
          trend="up"
        />
        <KpiCard
          label="Most Regular Class"
          value={mostRegular?.className ?? 'N/A'}
          subtext={mostRegular ? `${mostRegular.percentage}% attendance` : 'No data'}
          icon={TrendingUp}
          iconBg="bg-teal-100 dark:bg-teal-950"
          iconColor="text-teal-600 dark:text-teal-400"
          trend="up"
        />
        <KpiCard
          label="Most Absent Class"
          value={mostAbsent?.className ?? 'N/A'}
          subtext={mostAbsent ? `${mostAbsent.percentage}% attendance` : 'No data'}
          icon={TrendingDown}
          iconBg="bg-rose-100 dark:bg-rose-950"
          iconColor="text-rose-600 dark:text-rose-400"
          trend="down"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Monthly Attendance Bar Chart (class-wise, latest month) */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Class-wise Attendance</CardTitle>
            <CardDescription>
              Attendance percentage by class &middot; {latestMonth ? formatMonthShort(latestMonth.month) : 'N/A'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {classBarData.length > 0 ? (
              <ChartContainer config={attendanceBarConfig} className="h-[280px] w-full">
                <BarChart data={classBarData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis
                    dataKey="className"
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    tick={{ fontSize: 11 }}
                  />
                  <YAxis
                    domain={[0, 100]}
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    tickFormatter={(v: number) => `${v}%`}
                  />
                  <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                  <Bar
                    dataKey="percentage"
                    fill="var(--color-percentage)"
                    radius={[4, 4, 0, 0]}
                    maxBarSize={36}
                  />
                </BarChart>
              </ChartContainer>
            ) : (
              <EmptyChartState message="No class-wise attendance data" />
            )}
          </CardContent>
        </Card>

        {/* Attendance Trend Line */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Overall Attendance Trend</CardTitle>
            <CardDescription>
              Monthly average attendance across all classes
            </CardDescription>
          </CardHeader>
          <CardContent>
            {trendData.length > 0 ? (
              <ChartContainer config={attendanceTrendConfig} className="h-[280px] w-full">
                <LineChart data={trendData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
                  <YAxis
                    domain={[60, 100]}
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    tickFormatter={(v: number) => `${v}%`}
                  />
                  <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                  <Line
                    type="monotone"
                    dataKey="avgPercentage"
                    stroke="var(--color-avgPercentage)"
                    strokeWidth={2.5}
                    dot={{ r: 4, fill: 'var(--color-avgPercentage)' }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ChartContainer>
            ) : (
              <EmptyChartState message="No trend data available" />
            )}
          </CardContent>
        </Card>
      </div>

      {/* Defaulter List Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <CircleDot className="h-4 w-4 text-rose-500" />
            Low Attendance Classes
          </CardTitle>
          <CardDescription>
            Classes with lowest attendance rates (sorted ascending)
          </CardDescription>
        </CardHeader>
        <CardContent>
          {defaulterData.length > 0 ? (
            <ScrollArea className="max-h-96">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Class</TableHead>
                    <TableHead className="text-right">Total Records</TableHead>
                    <TableHead className="text-right">Present</TableHead>
                    <TableHead className="text-right">Absent</TableHead>
                    <TableHead className="text-right">Attendance %</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {defaulterData.map((entry) => (
                    <TableRow key={entry.className}>
                      <TableCell className="font-medium">{entry.className}</TableCell>
                      <TableCell className="text-right">{entry.total}</TableCell>
                      <TableCell className="text-right text-emerald-600 dark:text-emerald-400">
                        {entry.present}
                      </TableCell>
                      <TableCell className="text-right text-rose-600 dark:text-rose-400">
                        {entry.total - entry.present}
                      </TableCell>
                      <TableCell className="text-right">
                        <Badge
                          variant={entry.percentage >= 80 ? 'default' : entry.percentage >= 60 ? 'secondary' : 'destructive'}
                          className="text-xs"
                        >
                          {entry.percentage}%
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          ) : (
            <div className="flex h-40 items-center justify-center text-muted-foreground text-sm">
              No data available
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// ─── Fee Report ────────────────────────────────────────────────────────────

function FeeReportView({ data }: { data: FeesReport }) {
  const totalCollected = data.collectionByMonth.reduce((s, m) => s + m.amount, 0)
  const totalOutstanding = data.totalOutstanding
  const collectionRate =
    totalCollected + totalOutstanding > 0
      ? Math.round((totalCollected / (totalCollected + totalOutstanding)) * 100)
      : 0

  // Bar chart data: monthly collection
  const barData = data.collectionByMonth.map((m) => ({
    month: formatMonthShort(m.month),
    amount: m.amount,
  }))

  // Pie chart data: outstanding by class (top classes)
  const pieData = data.outstandingByClass.slice(0, 8).map((item) => ({
    name: item.className,
    value: item.amount,
  }))

  // Horizontal bar data: outstanding by class
  const outstandingBarData = data.outstandingByClass.slice(0, 10).map((item) => ({
    className: item.className,
    amount: item.amount,
  }))

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          label="Total Collected"
          value={formatIndianCurrency(totalCollected)}
          subtext="Last 6 months"
          icon={IndianRupee}
          iconBg="bg-emerald-100 dark:bg-emerald-950"
          iconColor="text-emerald-600 dark:text-emerald-400"
          trend="up"
        />
        <KpiCard
          label="Total Outstanding"
          value={formatIndianCurrency(totalOutstanding)}
          subtext={`${data.outstandingByClass.length} classes`}
          icon={AlertCircle}
          iconBg="bg-rose-100 dark:bg-rose-950"
          iconColor="text-rose-600 dark:text-rose-400"
          trend="down"
        />
        <KpiCard
          label="Collection Rate"
          value={`${collectionRate}%`}
          subtext="Collected / Total Due"
          icon={TrendingUp}
          iconBg="bg-amber-100 dark:bg-amber-950"
          iconColor="text-amber-600 dark:text-amber-400"
          trend={collectionRate >= 70 ? 'up' : 'down'}
        />
        <KpiCard
          label="Classes with Dues"
          value={data.outstandingByClass.length.toString()}
          subtext="With pending fees"
          icon={Users}
          iconBg="bg-teal-100 dark:bg-teal-950"
          iconColor="text-teal-600 dark:text-teal-400"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Fee Collection Trend Bar */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Fee Collection Trend</CardTitle>
            <CardDescription>
              Monthly collected amount &middot; Total: {formatIndianCurrency(totalCollected)}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {barData.length > 0 ? (
              <ChartContainer config={feeCollectionConfig} className="h-[280px] w-full">
                <BarChart data={barData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    tickFormatter={(v: number) => formatCompact(v)}
                  />
                  <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                  <Bar
                    dataKey="amount"
                    fill="var(--color-amount)"
                    radius={[4, 4, 0, 0]}
                    maxBarSize={48}
                  />
                </BarChart>
              </ChartContainer>
            ) : (
              <EmptyChartState message="No fee collection data" />
            )}
          </CardContent>
        </Card>

        {/* Outstanding by Class (Pie Chart) */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Outstanding by Class</CardTitle>
            <CardDescription>Distribution of pending fees across classes</CardDescription>
          </CardHeader>
          <CardContent>
            {pieData.length > 0 ? (
              <ChartContainer config={feePieConfig} className="h-[280px] w-full">
                <RechartsPieChart>
                  <ChartTooltip content={<ChartTooltipContent nameKey="name" />} />
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    dataKey="value"
                    nameKey="name"
                    paddingAngle={2}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={true}
                  >
                    {pieData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend content={<ChartLegendContent nameKey="name" />} />
                </RechartsPieChart>
              </ChartContainer>
            ) : (
              <EmptyChartState message="No outstanding fee data" />
            )}
          </CardContent>
        </Card>
      </div>

      {/* Outstanding by Class (Horizontal Bar) */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Outstanding Fees by Class</CardTitle>
          <CardDescription>
            Classes with the highest pending fee amounts
          </CardDescription>
        </CardHeader>
        <CardContent>
          {outstandingBarData.length > 0 ? (
            <ChartContainer config={feeOutstandingConfig} className="h-[300px] w-full">
              <BarChart
                data={outstandingBarData}
                layout="vertical"
                margin={{ top: 8, right: 8, left: 0, bottom: 0 }}
              >
                <CartesianGrid horizontal={false} strokeDasharray="3 3" />
                <XAxis
                  type="number"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tickFormatter={(v: number) => formatCompact(v)}
                />
                <YAxis
                  type="category"
                  dataKey="className"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  width={80}
                  tick={{ fontSize: 11 }}
                />
                <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                <Bar
                  dataKey="amount"
                  fill="var(--color-amount)"
                  radius={[0, 4, 4, 0]}
                  maxBarSize={24}
                />
              </BarChart>
            </ChartContainer>
          ) : (
            <EmptyChartState message="No outstanding data available" />
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// ─── Academic Report ───────────────────────────────────────────────────────

function AcademicReportView({ data }: { data: AcademicReport }) {
  // Subject bar chart data
  const subjectBarData = data.averageBySubject.map((s) => ({
    subject: s.subject,
    averagePercentage: s.averagePercentage,
    averageMarks: s.averageMarks,
  }))

  // Grade distribution from averagePercentage
  const gradeDistribution = useMemo(() => {
    const grades: Record<string, number> = {
      'A+': 0, 'A': 0, 'B+': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0,
    }
    data.averageBySubject.forEach((s) => {
      const pct = s.averagePercentage
      if (pct >= 90) grades['A+']++
      else if (pct >= 80) grades['A']++
      else if (pct >= 70) grades['B+']++
      else if (pct >= 60) grades['B']++
      else if (pct >= 50) grades['C']++
      else if (pct >= 40) grades['D']++
      else grades['F']++
    })
    return Object.entries(grades)
      .filter(([, count]) => count > 0)
      .map(([grade, value]) => ({ grade, value }))
  }, [data.averageBySubject])

  // Class performance bar chart
  const classBarData = data.classPerformance.map((c) => ({
    className: c.className,
    averagePercentage: c.averagePercentage,
    averageMarks: c.averageMarks,
  }))

  // Subject analysis
  const subjectAnalysis = useMemo(() => {
    if (data.averageBySubject.length === 0) return null
    const sorted = [...data.averageBySubject].sort(
      (a, b) => b.averagePercentage - a.averagePercentage
    )
    const highest = sorted[0]
    const lowest = sorted[sorted.length - 1]
    const avgPct =
      Math.round(
        sorted.reduce((s, item) => s + item.averagePercentage, 0) / sorted.length
      )
    return { highest, lowest, average: avgPct }
  }, [data.averageBySubject])

  // Top performers table: show top subjects and classes
  const topSubjects = [...data.averageBySubject]
    .sort((a, b) => b.averagePercentage - a.averagePercentage)
    .slice(0, 6)

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          label="Subjects Tracked"
          value={data.averageBySubject.length.toString()}
          subtext="With exam data"
          icon={GraduationCap}
          iconBg="bg-emerald-100 dark:bg-emerald-950"
          iconColor="text-emerald-600 dark:text-emerald-400"
        />
        <KpiCard
          label="Highest Average"
          value={subjectAnalysis ? `${subjectAnalysis.highest.subject}` : 'N/A'}
          subtext={
            subjectAnalysis
              ? `${subjectAnalysis.highest.averagePercentage}% (${subjectAnalysis.highest.averageMarks} marks)`
              : 'No data'
          }
          icon={TrendingUp}
          iconBg="bg-teal-100 dark:bg-teal-950"
          iconColor="text-teal-600 dark:text-teal-400"
          trend="up"
        />
        <KpiCard
          label="Lowest Average"
          value={subjectAnalysis ? `${subjectAnalysis.lowest.subject}` : 'N/A'}
          subtext={
            subjectAnalysis
              ? `${subjectAnalysis.lowest.averagePercentage}% (${subjectAnalysis.lowest.averageMarks} marks)`
              : 'No data'
          }
          icon={TrendingDown}
          iconBg="bg-rose-100 dark:bg-rose-950"
          iconColor="text-rose-600 dark:text-rose-400"
          trend="down"
        />
        <KpiCard
          label="Overall Average"
          value={subjectAnalysis ? `${subjectAnalysis.average}%` : 'N/A'}
          subtext="Across all subjects"
          icon={BarChart3}
          iconBg="bg-amber-100 dark:bg-amber-950"
          iconColor="text-amber-600 dark:text-amber-400"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Average Marks by Subject Bar */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Average Marks by Subject</CardTitle>
            <CardDescription>Subject-wise average percentage in exams</CardDescription>
          </CardHeader>
          <CardContent>
            {subjectBarData.length > 0 ? (
              <ChartContainer config={academicSubjectConfig} className="h-[280px] w-full">
                <BarChart data={subjectBarData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis
                    dataKey="subject"
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    tick={{ fontSize: 11 }}
                  />
                  <YAxis
                    domain={[0, 100]}
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    tickFormatter={(v: number) => `${v}%`}
                  />
                  <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                  <Bar
                    dataKey="averagePercentage"
                    fill="var(--color-averagePercentage)"
                    radius={[4, 4, 0, 0]}
                    maxBarSize={48}
                  />
                </BarChart>
              </ChartContainer>
            ) : (
              <EmptyChartState message="No academic data available" />
            )}
          </CardContent>
        </Card>

        {/* Grade Distribution Pie */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Grade Distribution</CardTitle>
            <CardDescription>
              Subject classification by average performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            {gradeDistribution.length > 0 ? (
              <ChartContainer config={academicPieConfig} className="h-[280px] w-full">
                <RechartsPieChart>
                  <ChartTooltip content={<ChartTooltipContent nameKey="grade" />} />
                  <Pie
                    data={gradeDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    dataKey="value"
                    nameKey="grade"
                    paddingAngle={2}
                    label={({ grade, value }) => `${grade}: ${value}`}
                    labelLine={true}
                  >
                    {gradeDistribution.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend content={<ChartLegendContent nameKey="grade" />} />
                </RechartsPieChart>
              </ChartContainer>
            ) : (
              <EmptyChartState message="No grade distribution data" />
            )}
          </CardContent>
        </Card>
      </div>

      {/* Class-wise Performance Comparison (Grouped Bar) */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Class-wise Performance Comparison</CardTitle>
          <CardDescription>
            Average marks percentage by class
          </CardDescription>
        </CardHeader>
        <CardContent>
          {classBarData.length > 0 ? (
            <ChartContainer config={academicClassConfig} className="h-[300px] w-full">
              <BarChart data={classBarData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" />
                <XAxis
                  dataKey="className"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tick={{ fontSize: 11 }}
                />
                <YAxis
                  domain={[0, 100]}
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tickFormatter={(v: number) => `${v}%`}
                />
                <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                <Bar
                  dataKey="averagePercentage"
                  fill="var(--color-averagePercentage)"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                />
              </BarChart>
            </ChartContainer>
          ) : (
            <EmptyChartState message="No class performance data" />
          )}
        </CardContent>
      </Card>

      {/* Top Subjects Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-emerald-500" />
            Top Performing Subjects
          </CardTitle>
          <CardDescription>Ranked by average percentage</CardDescription>
        </CardHeader>
        <CardContent>
          {topSubjects.length > 0 ? (
            <ScrollArea className="max-h-96">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">#</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead className="text-right">Avg Marks</TableHead>
                    <TableHead className="text-right">Max Marks</TableHead>
                    <TableHead className="text-right">Avg %</TableHead>
                    <TableHead className="text-right">Students</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topSubjects.map((s, i) => (
                    <TableRow key={s.subject}>
                      <TableCell>
                        <Badge
                          variant={i === 0 ? 'default' : 'secondary'}
                          className="w-6 h-6 flex items-center justify-center p-0 text-xs"
                        >
                          {i + 1}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium">{s.subject}</TableCell>
                      <TableCell className="text-right">{s.averageMarks}</TableCell>
                      <TableCell className="text-right text-muted-foreground">{s.maxMarks}</TableCell>
                      <TableCell className="text-right">
                        <Badge
                          variant={s.averagePercentage >= 80 ? 'default' : s.averagePercentage >= 60 ? 'secondary' : 'destructive'}
                          className="text-xs"
                        >
                          {s.averagePercentage}%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">{s.studentsCount}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          ) : (
            <div className="flex h-40 items-center justify-center text-muted-foreground text-sm">
              No academic data available
            </div>
          )}
        </CardContent>
      </Card>

      {/* Subject-wise Analysis */}
      {subjectAnalysis && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Subject-wise Analysis Summary</CardTitle>
            <CardDescription>Highest, lowest, and overall averages</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div className="rounded-lg border p-4">
                <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400 mb-1">
                  Highest Performing
                </p>
                <p className="text-lg font-bold">{subjectAnalysis.highest.subject}</p>
                <p className="text-sm text-muted-foreground">
                  {subjectAnalysis.highest.averagePercentage}% avg &middot; {subjectAnalysis.highest.averageMarks} avg marks
                </p>
              </div>
              <div className="rounded-lg border p-4">
                <p className="text-xs font-medium text-rose-600 dark:text-rose-400 mb-1">
                  Needs Improvement
                </p>
                <p className="text-lg font-bold">{subjectAnalysis.lowest.subject}</p>
                <p className="text-sm text-muted-foreground">
                  {subjectAnalysis.lowest.averagePercentage}% avg &middot; {subjectAnalysis.lowest.averageMarks} avg marks
                </p>
              </div>
              <div className="rounded-lg border p-4">
                <p className="text-xs font-medium text-amber-600 dark:text-amber-400 mb-1">
                  Overall Average
                </p>
                <p className="text-lg font-bold">{subjectAnalysis.average}%</p>
                <p className="text-sm text-muted-foreground">
                  Across {data.averageBySubject.length} subjects
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// ─── Financial Report ──────────────────────────────────────────────────────

function FinancialReportView({ data }: { data: FinancialReport }) {
  const { plSummary } = data

  // Area chart data
  const areaData = data.incomeVsExpense.map((m) => ({
    month: formatMonthShort(m.month),
    income: m.income,
    expense: m.expense,
  }))

  // Net P/L trend data
  const netData = data.incomeVsExpense.map((m) => ({
    month: formatMonthShort(m.month),
    net: m.net,
  }))

  // Expense pie data
  const expensePieData = data.expenseBreakdown.slice(0, 8).map((item) => ({
    name: item.category,
    value: item.amount,
  }))

  // Income pie data
  const incomePieData = data.incomeBreakdown.slice(0, 8).map((item) => ({
    name: item.category,
    value: item.amount,
  }))

  // Monthly P&L table data
  const plTableData = data.incomeVsExpense.map((m) => ({
    month: m.month,
    income: m.income,
    expense: m.expense,
    net: m.net,
  }))

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          label="Total Income"
          value={formatIndianCurrency(plSummary.totalIncome)}
          subtext={`This month: ${formatIndianCurrency(plSummary.thisMonthIncome)}`}
          icon={Wallet}
          iconBg="bg-emerald-100 dark:bg-emerald-950"
          iconColor="text-emerald-600 dark:text-emerald-400"
          trend="up"
        />
        <KpiCard
          label="Total Expenses"
          value={formatIndianCurrency(plSummary.totalExpense)}
          subtext={`This month: ${formatIndianCurrency(plSummary.thisMonthExpense)}`}
          icon={TrendingDown}
          iconBg="bg-rose-100 dark:bg-rose-950"
          iconColor="text-rose-600 dark:text-rose-400"
          trend="down"
        />
        <KpiCard
          label="Net Profit"
          value={formatIndianCurrency(plSummary.netProfit)}
          subtext={`This month: ${formatIndianCurrency(plSummary.thisMonthNet)}`}
          icon={plSummary.netProfit >= 0 ? TrendingUp : TrendingDown}
          iconBg={plSummary.netProfit >= 0 ? 'bg-teal-100 dark:bg-teal-950' : 'bg-rose-100 dark:bg-rose-950'}
          iconColor={plSummary.netProfit >= 0 ? 'text-teal-600 dark:text-teal-400' : 'text-rose-600 dark:text-rose-400'}
          trend={plSummary.netProfit >= 0 ? 'up' : 'down'}
        />
        <KpiCard
          label="Profit Margin"
          value={`${plSummary.profitMargin}%`}
          subtext="Income vs Expense ratio"
          icon={BarChart3}
          iconBg="bg-amber-100 dark:bg-amber-950"
          iconColor="text-amber-600 dark:text-amber-400"
          trend={plSummary.profitMargin >= 0 ? 'up' : 'down'}
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Income vs Expense Area Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Income vs Expense</CardTitle>
            <CardDescription>
              Monthly comparison &middot; Net: {formatIndianCurrency(plSummary.netProfit)}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {areaData.length > 0 ? (
              <ChartContainer config={financialAreaConfig} className="h-[280px] w-full">
                <AreaChart data={areaData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="finIncomeGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={COLORS.emerald} stopOpacity={0.3} />
                      <stop offset="100%" stopColor={COLORS.emerald} stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="finExpenseGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={COLORS.rose} stopOpacity={0.3} />
                      <stop offset="100%" stopColor={COLORS.rose} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    tickFormatter={(v: number) => formatCompact(v)}
                  />
                  <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                  <ChartLegend content={<ChartLegendContent />} />
                  <Area
                    type="monotone"
                    dataKey="income"
                    fill="url(#finIncomeGrad)"
                    stroke="var(--color-income)"
                    strokeWidth={2}
                    dot={{ r: 3, fill: 'var(--color-income)' }}
                    activeDot={{ r: 5 }}
                  />
                  <Area
                    type="monotone"
                    dataKey="expense"
                    fill="url(#finExpenseGrad)"
                    stroke="var(--color-expense)"
                    strokeWidth={2}
                    dot={{ r: 3, fill: 'var(--color-expense)' }}
                    activeDot={{ r: 5 }}
                  />
                </AreaChart>
              </ChartContainer>
            ) : (
              <EmptyChartState message="No financial data available" />
            )}
          </CardContent>
        </Card>

        {/* Expense Breakdown Pie */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Expense Breakdown</CardTitle>
            <CardDescription>By category</CardDescription>
          </CardHeader>
          <CardContent>
            {expensePieData.length > 0 ? (
              <ChartContainer config={financialExpensePieConfig} className="h-[280px] w-full">
                <RechartsPieChart>
                  <ChartTooltip content={<ChartTooltipContent nameKey="name" />} />
                  <Pie
                    data={expensePieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    dataKey="value"
                    nameKey="name"
                    paddingAngle={2}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={true}
                  >
                    {expensePieData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend content={<ChartLegendContent nameKey="name" />} />
                </RechartsPieChart>
              </ChartContainer>
            ) : (
              <EmptyChartState message="No expense breakdown data" />
            )}
          </CardContent>
        </Card>
      </div>

      {/* Net P/L Trend */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Net Surplus / Deficit Trend</CardTitle>
          <CardDescription>Monthly net profit or loss</CardDescription>
        </CardHeader>
        <CardContent>
          {netData.length > 0 ? (
            <ChartContainer config={financialNetConfig} className="h-[250px] w-full">
              <BarChart data={netData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" />
                <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tickFormatter={(v: number) => formatCompact(v)}
                />
                <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                <Bar
                  dataKey="net"
                  fill="var(--color-net)"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={48}
                />
              </BarChart>
            </ChartContainer>
          ) : (
            <EmptyChartState message="No P/L trend data" />
          )}
        </CardContent>
      </Card>

      {/* Monthly P&L Summary Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Monthly P&L Summary</CardTitle>
          <CardDescription>
            Income, expense, and net for each month
          </CardDescription>
        </CardHeader>
        <CardContent>
          {plTableData.length > 0 ? (
            <ScrollArea className="max-h-96">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Month</TableHead>
                    <TableHead className="text-right">Income</TableHead>
                    <TableHead className="text-right">Expense</TableHead>
                    <TableHead className="text-right">Net P/L</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {plTableData.map((row) => (
                    <TableRow key={row.month}>
                      <TableCell className="font-medium">
                        {formatMonthShort(row.month)} {row.month.split('-')[0]}
                      </TableCell>
                      <TableCell className="text-right text-emerald-600 dark:text-emerald-400">
                        {formatIndianCurrency(row.income)}
                      </TableCell>
                      <TableCell className="text-right text-rose-600 dark:text-rose-400">
                        {formatIndianCurrency(row.expense)}
                      </TableCell>
                      <TableCell className="text-right">
                        <Badge
                          variant={row.net >= 0 ? 'default' : 'destructive'}
                          className="text-xs"
                        >
                          {row.net >= 0 ? '+' : ''}
                          {formatIndianCurrency(row.net)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                  {/* Total row */}
                  <TableRow className="font-bold border-t-2">
                    <TableCell>Total</TableCell>
                    <TableCell className="text-right text-emerald-600 dark:text-emerald-400">
                      {formatIndianCurrency(plSummary.totalIncome)}
                    </TableCell>
                    <TableCell className="text-right text-rose-600 dark:text-rose-400">
                      {formatIndianCurrency(plSummary.totalExpense)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge
                        variant={plSummary.netProfit >= 0 ? 'default' : 'destructive'}
                        className="text-xs"
                      >
                        {plSummary.netProfit >= 0 ? '+' : ''}
                        {formatIndianCurrency(plSummary.netProfit)}
                      </Badge>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </ScrollArea>
          ) : (
            <div className="flex h-40 items-center justify-center text-muted-foreground text-sm">
              No P&L data available
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// ─── Main Component ─────────────────────────────────────────────────────────

export default function ReportsModule() {
  const [reportType, setReportType] = useState<ReportType>('attendance')
  const [data, setData] = useState<ReportData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Date range state (decorative - API doesn't support date params yet)
  const [dateFrom, setDateFrom] = useState(getSixMonthsAgoStr())
  const [dateTo, setDateTo] = useState(getTodayStr())

  const fetchReport = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      const res = await fetch(`/api/reports?type=${reportType}`)
      if (!res.ok) throw new Error('Failed to load report')
      const json = await res.json()
      setData(json.data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }, [reportType])

  useEffect(() => {
    fetchReport()
  }, [fetchReport])

  const handleExport = () => {
    // Decorative action
  }

  const reportTabs: Array<{ value: ReportType; label: string; icon: React.ComponentType<{ className?: string }> }> = [
    { value: 'attendance', label: 'Attendance', icon: UserCheck },
    { value: 'fees', label: 'Fees', icon: IndianRupee },
    { value: 'academic', label: 'Academic', icon: GraduationCap },
    { value: 'financial', label: 'Financial', icon: Wallet },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl flex items-center gap-2">
            <BarChart3 className="h-7 w-7 text-emerald-600 dark:text-emerald-400" />
            Reports & Analytics
          </h1>
          <p className="text-muted-foreground mt-1">
            Comprehensive data insights and performance metrics
          </p>
        </div>
        <Button
          variant="outline"
          className="shrink-0"
          onClick={handleExport}
        >
          <Download className="h-4 w-4 mr-2" />
          Export Report
        </Button>
      </div>

      {/* Report Type Tabs */}
      <Tabs
        value={reportType}
        onValueChange={(v) => setReportType(v as ReportType)}
      >
        <TabsList className="w-full sm:w-auto">
          {reportTabs.map((tab) => (
            <TabsTrigger key={tab.value} value={tab.value} className="gap-1.5">
              <tab.icon className="h-4 w-4" />
              <span className="hidden sm:inline">{tab.label}</span>
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {/* Date Range Selector */}
      <Card className="p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <div className="flex flex-col gap-1.5 flex-1">
            <Label htmlFor="date-from" className="text-xs text-muted-foreground">
              From
            </Label>
            <div className="relative">
              <CalendarDays className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="date-from"
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="pl-8"
              />
            </div>
          </div>
          <div className="flex flex-col gap-1.5 flex-1">
            <Label htmlFor="date-to" className="text-xs text-muted-foreground">
              To
            </Label>
            <div className="relative">
              <CalendarDays className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="date-to"
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="pl-8"
              />
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="shrink-0 h-[38px]"
            onClick={fetchReport}
            disabled={loading}
          >
            {loading ? (
              <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
            ) : (
              <BarChart3 className="h-4 w-4 mr-1.5" />
            )}
            <span className="hidden sm:inline">Apply</span>
          </Button>
        </div>
      </Card>

      {/* Error State */}
      {error && !loading && (
        <Card className="border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950/30">
          <CardContent className="flex items-center gap-3 p-4">
            <AlertCircle className="h-5 w-5 text-rose-500 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-medium text-rose-700 dark:text-rose-400 text-sm">
                Failed to load report
              </p>
              <p className="text-xs text-rose-600/80 dark:text-rose-400/80 truncate">
                {error}
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="shrink-0"
              onClick={fetchReport}
            >
              Retry
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Loading State */}
      {loading && <FullSkeleton />}

      {/* Report Content */}
      {!loading && data && (
        <>
          {data.type === 'attendance' && <AttendanceReportView data={data as AttendanceReport} />}
          {data.type === 'fees' && <FeeReportView data={data as FeesReport} />}
          {data.type === 'academic' && <AcademicReportView data={data as AcademicReport} />}
          {data.type === 'financial' && <FinancialReportView data={data as FinancialReport} />}
        </>
      )}

      {/* Empty State (no data) */}
      {!loading && !error && !data && (
        <Card className="p-12">
          <div className="flex flex-col items-center justify-center text-center">
            <FileText className="h-12 w-12 text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground text-sm">No report data available</p>
            <p className="text-muted-foreground/70 text-xs mt-1">
              Select a report type and date range to generate a report
            </p>
          </div>
        </Card>
      )}
    </div>
  )
}