'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Calendar,
  Plus,
  MapPin,
  Trophy,
  Music,
  GraduationCap,
  Palmtree,
  Loader2,
  CalendarDays,
} from 'lucide-react'
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'

// ─── Types ───────────────────────────────────────────────────────────────────

interface Event {
  id: string
  title: string
  description: string | null
  date: string
  endDate: string | null
  venue: string | null
  type: string
  status: string
  createdAt: string
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getEventIcon(type: string) {
  switch (type) {
    case 'sports':
      return <Trophy className="h-5 w-5" />
    case 'cultural':
      return <Music className="h-5 w-5" />
    case 'academic':
      return <GraduationCap className="h-5 w-5" />
    case 'holiday':
      return <Palmtree className="h-5 w-5" />
    default:
      return <CalendarDays className="h-5 w-5" />
  }
}

function getEventIconColor(type: string) {
  switch (type) {
    case 'sports':
      return 'bg-amber-100 text-amber-600 dark:bg-amber-950 dark:text-amber-400'
    case 'cultural':
      return 'bg-rose-100 text-rose-600 dark:bg-rose-950 dark:text-rose-400'
    case 'academic':
      return 'bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400'
    case 'holiday':
      return 'bg-teal-100 text-teal-600 dark:bg-teal-950 dark:text-teal-400'
    default:
      return 'bg-sky-100 text-sky-600 dark:bg-sky-950 dark:text-sky-400'
  }
}

function getTypeBadgeVariant(type: string) {
  switch (type) {
    case 'sports':
      return 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400'
    case 'cultural':
      return 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
    case 'academic':
      return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400'
    case 'holiday':
      return 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-400'
    default:
      return 'bg-muted text-muted-foreground'
  }
}

function getStatusBadge(status: string) {
  switch (status) {
    case 'upcoming':
      return (
        <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 text-[10px] px-1.5 py-0 hover:bg-emerald-100">
          Upcoming
        </Badge>
      )
    case 'completed':
      return (
        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
          Completed
        </Badge>
      )
    case 'cancelled':
      return (
        <Badge variant="destructive" className="text-[10px] px-1.5 py-0">
          Cancelled
        </Badge>
      )
    default:
      return (
        <Badge variant="outline" className="text-[10px] px-1.5 py-0">
          {status}
        </Badge>
      )
  }
}

function formatEventDate(dateStr: string) {
  const date = new Date(dateStr)
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}

function formatDateRange(startDate: string, endDate: string | null) {
  const start = formatEventDate(startDate)
  if (endDate) {
    return `${start} — ${formatEventDate(endDate)}`
  }
  return start
}

function isUpcoming(status: string) {
  return status === 'upcoming'
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function EventCardSkeleton() {
  return (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <Skeleton className="h-10 w-10 rounded-lg" />
            <div className="space-y-2">
              <Skeleton className="h-5 w-40" />
              <Skeleton className="h-4 w-24" />
            </div>
          </div>
          <Skeleton className="h-5 w-16" />
        </div>
        <Skeleton className="h-4 w-full" />
        <div className="flex items-center gap-2">
          <Skeleton className="h-4 w-28" />
          <Skeleton className="h-4 w-24" />
        </div>
      </div>
    </Card>
  )
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function EventsModule() {
  const [events, setEvents] = useState<Event[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  // Form state
  const [formTitle, setFormTitle] = useState('')
  const [formDescription, setFormDescription] = useState('')
  const [formDate, setFormDate] = useState('')
  const [formEndDate, setFormEndDate] = useState('')
  const [formVenue, setFormVenue] = useState('')
  const [formType, setFormType] = useState('')

  const fetchEvents = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      const res = await fetch('/api/events')
      if (!res.ok) throw new Error('Failed to fetch events')
      const json = await res.json()
      setEvents(json.data ?? [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchEvents()
  }, [fetchEvents])

  const handleSubmit = async () => {
    if (!formTitle || !formDate || !formType) return
    try {
      setSubmitting(true)
      const res = await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formTitle,
          description: formDescription || null,
          date: formDate,
          endDate: formEndDate || null,
          venue: formVenue || null,
          type: formType,
        }),
      })
      if (!res.ok) throw new Error('Failed to create event')
      setDialogOpen(false)
      setFormTitle('')
      setFormDescription('')
      setFormDate('')
      setFormEndDate('')
      setFormVenue('')
      setFormType('')
      fetchEvents()
    } catch (err) {
      console.error(err)
    } finally {
      setSubmitting(false)
    }
  }

  // Sort by date (upcoming first, then completed)
  const sortedEvents = [...events].sort((a, b) => {
    // Upcoming first
    if (a.status === 'upcoming' && b.status !== 'upcoming') return -1
    if (a.status !== 'upcoming' && b.status === 'upcoming') return 1
    // Then by date descending
    return new Date(b.date).getTime() - new Date(a.date).getTime()
  })

  const upcomingCount = events.filter((e) => e.status === 'upcoming').length
  const completedCount = events.filter((e) => e.status === 'completed').length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Event Management
          </h1>
          <p className="text-muted-foreground mt-1">
            Plan, schedule, and track school events
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Create Event
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Event</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label htmlFor="evt-title">Event Title *</Label>
                <Input
                  id="evt-title"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g., Annual Sports Day"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="evt-desc">Description</Label>
                <Textarea
                  id="evt-desc"
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Event details..."
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="evt-date">Start Date *</Label>
                  <Input
                    id="evt-date"
                    type="date"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="evt-enddate">End Date</Label>
                  <Input
                    id="evt-enddate"
                    type="date"
                    value={formEndDate}
                    onChange={(e) => setFormEndDate(e.target.value)}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="evt-venue">Venue</Label>
                  <Input
                    id="evt-venue"
                    value={formVenue}
                    onChange={(e) => setFormVenue(e.target.value)}
                    placeholder="e.g., School Ground"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="evt-type">Type *</Label>
                  <Select value={formType} onValueChange={setFormType}>
                    <SelectTrigger id="evt-type">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">General</SelectItem>
                      <SelectItem value="sports">Sports</SelectItem>
                      <SelectItem value="cultural">Cultural</SelectItem>
                      <SelectItem value="academic">Academic</SelectItem>
                      <SelectItem value="holiday">Holiday</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button
                onClick={handleSubmit}
                disabled={submitting || !formTitle || !formDate || !formType}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Create Event
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Error State */}
      {error && !loading && (
        <Card className="border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950/30">
          <CardContent className="flex items-center gap-3 p-4">
            <span className="text-rose-500 text-lg">⚠</span>
            <p className="text-sm text-rose-700 dark:text-rose-400">{error}</p>
            <Button variant="outline" size="sm" className="ml-auto" onClick={fetchEvents}>
              Retry
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950">
              <Calendar className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{events.length}</p>
              <p className="text-xs text-muted-foreground">Total Events</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-950">
              <CalendarDays className="h-5 w-5 text-teal-600 dark:text-teal-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{upcomingCount}</p>
              <p className="text-xs text-muted-foreground">Upcoming</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-950">
              <Trophy className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{completedCount}</p>
              <p className="text-xs text-muted-foreground">Completed</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Event Cards */}
      {loading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <EventCardSkeleton key={i} />
          ))}
        </div>
      ) : sortedEvents.length > 0 ? (
        <ScrollArea className="max-h-[700px]">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 pr-3">
            {sortedEvents.map((event) => {
              const upcoming = isUpcoming(event.status)
              const eventDate = new Date(event.date)
              const day = eventDate.getDate()
              const monthShort = eventDate.toLocaleDateString('en-US', {
                month: 'short',
              })

              return (
                <Card
                  key={event.id}
                  className={`p-4 transition-shadow hover:shadow-md ${
                    upcoming
                      ? 'border-l-4 border-l-emerald-500'
                      : 'opacity-75'
                  }`}
                >
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <div
                          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${getEventIconColor(event.type)}`}
                        >
                          {getEventIcon(event.type)}
                        </div>
                        <div className="min-w-0">
                          <h3 className="font-semibold text-sm leading-tight truncate">
                            {event.title}
                          </h3>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {getStatusBadge(event.status)}
                      </div>
                    </div>

                    {/* Type Badge */}
                    <span
                      className={`inline-flex items-center rounded-full px-2 py-0 text-[10px] font-medium ${getTypeBadgeVariant(event.type)}`}
                    >
                      {event.type}
                    </span>

                    {/* Description */}
                    {event.description && (
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {event.description}
                      </p>
                    )}

                    {/* Date Range & Venue */}
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <CalendarDays className="h-3 w-3 shrink-0" />
                        <span>{formatDateRange(event.date, event.endDate)}</span>
                      </div>
                      {event.venue && (
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <MapPin className="h-3 w-3 shrink-0" />
                          <span>{event.venue}</span>
                        </div>
                      )}
                    </div>

                    {/* Date badge for upcoming */}
                    {upcoming && (
                      <div className="flex items-center gap-2 pt-1">
                        <div className="flex h-9 w-9 flex-col items-center justify-center rounded-lg bg-emerald-50 dark:bg-emerald-950/50">
                          <span className="text-[9px] font-medium text-emerald-600 dark:text-emerald-400 uppercase leading-none">
                            {monthShort}
                          </span>
                          <span className="text-sm font-bold text-emerald-700 dark:text-emerald-300 leading-tight">
                            {day}
                          </span>
                        </div>
                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                          Coming up
                        </span>
                      </div>
                    )}
                  </div>
                </Card>
              )
            })}
          </div>
        </ScrollArea>
      ) : (
        <Card className="p-12">
          <div className="flex flex-col items-center justify-center text-center">
            <Calendar className="h-12 w-12 text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground text-sm">No events scheduled</p>
            <p className="text-muted-foreground/70 text-xs mt-1">
              Create a new event to get started
            </p>
          </div>
        </Card>
      )}
    </div>
  )
}
