'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  BookOpen,
  Plus,
  Calendar,
  Clock,
  AlertCircle,
  CircleCheck,
  BookOpenCheck,
  Loader2,
} from 'lucide-react'
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'

// ─── Types ───────────────────────────────────────────────────────────────────

interface Homework {
  id: string
  title: string
  description: string | null
  subjectName: string
  sectionName: string
  teacherName: string
  dueDate: string
  status: string
  createdAt: string
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getDueDateStatus(dueDate: string): 'overdue' | 'due-today' | 'upcoming' {
  const now = new Date()
  const due = new Date(dueDate)
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const dueDay = new Date(due.getFullYear(), due.getMonth(), due.getDate())

  if (dueDay < today) return 'overdue'
  if (dueDay.getTime() === today.getTime()) return 'due-today'
  return 'upcoming'
}

function getDueDateColor(status: 'overdue' | 'due-today' | 'upcoming') {
  switch (status) {
    case 'overdue':
      return 'border-l-rose-500 bg-rose-50/50 dark:bg-rose-950/20'
    case 'due-today':
      return 'border-l-amber-500 bg-amber-50/50 dark:bg-amber-950/20'
    case 'upcoming':
      return 'border-l-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20'
  }
}

function getDueDateBadge(status: 'overdue' | 'due-today' | 'upcoming') {
  switch (status) {
    case 'overdue':
      return <Badge variant="destructive" className="text-[10px] px-1.5 py-0">Overdue</Badge>
    case 'due-today':
      return <Badge className="text-[10px] px-1.5 py-0 bg-amber-500 hover:bg-amber-600 text-white">Due Today</Badge>
    case 'upcoming':
      return <Badge variant="outline" className="text-[10px] px-1.5 py-0 text-emerald-600 border-emerald-300">Upcoming</Badge>
  }
}

function formatDueDate(dateStr: string) {
  const date = new Date(dateStr)
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function HomeworkCardSkeleton() {
  return (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-start justify-between">
          <Skeleton className="h-5 w-3/4" />
          <Skeleton className="h-5 w-16" />
        </div>
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-1/2" />
        <div className="flex items-center justify-between">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-5 w-20" />
        </div>
      </div>
    </Card>
  )
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function HomeworkModule() {
  const [homework, setHomework] = useState<Homework[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState('all')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  // Form state
  const [formTitle, setFormTitle] = useState('')
  const [formDescription, setFormDescription] = useState('')
  const [formSubject, setFormSubject] = useState('')
  const [formSection, setFormSection] = useState('')
  const [formDueDate, setFormDueDate] = useState('')
  const [formTeacher, setFormTeacher] = useState('')

  const fetchHomework = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      let url = '/api/homework'
      if (activeTab === 'active' || activeTab === 'completed') {
        url += `?status=${activeTab}`
      }
      const res = await fetch(url)
      if (!res.ok) throw new Error('Failed to fetch homework')
      const json = await res.json()
      setHomework(json.data ?? [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }, [activeTab])

  useEffect(() => {
    fetchHomework()
  }, [fetchHomework])

  const handleSubmit = async () => {
    if (!formTitle || !formSubject || !formSection || !formDueDate || !formTeacher) return

    try {
      setSubmitting(true)
      const res = await fetch('/api/homework', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formTitle,
          description: formDescription,
          subjectName: formSubject,
          sectionName: formSection,
          dueDate: formDueDate,
          teacherName: formTeacher,
        }),
      })
      if (!res.ok) throw new Error('Failed to create homework')
      setDialogOpen(false)
      setFormTitle('')
      setFormDescription('')
      setFormSubject('')
      setFormSection('')
      setFormDueDate('')
      setFormTeacher('')
      fetchHomework()
    } catch (err) {
      console.error(err)
    } finally {
      setSubmitting(false)
    }
  }

  // Filter homework based on tab
  const filteredHomework = homework.filter((h) => {
    if (activeTab === 'all') return true
    if (activeTab === 'active') return h.status === 'active'
    if (activeTab === 'completed') return h.status === 'completed'
    return true
  })

  // Summary stats
  const activeCount = homework.filter((h) => h.status === 'active').length
  const completedCount = homework.filter((h) => h.status === 'completed').length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Homework & Assignments
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage homework and track assignments across sections
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Create Homework
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Create Homework</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label htmlFor="hw-title">Title *</Label>
                <Input
                  id="hw-title"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g., Chapter 5 Exercises"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hw-desc">Description</Label>
                <Textarea
                  id="hw-desc"
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Homework details..."
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="hw-subject">Subject *</Label>
                  <Input
                    id="hw-subject"
                    value={formSubject}
                    onChange={(e) => setFormSubject(e.target.value)}
                    placeholder="e.g., Mathematics"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hw-section">Section *</Label>
                  <Input
                    id="hw-section"
                    value={formSection}
                    onChange={(e) => setFormSection(e.target.value)}
                    placeholder="e.g., 10-A"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="hw-teacher">Teacher *</Label>
                  <Input
                    id="hw-teacher"
                    value={formTeacher}
                    onChange={(e) => setFormTeacher(e.target.value)}
                    placeholder="Teacher name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hw-due">Due Date *</Label>
                  <Input
                    id="hw-due"
                    type="date"
                    value={formDueDate}
                    onChange={(e) => setFormDueDate(e.target.value)}
                  />
                </div>
              </div>
              <Button
                onClick={handleSubmit}
                disabled={submitting || !formTitle || !formSubject || !formSection || !formDueDate || !formTeacher}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Create Homework
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Error State */}
      {error && !loading && (
        <Card className="border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950/30">
          <CardContent className="flex items-center gap-3 p-4">
            <AlertCircle className="h-5 w-5 text-rose-500 shrink-0" />
            <p className="text-sm text-rose-700 dark:text-rose-400">{error}</p>
            <Button
              variant="outline"
              size="sm"
              className="ml-auto shrink-0"
              onClick={fetchHomework}
            >
              Retry
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-950">
              <Clock className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{activeCount}</p>
              <p className="text-xs text-muted-foreground">Active Assignments</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950">
              <CircleCheck className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{completedCount}</p>
              <p className="text-xs text-muted-foreground">Completed</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 transition-shadow hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-950">
              <BookOpen className="h-5 w-5 text-teal-600 dark:text-teal-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{homework.length}</p>
              <p className="text-xs text-muted-foreground">Total Homework</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="active">
            Active ({activeCount})
          </TabsTrigger>
          <TabsTrigger value="completed">
            Completed ({completedCount})
          </TabsTrigger>
          <TabsTrigger value="all">
            All ({homework.length})
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Homework List */}
      {loading ? (
        <div className="space-y-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <HomeworkCardSkeleton key={i} />
          ))}
        </div>
      ) : filteredHomework.length > 0 ? (
        <ScrollArea className="max-h-[600px]">
          <div className="space-y-4 pr-3">
            {filteredHomework.map((hw) => {
              const dueStatus = getDueDateStatus(hw.dueDate)
              return (
                <Card
                  key={hw.id}
                  className={`border-l-4 p-4 transition-shadow hover:shadow-md ${getDueDateColor(dueStatus)}`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2 flex-wrap min-w-0">
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0 shrink-0">
                          {hw.subjectName}
                        </Badge>
                        <h3 className="font-semibold text-sm truncate">{hw.title}</h3>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {getDueDateBadge(dueStatus)}
                        <Badge
                          variant={hw.status === 'completed' ? 'default' : 'secondary'}
                          className="text-[10px] px-1.5 py-0"
                        >
                          {hw.status}
                        </Badge>
                      </div>
                    </div>
                    {hw.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {hw.description}
                      </p>
                    )}
                    <div className="flex items-center gap-4 flex-wrap text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <BookOpenCheck className="h-3 w-3" />
                        {hw.teacherName}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        Due: {formatDueDate(hw.dueDate)}
                      </span>
                      <span className="flex items-center gap-1">
                        <BookOpen className="h-3 w-3" />
                        {hw.sectionName}
                      </span>
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        </ScrollArea>
      ) : (
        <Card className="p-12">
          <div className="flex flex-col items-center justify-center text-center">
            <BookOpen className="h-12 w-12 text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground text-sm">No homework found</p>
            <p className="text-muted-foreground/70 text-xs mt-1">
              Create a new assignment to get started
            </p>
          </div>
        </Card>
      )}
    </div>
  )
}
