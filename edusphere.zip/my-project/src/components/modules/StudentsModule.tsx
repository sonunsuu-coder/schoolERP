'use client'

import React, { useState, useEffect, useCallback, useRef } from 'react'
import {
  Plus,
  Search,
  Eye,
  Pencil,
  Trash2,
  Users,
  Loader2,
  AlertCircle,
  Phone,
  Mail,
  MapPin,
  Calendar,
  User,
  Heart,
  BookOpen,
  DollarSign,
  CheckCircle,
  XCircle,
  Clock,
} from 'lucide-react'

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogAction,
  AlertDialogCancel,
} from '@/components/ui/alert-dialog'

// ─── Types ──────────────────────────────────────────────────────────────────

interface ClassWithSections {
  id: string
  name: string
  numericLevel: number
  sections: { id: string; name: string }[]
}

interface Student {
  id: string
  admissionNo: string
  rollNumber: string | null
  firstName: string
  lastName: string
  dob: string
  gender: string
  bloodGroup: string | null
  religion: string | null
  category: string | null
  address: string
  phone: string | null
  email: string | null
  avatar: string | null
  admissionDate: string
  fatherName: string | null
  fatherPhone: string | null
  fatherOccupation: string | null
  motherName: string | null
  motherPhone: string | null
  motherOccupation: string | null
  guardianName: string | null
  guardianPhone: string | null
  guardianRelation: string | null
  medicalHistory: string | null
  allergies: string | null
  schoolId: string
  classId: string | null
  sectionId: string | null
  className: string | null
  sectionName: string | null
  status: string
  class?: { id: string; name: string } | null
  section?: { id: string; name: string } | null
  attendanceSummary?: {
    totalDays: number
    presentDays: number
    absentDays: number
    percentage: number
  }
  feeSummary?: {
    totalFees: number
    totalPaid: number
    outstanding: number
    paidRecords: number
    pendingRecords: number
  }
  feeRecords?: Array<{
    id: string
    feeName: string
    amount: number
    paidAmount: number
    dueDate: string
    paidDate: string | null
    status: string
  }>
}

interface StudentFormData {
  firstName: string
  lastName: string
  dob: string
  gender: string
  bloodGroup: string
  religion: string
  category: string
  address: string
  phone: string
  email: string
  fatherName: string
  fatherPhone: string
  fatherOccupation: string
  motherName: string
  motherPhone: string
  motherOccupation: string
  classId: string
  sectionId: string
  rollNumber: string
  allergies: string
  medicalHistory: string
}

const emptyForm: StudentFormData = {
  firstName: '',
  lastName: '',
  dob: '',
  gender: '',
  bloodGroup: '',
  religion: '',
  category: '',
  address: '',
  phone: '',
  email: '',
  fatherName: '',
  fatherPhone: '',
  fatherOccupation: '',
  motherName: '',
  motherPhone: '',
  motherOccupation: '',
  classId: '',
  sectionId: '',
  rollNumber: '',
  allergies: '',
  medicalHistory: '',
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function getInitials(firstName: string, lastName: string) {
  return `${(firstName?.[0] ?? '').toUpperCase()}${(lastName?.[0] ?? '').toUpperCase()}`
}

function formatDate(dateStr: string) {
  if (!dateStr) return 'N/A'
  try {
    return new Date(dateStr).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    })
  } catch {
    return dateStr
  }
}

function formatCurrency(amount: number) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount)
}

// ─── Component ──────────────────────────────────────────────────────────────

export default function StudentsModule() {
  // Data state
  const [students, setStudents] = useState<Student[]>([])
  const [total, setTotal] = useState(0)
  const [totalPages, setTotalPages] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Filter & pagination state
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [filterClassId, setFilterClassId] = useState('')
  const [filterSectionId, setFilterSectionId] = useState('')
  const [filterStatus, setFilterStatus] = useState('')

  // Classes & sections
  const [classes, setClasses] = useState<ClassWithSections[]>([])
  const [sections, setSections] = useState<{ id: string; name: string }[]>([])

  // Dialog state
  const [formOpen, setFormOpen] = useState(false)
  const [editingStudent, setEditingStudent] = useState<Student | null>(null)
  const [form, setForm] = useState<StudentFormData>(emptyForm)
  const [formErrors, setFormErrors] = useState<Partial<Record<keyof StudentFormData, string>>>({})
  const [submitting, setSubmitting] = useState(false)

  // View sheet state
  const [viewOpen, setViewOpen] = useState(false)
  const [viewStudent, setViewStudent] = useState<Student | null>(null)
  const [viewLoading, setViewLoading] = useState(false)

  // Delete dialog state
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [deletingStudent, setDeletingStudent] = useState<Student | null>(null)
  const [deleting, setDeleting] = useState(false)

  // Search debounce
  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // ─── Fetch classes & sections ───────────────────────────────────────────

  useEffect(() => {
    async function fetchClasses() {
      try {
        const res = await fetch('/api/classes')
        if (!res.ok) throw new Error('Failed to fetch classes')
        const json = await res.json()
        setClasses(json.data ?? [])
      } catch (err) {
        console.error(err)
      }
    }
    fetchClasses()
  }, [])

  // Update filter sections based on selected class
  useEffect(() => {
    if (filterClassId) {
      const cls = classes.find((c) => c.id === filterClassId)
      setSections(cls?.sections ?? [])
      // Reset section filter if the current one isn't in the new list
      if (filterSectionId && cls && !cls.sections.some((s) => s.id === filterSectionId)) {
        setFilterSectionId('')
      }
    } else {
      setSections(classes.flatMap((c) => c.sections))
    }
  }, [filterClassId, classes, filterSectionId])

  // ─── Fetch students ─────────────────────────────────────────────────────

  const fetchStudents = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const params = new URLSearchParams({
        page: String(page),
        limit: '10',
      })
      if (debouncedSearch) params.set('search', debouncedSearch)
      if (filterClassId) params.set('classId', filterClassId)
      if (filterSectionId) params.set('sectionId', filterSectionId)
      if (filterStatus) params.set('status', filterStatus)

      const res = await fetch(`/api/students?${params.toString()}`)
      if (!res.ok) throw new Error('Failed to fetch students')
      const json = await res.json()
      setStudents(json.data ?? [])
      setTotal(json.total ?? 0)
      setTotalPages(json.totalPages ?? 1)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }, [page, debouncedSearch, filterClassId, filterSectionId, filterStatus])

  useEffect(() => {
    fetchStudents()
  }, [fetchStudents])

  // Reset page when filters change
  useEffect(() => {
    setPage(1)
  }, [debouncedSearch, filterClassId, filterSectionId, filterStatus])

  // ─── Search debounce ────────────────────────────────────────────────────

  function handleSearchChange(value: string) {
    setSearch(value)
    if (searchTimerRef.current) clearTimeout(searchTimerRef.current)
    searchTimerRef.current = setTimeout(() => {
      setDebouncedSearch(value)
    }, 300)
  }

  // ─── Pagination ─────────────────────────────────────────────────────────

  function goToPage(newPage: number) {
    if (newPage >= 1 && newPage <= totalPages) {
      setPage(newPage)
    }
  }

  function getPaginationPages(): (number | '...')[] {
    const pages: (number | '...')[] = []
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i)
    } else {
      pages.push(1)
      if (page > 3) pages.push('...')
      const start = Math.max(2, page - 1)
      const end = Math.min(totalPages - 1, page + 1)
      for (let i = start; i <= end; i++) pages.push(i)
      if (page < totalPages - 2) pages.push('...')
      pages.push(totalPages)
    }
    return pages
  }

  // ─── Form: open for Add/Edit ────────────────────────────────────────────

  function openAddForm() {
    setEditingStudent(null)
    setForm(emptyForm)
    setFormErrors({})
    setFormOpen(true)
  }

  function openEditForm(student: Student) {
    setEditingStudent(student)
    setForm({
      firstName: student.firstName ?? '',
      lastName: student.lastName ?? '',
      dob: student.dob ? student.dob.split('T')[0] : '',
      gender: student.gender ?? '',
      bloodGroup: student.bloodGroup ?? '',
      religion: student.religion ?? '',
      category: student.category ?? '',
      address: student.address ?? '',
      phone: student.phone ?? '',
      email: student.email ?? '',
      fatherName: student.fatherName ?? '',
      fatherPhone: student.fatherPhone ?? '',
      fatherOccupation: student.fatherOccupation ?? '',
      motherName: student.motherName ?? '',
      motherPhone: student.motherPhone ?? '',
      motherOccupation: student.motherOccupation ?? '',
      classId: student.classId ?? '',
      sectionId: student.sectionId ?? '',
      rollNumber: student.rollNumber ?? '',
      allergies: student.allergies ?? '',
      medicalHistory: student.medicalHistory ?? '',
    })
    setFormErrors({})
    setFormOpen(true)
  }

  // ─── Form: section dependent on class ───────────────────────────────────

  const formSections = form.classId
    ? classes.find((c) => c.id === form.classId)?.sections ?? []
    : classes.flatMap((c) => c.sections)

  // ─── Form: validation ───────────────────────────────────────────────────

  function validateForm(): boolean {
    const errors: Partial<Record<keyof StudentFormData, string>> = {}
    if (!form.firstName.trim()) errors.firstName = 'First name is required'
    if (!form.lastName.trim()) errors.lastName = 'Last name is required'
    if (!form.dob) errors.dob = 'Date of birth is required'
    if (!form.gender) errors.gender = 'Gender is required'
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      errors.email = 'Invalid email format'
    }
    if (form.phone && !/^[+]?[\d\s-]{7,15}$/.test(form.phone)) {
      errors.phone = 'Invalid phone number'
    }
    setFormErrors(errors)
    return Object.keys(errors).length === 0
  }

  // ─── Form: submit ───────────────────────────────────────────────────────

  async function handleSubmit() {
    if (!validateForm()) return
    setSubmitting(true)
    try {
      const selectedClass = classes.find((c) => c.id === form.classId)
      const selectedSection = form.classId
        ? classes.find((c) => c.id === form.classId)?.sections.find((s) => s.id === form.sectionId)
        : formSections.find((s) => s.id === form.sectionId)

      const payload = {
        ...form,
        admissionNo: editingStudent?.admissionNo ?? `ADM-${new Date().getFullYear()}-${String(Date.now()).slice(-4)}`,
        className: selectedClass?.name ?? null,
        sectionName: selectedSection?.name ?? null,
      }

      const url = editingStudent
        ? `/api/students/${editingStudent.id}`
        : '/api/students'
      const method = editingStudent ? 'PUT' : 'POST'

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })

      if (!res.ok) throw new Error(`Failed to ${editingStudent ? 'update' : 'create'} student`)

      setFormOpen(false)
      fetchStudents()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setSubmitting(false)
    }
  }

  // ─── View student detail ────────────────────────────────────────────────

  async function openViewSheet(student: Student) {
    setViewStudent(student)
    setViewOpen(true)
    setViewLoading(true)
    try {
      const res = await fetch(`/api/students/${student.id}`)
      if (!res.ok) throw new Error('Failed to fetch student details')
      const json = await res.json()
      setViewStudent(json.data)
    } catch (err) {
      console.error(err)
    } finally {
      setViewLoading(false)
    }
  }

  // ─── Delete student ─────────────────────────────────────────────────────

  function openDeleteDialog(student: Student) {
    setDeletingStudent(student)
    setDeleteOpen(true)
  }

  async function handleDelete() {
    if (!deletingStudent) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/students/${deletingStudent.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Failed to delete student')
      setDeleteOpen(false)
      setDeletingStudent(null)
      fetchStudents()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete student')
    } finally {
      setDeleting(false)
    }
  }

  // ─── Render ─────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* ─── Top Bar ─────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold tracking-tight">Students</h1>
          <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400">
            {total}
          </Badge>
        </div>
        <Button onClick={openAddForm} className="bg-emerald-600 hover:bg-emerald-700 text-white">
          <Plus className="size-4 mr-2" />
          Add Student
        </Button>
      </div>

      {/* ─── Filters Row ─────────────────────────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input
            placeholder="Search by name or admission no..."
            value={search}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={filterClassId} onValueChange={(val) => setFilterClassId(val === '__all__' ? '' : val)}>
          <SelectTrigger className="w-full sm:w-[160px]">
            <SelectValue placeholder="All Classes" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All Classes</SelectItem>
            {classes.map((cls) => (
              <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterSectionId} onValueChange={(val) => setFilterSectionId(val === '__all__' ? '' : val)}>
          <SelectTrigger className="w-full sm:w-[160px]">
            <SelectValue placeholder="All Sections" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All Sections</SelectItem>
            {sections.map((sec) => (
              <SelectItem key={sec.id} value={sec.id}>{sec.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={(val) => setFilterStatus(val === '__all__' ? '' : val)}>
          <SelectTrigger className="w-full sm:w-[140px]">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* ─── Error Banner ────────────────────────────────────────────── */}
      {error && (
        <Card className="border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950/30">
          <CardContent className="flex items-center gap-3 p-4">
            <AlertCircle className="size-5 text-red-600 dark:text-red-400 shrink-0" />
            <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
            <Button variant="ghost" size="sm" className="ml-auto text-red-600" onClick={() => setError(null)}>
              Dismiss
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ─── Students Table ──────────────────────────────────────────── */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="w-[56px] pl-4">Photo</TableHead>
                  <TableHead>Admission No</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead className="hidden md:table-cell">Class</TableHead>
                  <TableHead className="hidden lg:table-cell">Section</TableHead>
                  <TableHead className="hidden lg:table-cell">Gender</TableHead>
                  <TableHead className="hidden xl:table-cell">Father&apos;s Name</TableHead>
                  <TableHead className="hidden xl:table-cell">Phone</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-[120px] text-right pr-4">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 10 }).map((_, i) => (
                    <TableRow key={i} className="hover:bg-transparent">
                      <TableCell className="pl-4"><Skeleton className="size-9 rounded-full" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-36" /></TableCell>
                      <TableCell className="hidden md:table-cell"><Skeleton className="h-4 w-16" /></TableCell>
                      <TableCell className="hidden lg:table-cell"><Skeleton className="h-4 w-12" /></TableCell>
                      <TableCell className="hidden lg:table-cell"><Skeleton className="h-4 w-14" /></TableCell>
                      <TableCell className="hidden xl:table-cell"><Skeleton className="h-4 w-28" /></TableCell>
                      <TableCell className="hidden xl:table-cell"><Skeleton className="h-4 w-20" /></TableCell>
                      <TableCell><Skeleton className="h-6 w-16" /></TableCell>
                      <TableCell><Skeleton className="h-8 w-20 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : students.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={10} className="h-40 text-center">
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Users className="size-10 opacity-40" />
                        <p className="text-sm font-medium">No students found</p>
                        <p className="text-xs">Try adjusting your search or filters</p>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  students.map((student) => (
                    <TableRow key={student.id} className="group cursor-pointer" onClick={() => openViewSheet(student)}>
                      <TableCell className="pl-4" onClick={(e) => e.stopPropagation()}>
                        <Avatar className="size-9">
                          <AvatarImage src={student.avatar ?? undefined} alt={student.firstName} />
                          <AvatarFallback className="bg-emerald-100 text-emerald-700 text-xs font-medium dark:bg-emerald-900/30 dark:text-emerald-400">
                            {getInitials(student.firstName, student.lastName)}
                          </AvatarFallback>
                        </Avatar>
                      </TableCell>
                      <TableCell className="font-mono text-xs">{student.admissionNo}</TableCell>
                      <TableCell>
                        <div className="font-medium">{student.firstName} {student.lastName}</div>
                        <div className="text-xs text-muted-foreground md:hidden">{student.className ?? '—'} {student.sectionName ? `· ${student.sectionName}` : ''}</div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">{student.className ?? '—'}</TableCell>
                      <TableCell className="hidden lg:table-cell">{student.sectionName ?? '—'}</TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <Badge
                          variant="secondary"
                          className={
                            student.gender === 'Male'
                              ? 'bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-400'
                              : student.gender === 'Female'
                                ? 'bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400'
                                : 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400'
                          }
                        >
                          {student.gender}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden xl:table-cell">{student.fatherName ?? '—'}</TableCell>
                      <TableCell className="hidden xl:table-cell text-xs">{student.phone ?? '—'}</TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <Badge
                          className={
                            student.status === 'active'
                              ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-transparent'
                              : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-transparent'
                          }
                        >
                          {student.status === 'active' ? (
                            <><CheckCircle className="size-3 mr-1" />Active</>
                          ) : (
                            <><XCircle className="size-3 mr-1" />Inactive</>
                          )}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right pr-4" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="size-8" onClick={() => openViewSheet(student)} title="View">
                            <Eye className="size-4 text-muted-foreground" />
                          </Button>
                          <Button variant="ghost" size="icon" className="size-8" onClick={() => openEditForm(student)} title="Edit">
                            <Pencil className="size-4 text-muted-foreground" />
                          </Button>
                          <Button variant="ghost" size="icon" className="size-8" onClick={() => openDeleteDialog(student)} title="Delete">
                            <Trash2 className="size-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* ─── Pagination ──────────────────────────────────────────── */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between border-t px-4 py-3">
              <p className="text-sm text-muted-foreground">
                Showing {(page - 1) * 10 + 1}–{Math.min(page * 10, total)} of {total}
              </p>
              <div className="flex items-center gap-1">
                <Button variant="outline" size="icon" className="size-8" disabled={page <= 1} onClick={() => goToPage(page - 1)}>
                  <span className="sr-only">Previous</span>
                  <svg className="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                </Button>
                {getPaginationPages().map((p, idx) =>
                  p === '...' ? (
                    <span key={`ellipsis-${idx}`} className="px-2 text-muted-foreground">...</span>
                  ) : (
                    <Button
                      key={p}
                      variant={page === p ? 'default' : 'outline'}
                      size="icon"
                      className="size-8"
                      onClick={() => goToPage(p as number)}
                    >
                      {p}
                    </Button>
                  )
                )}
                <Button variant="outline" size="icon" className="size-8" disabled={page >= totalPages} onClick={() => goToPage(page + 1)}>
                  <span className="sr-only">Next</span>
                  <svg className="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ─── Add / Edit Dialog ───────────────────────────────────────── */}
      <Dialog open={formOpen} onOpenChange={(open) => { if (!open) setFormOpen(false) }}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingStudent ? 'Edit Student' : 'Add New Student'}</DialogTitle>
            <DialogDescription>
              {editingStudent ? 'Update the student information below.' : 'Fill in the student information to create a new record.'}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Personal Information */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                <User className="size-4" /> Personal Information
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name <span className="text-red-500">*</span></Label>
                  <Input
                    id="firstName"
                    value={form.firstName}
                    onChange={(e) => setForm((f) => ({ ...f, firstName: e.target.value }))}
                    placeholder="Enter first name"
                  />
                  {formErrors.firstName && <p className="text-xs text-red-500">{formErrors.firstName}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name <span className="text-red-500">*</span></Label>
                  <Input
                    id="lastName"
                    value={form.lastName}
                    onChange={(e) => setForm((f) => ({ ...f, lastName: e.target.value }))}
                    placeholder="Enter last name"
                  />
                  {formErrors.lastName && <p className="text-xs text-red-500">{formErrors.lastName}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dob">Date of Birth <span className="text-red-500">*</span></Label>
                  <Input
                    id="dob"
                    type="date"
                    value={form.dob}
                    onChange={(e) => setForm((f) => ({ ...f, dob: e.target.value }))}
                  />
                  {formErrors.dob && <p className="text-xs text-red-500">{formErrors.dob}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender <span className="text-red-500">*</span></Label>
                  <Select value={form.gender} onValueChange={(val) => setForm((f) => ({ ...f, gender: val }))}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Male">Male</SelectItem>
                      <SelectItem value="Female">Female</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  {formErrors.gender && <p className="text-xs text-red-500">{formErrors.gender}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bloodGroup">Blood Group</Label>
                  <Select value={form.bloodGroup} onValueChange={(val) => setForm((f) => ({ ...f, bloodGroup: val }))}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select blood group" />
                    </SelectTrigger>
                    <SelectContent>
                      {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map((bg) => (
                        <SelectItem key={bg} value={bg}>{bg}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="religion">Religion</Label>
                  <Input
                    id="religion"
                    value={form.religion}
                    onChange={(e) => setForm((f) => ({ ...f, religion: e.target.value }))}
                    placeholder="Enter religion"
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="category">Category</Label>
                  <Input
                    id="category"
                    value={form.category}
                    onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                    placeholder="e.g. General, OBC, SC, ST"
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Contact Information */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                <Phone className="size-4" /> Contact Information
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="address">Address</Label>
                  <Textarea
                    id="address"
                    value={form.address}
                    onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))}
                    placeholder="Enter full address"
                    rows={2}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={form.phone}
                    onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
                    placeholder="Enter phone number"
                  />
                  {formErrors.phone && <p className="text-xs text-red-500">{formErrors.phone}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                    placeholder="Enter email address"
                  />
                  {formErrors.email && <p className="text-xs text-red-500">{formErrors.email}</p>}
                </div>
              </div>
            </div>

            <Separator />

            {/* Parent Information */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                <Users className="size-4" /> Parent Information
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fatherName">Father&apos;s Name</Label>
                  <Input
                    id="fatherName"
                    value={form.fatherName}
                    onChange={(e) => setForm((f) => ({ ...f, fatherName: e.target.value }))}
                    placeholder="Enter father's name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fatherPhone">Father&apos;s Phone</Label>
                  <Input
                    id="fatherPhone"
                    value={form.fatherPhone}
                    onChange={(e) => setForm((f) => ({ ...f, fatherPhone: e.target.value }))}
                    placeholder="Enter father's phone"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fatherOccupation">Father&apos;s Occupation</Label>
                  <Input
                    id="fatherOccupation"
                    value={form.fatherOccupation}
                    onChange={(e) => setForm((f) => ({ ...f, fatherOccupation: e.target.value }))}
                    placeholder="Enter occupation"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="motherName">Mother&apos;s Name</Label>
                  <Input
                    id="motherName"
                    value={form.motherName}
                    onChange={(e) => setForm((f) => ({ ...f, motherName: e.target.value }))}
                    placeholder="Enter mother's name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="motherPhone">Mother&apos;s Phone</Label>
                  <Input
                    id="motherPhone"
                    value={form.motherPhone}
                    onChange={(e) => setForm((f) => ({ ...f, motherPhone: e.target.value }))}
                    placeholder="Enter mother's phone"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="motherOccupation">Mother&apos;s Occupation</Label>
                  <Input
                    id="motherOccupation"
                    value={form.motherOccupation}
                    onChange={(e) => setForm((f) => ({ ...f, motherOccupation: e.target.value }))}
                    placeholder="Enter occupation"
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Academic Information */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                <BookOpen className="size-4" /> Academic Information
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="formClass">Class</Label>
                  <Select value={form.classId} onValueChange={(val) => setForm((f) => ({ ...f, classId: val, sectionId: '' }))}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent>
                      {classes.map((cls) => (
                        <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="formSection">Section</Label>
                  <Select value={form.sectionId} onValueChange={(val) => setForm((f) => ({ ...f, sectionId: val }))}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select section" />
                    </SelectTrigger>
                    <SelectContent>
                      {formSections.map((sec) => (
                        <SelectItem key={sec.id} value={sec.id}>{sec.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="rollNumber">Roll Number</Label>
                  <Input
                    id="rollNumber"
                    value={form.rollNumber}
                    onChange={(e) => setForm((f) => ({ ...f, rollNumber: e.target.value }))}
                    placeholder="Enter roll number"
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Medical Information */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                <Heart className="size-4" /> Medical Information
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="allergies">Allergies</Label>
                  <Input
                    id="allergies"
                    value={form.allergies}
                    onChange={(e) => setForm((f) => ({ ...f, allergies: e.target.value }))}
                    placeholder="Enter known allergies"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="medicalHistory">Medical History</Label>
                  <Input
                    id="medicalHistory"
                    value={form.medicalHistory}
                    onChange={(e) => setForm((f) => ({ ...f, medicalHistory: e.target.value }))}
                    placeholder="Enter medical history"
                  />
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)} disabled={submitting}>
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              {submitting && <Loader2 className="size-4 mr-2 animate-spin" />}
              {editingStudent ? 'Update Student' : 'Create Student'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── View Student Sheet ──────────────────────────────────────── */}
      <Sheet open={viewOpen} onOpenChange={setViewOpen}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto p-0">
          {viewStudent && (
            <>
              <SheetHeader className="bg-gradient-to-br from-emerald-600 to-teal-600 text-white p-6 pb-8 rounded-b-2xl">
                <SheetTitle className="text-white">Student Profile</SheetTitle>
                <SheetDescription className="text-emerald-100">
                  {viewStudent.admissionNo}
                </SheetDescription>
                <div className="flex flex-col items-center gap-3 mt-4">
                  <Avatar className="size-20 border-4 border-white/30">
                    <AvatarImage src={viewStudent.avatar ?? undefined} alt={viewStudent.firstName} />
                    <AvatarFallback className="bg-white/20 text-white text-xl font-bold">
                      {getInitials(viewStudent.firstName, viewStudent.lastName)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-center">
                    <h2 className="text-xl font-bold">{viewStudent.firstName} {viewStudent.lastName}</h2>
                    <p className="text-emerald-100 text-sm">
                      {viewStudent.className ?? 'Unassigned'} {viewStudent.sectionName ? `· Section ${viewStudent.sectionName}` : ''}
                    </p>
                  </div>
                </div>
              </SheetHeader>

              <div className="p-4">
                <Tabs defaultValue="personal">
                  <TabsList className="w-full">
                    <TabsTrigger value="personal" className="flex-1">Personal</TabsTrigger>
                    <TabsTrigger value="academic" className="flex-1">Academic</TabsTrigger>
                    <TabsTrigger value="attendance" className="flex-1">Attendance</TabsTrigger>
                    <TabsTrigger value="fees" className="flex-1">Fees</TabsTrigger>
                  </TabsList>

                  {/* ─── Personal Tab ────────────────────────────── */}
                  <TabsContent value="personal" className="mt-4 space-y-4">
                    {viewLoading ? (
                      <div className="space-y-3">
                        {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <DetailRow icon={<User className="size-4" />} label="Admission No" value={viewStudent.admissionNo} />
                        <DetailRow icon={<Calendar className="size-4" />} label="Date of Birth" value={formatDate(viewStudent.dob)} />
                        <DetailRow
                          icon={<User className="size-4" />}
                          label="Gender"
                          value={
                            <Badge variant="secondary" className={
                              viewStudent.gender === 'Male'
                                ? 'bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-400'
                                : viewStudent.gender === 'Female'
                                  ? 'bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400'
                                  : ''
                            }>
                              {viewStudent.gender}
                            </Badge>
                          }
                        />
                        <DetailRow icon={<Heart className="size-4" />} label="Blood Group" value={viewStudent.bloodGroup ?? 'N/A'} />
                        <DetailRow icon={<BookOpen className="size-4" />} label="Religion" value={viewStudent.religion ?? 'N/A'} />
                        <DetailRow icon={<User className="size-4" />} label="Category" value={viewStudent.category ?? 'N/A'} />
                        <Separator className="my-2" />
                        <DetailRow icon={<MapPin className="size-4" />} label="Address" value={viewStudent.address ?? 'N/A'} />
                        <DetailRow icon={<Phone className="size-4" />} label="Phone" value={viewStudent.phone ?? 'N/A'} />
                        <DetailRow icon={<Mail className="size-4" />} label="Email" value={viewStudent.email ?? 'N/A'} />
                        <Separator className="my-2" />
                        <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider pt-1">Parents</h4>
                        <DetailRow icon={<User className="size-4" />} label="Father" value={viewStudent.fatherName ?? 'N/A'} />
                        <DetailRow icon={<Phone className="size-4" />} label="Father's Phone" value={viewStudent.fatherPhone ?? 'N/A'} />
                        <DetailRow icon={<BookOpen className="size-4" />} label="Father's Occupation" value={viewStudent.fatherOccupation ?? 'N/A'} />
                        <DetailRow icon={<User className="size-4" />} label="Mother" value={viewStudent.motherName ?? 'N/A'} />
                        <DetailRow icon={<Phone className="size-4" />} label="Mother's Phone" value={viewStudent.motherPhone ?? 'N/A'} />
                        <DetailRow icon={<BookOpen className="size-4" />} label="Mother's Occupation" value={viewStudent.motherOccupation ?? 'N/A'} />
                        <Separator className="my-2" />
                        <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider pt-1">Medical</h4>
                        <DetailRow icon={<AlertCircle className="size-4" />} label="Allergies" value={viewStudent.allergies ?? 'None'} />
                        <DetailRow icon={<Heart className="size-4" />} label="Medical History" value={viewStudent.medicalHistory ?? 'None'} />
                      </div>
                    )}
                  </TabsContent>

                  {/* ─── Academic Tab ────────────────────────────── */}
                  <TabsContent value="academic" className="mt-4 space-y-4">
                    <div className="space-y-1">
                      <DetailRow icon={<BookOpen className="size-4" />} label="Class" value={viewStudent.className ?? 'Unassigned'} />
                      <DetailRow icon={<BookOpen className="size-4" />} label="Section" value={viewStudent.sectionName ?? 'Unassigned'} />
                      <DetailRow icon={<User className="size-4" />} label="Roll Number" value={viewStudent.rollNumber ?? 'N/A'} />
                      <DetailRow icon={<Calendar className="size-4" />} label="Admission Date" value={formatDate(viewStudent.admissionDate)} />
                      <DetailRow
                        icon={<CheckCircle className="size-4" />}
                        label="Status"
                        value={
                          <Badge className={
                            viewStudent.status === 'active'
                              ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-transparent'
                              : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-transparent'
                          }>
                            {viewStudent.status}
                          </Badge>
                        }
                      />
                    </div>
                  </TabsContent>

                  {/* ─── Attendance Tab ──────────────────────────── */}
                  <TabsContent value="attendance" className="mt-4 space-y-4">
                    {viewLoading ? (
                      <div className="space-y-3">
                        <Skeleton className="h-24 w-full" />
                        <Skeleton className="h-8 w-full" />
                      </div>
                    ) : viewStudent.attendanceSummary ? (
                      <div className="space-y-4">
                        {/* Attendance Stats */}
                        <div className="grid grid-cols-2 gap-3">
                          <Card className="bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900">
                            <CardContent className="p-4 text-center">
                              <p className="text-2xl font-bold text-emerald-700 dark:text-emerald-400">
                                {viewStudent.attendanceSummary.percentage}%
                              </p>
                              <p className="text-xs text-muted-foreground">Attendance Rate</p>
                            </CardContent>
                          </Card>
                          <Card className="bg-sky-50 dark:bg-sky-950/20 border-sky-200 dark:border-sky-900">
                            <CardContent className="p-4 text-center">
                              <p className="text-2xl font-bold text-sky-700 dark:text-sky-400">
                                {viewStudent.attendanceSummary.totalDays}
                              </p>
                              <p className="text-xs text-muted-foreground">Total Days</p>
                            </CardContent>
                          </Card>
                          <Card className="bg-teal-50 dark:bg-teal-950/20 border-teal-200 dark:border-teal-900">
                            <CardContent className="p-4 text-center">
                              <p className="text-2xl font-bold text-teal-700 dark:text-teal-400">
                                {viewStudent.attendanceSummary.presentDays}
                              </p>
                              <p className="text-xs text-muted-foreground">Days Present</p>
                            </CardContent>
                          </Card>
                          <Card className="bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-900">
                            <CardContent className="p-4 text-center">
                              <p className="text-2xl font-bold text-red-700 dark:text-red-400">
                                {viewStudent.attendanceSummary.absentDays}
                              </p>
                              <p className="text-xs text-muted-foreground">Days Absent</p>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Attendance Bar */}
                        <div className="space-y-2">
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>Present</span>
                            <span>{viewStudent.attendanceSummary.presentDays}/{viewStudent.attendanceSummary.totalDays}</span>
                          </div>
                          <div className="h-3 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full bg-emerald-500 rounded-full transition-all"
                              style={{ width: `${viewStudent.attendanceSummary.percentage}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-8">No attendance data available</p>
                    )}
                  </TabsContent>

                  {/* ─── Fees Tab ────────────────────────────────── */}
                  <TabsContent value="fees" className="mt-4 space-y-4">
                    {viewLoading ? (
                      <div className="space-y-3">
                        {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}
                      </div>
                    ) : viewStudent.feeSummary ? (
                      <div className="space-y-4">
                        {/* Fee Summary Cards */}
                        <div className="grid grid-cols-2 gap-3">
                          <Card>
                            <CardContent className="p-4 text-center">
                              <p className="text-lg font-bold text-foreground">
                                {formatCurrency(viewStudent.feeSummary.totalFees)}
                              </p>
                              <p className="text-xs text-muted-foreground">Total Fees</p>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4 text-center">
                              <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                                {formatCurrency(viewStudent.feeSummary.totalPaid)}
                              </p>
                              <p className="text-xs text-muted-foreground">Total Paid</p>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4 text-center">
                              <p className="text-lg font-bold text-red-600 dark:text-red-400">
                                {formatCurrency(viewStudent.feeSummary.outstanding)}
                              </p>
                              <p className="text-xs text-muted-foreground">Outstanding</p>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4 text-center">
                              <p className="text-lg font-bold">
                                {viewStudent.feeSummary.paidRecords}/{viewStudent.feeSummary.paidRecords + viewStudent.feeSummary.pendingRecords}
                              </p>
                              <p className="text-xs text-muted-foreground">Paid Records</p>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Fee Payment Progress */}
                        <div className="space-y-2">
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>Payment Progress</span>
                            <span>
                              {viewStudent.feeSummary.totalFees > 0
                                ? Math.round((viewStudent.feeSummary.totalPaid / viewStudent.feeSummary.totalFees) * 100)
                                : 0}%
                            </span>
                          </div>
                          <div className="h-3 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full bg-emerald-500 rounded-full transition-all"
                              style={{
                                width: `${viewStudent.feeSummary.totalFees > 0
                                  ? Math.round((viewStudent.feeSummary.totalPaid / viewStudent.feeSummary.totalFees) * 100)
                                  : 0}%`
                              }}
                            />
                          </div>
                        </div>

                        {/* Fee Records List */}
                        {viewStudent.feeRecords && viewStudent.feeRecords.length > 0 && (
                          <div className="space-y-2">
                            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Fee Records</h4>
                            <ScrollArea className="max-h-64">
                              <div className="space-y-2">
                                {viewStudent.feeRecords.map((fr) => (
                                  <div key={fr.id} className="flex items-center justify-between p-3 rounded-lg border text-sm">
                                    <div>
                                      <p className="font-medium">{fr.feeName}</p>
                                      <p className="text-xs text-muted-foreground">
                                        Due: {formatDate(fr.dueDate)}
                                      </p>
                                    </div>
                                    <div className="text-right">
                                      <p className="font-medium">{formatCurrency(fr.amount)}</p>
                                      <Badge
                                        variant="secondary"
                                        className={
                                          fr.status === 'paid'
                                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 text-xs'
                                            : fr.status === 'overdue'
                                              ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 text-xs'
                                              : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 text-xs'
                                        }
                                      >
                                        {fr.status === 'paid' && <CheckCircle className="size-3 mr-1" />}
                                        {fr.status === 'overdue' && <Clock className="size-3 mr-1" />}
                                        {fr.status === 'pending' && <Clock className="size-3 mr-1" />}
                                        {fr.status.charAt(0).toUpperCase() + fr.status.slice(1)}
                                      </Badge>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </ScrollArea>
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-8">No fee data available</p>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>

      {/* ─── Delete Confirmation Dialog ─────────────────────────────── */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Deactivate Student</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to deactivate {deletingStudent?.firstName} {deletingStudent?.lastName}? Their status will be set to inactive. This action can be reversed by editing the student later.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {deleting && <Loader2 className="size-4 mr-2 animate-spin" />}
              Deactivate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ─── Detail Row Sub-component ───────────────────────────────────────────────

function DetailRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start gap-3 py-2">
      <div className="text-muted-foreground mt-0.5 shrink-0">{icon}</div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium">{value}</p>
      </div>
    </div>
  )
}